#include <stdio.h>
#include <stdlib.h>

#include "../../../../include/LIST/structure.h"
#include "../../../../include/LIST/library/file/file_writeCSV.h"
#include "../../../../include/LIST/list/individu/individuL.h"
#include "../../../../include/LIST/list/mariage/mariageL.h"
#include "../../../../include/LIST/list/list.h"

#include "../../../../include/LIST/listGeneration/methode/deleteL.h"

void deleteList(dataFile *file, LIST **ptrTeteListe, funcList *ptrFunc, funcSublist *funcSL)
{
    LIST *ptr = (*ptrTeteListe);
    FILE *f;
    LIST *next = NULL;

    remove(file->fileName);

    f = fopen(file->fileName, "wt");

    if( f != NULL)
    {
        writeHeadLineCSV(f, file);
        while ( ptr != NULL)
        {
            writeLineCSV(f, &ptr, ptrFunc, file);
            LIST_getNexMaillon(&next, ptr, ptrFunc);
            (*(ptrFunc->freeDescription)[ptr->type])(&ptr);
            (*(ptrFunc->freeMaillon)[ptr->type])(&ptr, funcSL);
            ptr = next;
        }    
    }
    fclose(f);
    (*ptrTeteListe) = ptr;
}