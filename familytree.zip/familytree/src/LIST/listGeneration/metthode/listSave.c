#include <stdio.h>
#include <stdlib.h>

#include "../../../../include/LIST/structure.h"
#include "../../../../include/LIST/library/file/file_writeCSV.h"
#include "../../../../include/LIST/list/list.h"
#include "../../../../include/LIST/listGeneration/methode/listSave.h"


void saveListInCSV(dataFile *file, LIST **ptrTeteListe, funcList *ptrFunc)
{
    LIST *ptr = (*ptrTeteListe);
    FILE *f;

    remove(file->fileName);

    f = fopen(file->fileName, "wt");

    if( f != NULL)
    {
        writeHeadLineCSV(f, file);
        while ( ptr != NULL)
        {
            writeLineCSV(f, &ptr, ptrFunc, file);

            LIST_getNexMaillon(&ptr, ptr, ptrFunc);
        }    
    }
    fclose(f);
}
