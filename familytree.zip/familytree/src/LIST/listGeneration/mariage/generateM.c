#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "../../../../include/LIST/structure.h"

#include "../../../../include/LIST/library/file/file_readCSV.h"
#include "../../../../include/LIST/library/file/file_writeCSV.h"
#include "../../../../include/LIST/library/allocation/free.h"
#include "../../../../include/LIST/list/list.h"
#include "../../../../include/LIST/list/mariage/mariageL.h"
#include "../../../../include/LIST/list/individu/individuL.h"

#include "../../../../include/LIST/listGeneration/mariage/generateM.h"

LIST* initialiseListMariage(FILE *f, dataFile *file, int nowNbLine, LIST **ptrI_teteListe, type_list type, funcList *func)
{
    if(nowNbLine == file->nb_row)
        return NULL;
    else
    {
        char **data = NULL;

        LIST *ptr_teteListe = NULL;

        data = readLineCSV(f, file, ";");
        nowNbLine++;

        ptr_teteListe = initialiseListMariage(f, file, nowNbLine, ptrI_teteListe, type, func);

        LIST *ptrMaillon = NULL;

        LIST_creatMaillon(&ptrMaillon, type, func);
        LIST_insertData(&ptrMaillon, data, func);
        LIST_insertMaillon(ptrMaillon, &ptr_teteListe, func);

        LISTMARIAGE_creationLink(ptrMaillon, ptrI_teteListe, data, 0, 1, 2, 3, 4, 1);

        LISTMARIAGE_creationLink(ptrMaillon, ptrI_teteListe, data, 5, 6, 7, 8, 9, 2);        

        free_charDoubleDim(&data, file->nb_column);

        return ptr_teteListe;
    }
}

void LISTMARIAGE_generationListe(dataFile **file, LIST **ptrTeteListe, LIST **ptrI_teteListe, type_list type, funcList *func)
{
    FILE *f;
    LIST *ptrM_teteListe = NULL;
    int nbLine = 0;

    f = fopen((*file)->fileName, "rt");

    if( f != NULL)
    {
        readHeaderLineCSV(f, file, ";");
        ptrM_teteListe = initialiseListMariage(f,  *file, nbLine,  ptrI_teteListe, type, func);
    }
    fclose(f);
    (*ptrTeteListe) = ptrM_teteListe;
}