#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "../../../../include/LIST/structure.h"
#include "../../../../include/LIST/list/list.h"
#include "../../../../include/LIST/library/file/file_writeCSV.h"
#include "../../../../include/LIST/library/file/file_readCSV.h"
#include "../../../../include/LIST/library/allocation/free.h"
#include "../../../../include/LIST/list/individu/individuL.h"

#include "../../../../include/LIST/listGeneration/individu/generateI.h"

LIST* initialiseListIndividu(FILE *f, dataFile *file, int nowNbLine, const type_list type, funcList *func)
{
    if(nowNbLine == file->nb_row)
        return NULL;
    else
    {
        char **data = NULL;
        LIST *ptr_teteListe = NULL;

        data = readLineCSV(f, file, ";");
        nowNbLine++;

        ptr_teteListe = initialiseListIndividu(f, file, nowNbLine, type, func);
        
        LIST *ptrMaillon = NULL;

        LIST_creatMaillon(&ptrMaillon, type, func);
        LIST_insertData(&ptrMaillon, data, func);
        LIST_insertMaillon(ptrMaillon, &ptr_teteListe, func);

        LISTINDIVIDU_creatLinkParent(ptrMaillon, &ptr_teteListe, data, 8, 9, 1);
        LISTINDIVIDU_creatLinkParent(ptrMaillon, &ptr_teteListe, data, 10, 11, 2);

        free_charDoubleDim(&data, file->nb_column);

        return ptr_teteListe;
    }
}

void LISTINDIVIDU_generationListe(LIST **ptrTeteListe, dataFile **file, type_list type, funcList *ptrFunc)
{
    FILE *f;
    LIST *ptrI_teteListe = NULL;
    int nbLine = 0;

    f = fopen((*file)->fileName, "rt");

    if( f != NULL)
    {
        readHeaderLineCSV(f, file, ";");
        ptrI_teteListe = initialiseListIndividu(f, *file, nbLine, type, ptrFunc);
    }
    fclose(f);

    (*ptrTeteListe) = ptrI_teteListe;
}