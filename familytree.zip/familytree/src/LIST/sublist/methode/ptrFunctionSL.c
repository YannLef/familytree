#include <stdio.h>
#include <stdlib.h>

#include "../../../../include/LIST/structure.h"
#include "../../../../include/LIST/sublist/sublist.h"

#include "../../../../include/LIST/sublist/individu/individuSL.h"
#include "../../../../include/LIST/sublist/mariage/mariageSL.h"

#include "../../../../include/LIST/sublist/methode/deleteSL.h"

#include "../../../../include/LIST/sublist/methode/ptrFunctionSL.h"

void SUBLIST_ptrFunctionInddividu(funcSublist **ptr)
{
    (*ptr)->tabSublistType[type_sublistIndividu] = &SUBLISTINDIVIDU_creatMaillon;
    (*ptr)->tabInsertData[type_sublistIndividu] = &SUBLISTINDIVIDU_insertData;
    (*ptr)->tabInsertMaillon[type_sublistIndividu] = &SUBLISTINDIVIDU_insertMaillon;
    (*ptr)->tabFreeMaillon[type_sublistIndividu] = &SUBLISTINDIVIDU_freeMaillon;
    (*ptr)->getNextMaillon[type_sublistIndividu] = &SUBLISTINDIVIDU_getNextMaillon;
}

void SUBLIST_ptrFunctionMariage(funcSublist **ptr)
{
    (*ptr)->tabSublistType[type_sublistMariage] = &SUBLISTMARIAGE_creatMaillon;
    (*ptr)->tabInsertData[type_sublistMariage] = &SUBLISTMARIAGE_insertData;
    (*ptr)->tabInsertMaillon[type_sublistMariage]= &SUBLISTMARIAGE_insertMaillon;
    (*ptr)->tabFreeMaillon[type_sublistMariage] = &SUBLISTMARIAGE_freeMaillon;
    (*ptr)->getNextMaillon[type_sublistMariage] = &SUBLISTMARIAGE_getNextMaillon;
}