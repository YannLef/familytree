#include <stdio.h>
#include <stdlib.h>

#include "../../../../include/LIST/structure.h"
#include "../../../../include/LIST/sublist/sublist.h"
#include "../../../../include/LIST/sublist/mariage/mariageSL.h"
#include "../../../../include/LIST/sublist/individu/individuSL.h"

#include "../../../../include/LIST/sublist/methode/deleteSL.h"

void SUBLIST_deleteAll(SUBLIST **ptrMaillon, funcSublist *ptrFunc_subList)
{
    SUBLIST *ptr = (*ptrMaillon);
    SUBLIST *next = NULL;
    
    while( ptr != NULL)
    {
        (*(ptrFunc_subList->getNextMaillon)[ptr->type])(&next, ptr);
        SUBLIST_free(&ptr, ptrFunc_subList);
        ptr = next;
    }
    (*ptrMaillon) = ptr;
}