#include <stdio.h>
#include <stdlib.h>

#include "../../../include/LIST/structure.h"

#include "../../../include/LIST/sublist/methode/ptrFunctionSL.h"

#include "../../../include/LIST/sublist/sublist.h"

void SUBLIST_create(SUBLIST **ptrMaillon, type_sublist sublistType, funcSublist *ptrFunc_subList)
{
    SUBLIST *ptr = NULL;

    ptr = (SUBLIST*)malloc(sizeof(SUBLIST));

    if( ptr != NULL)
    {
        #ifdef VERBOSE
            printf("[SUBLIST] malloc sizeof -> %ld | %p\n",sizeof(SUBLIST), ptr);
        #endif
        ptr->type = sublistType;
        (*(ptrFunc_subList->tabSublistType)[ptr->type])(&ptr);
    }

    (*ptrMaillon) = ptr;
}

void SUBLIST_insertData(SUBLIST **ptr, LIST *ptrMaillon_I, funcSublist *ptrFunc_subList)
{
    (*(ptrFunc_subList->tabInsertData[(*ptr)->type]))(ptr, ptrMaillon_I);
}

void SUBLIST_insertMaillon(SUBLIST **ptr, LIST **individuParent, funcSublist *ptrFunc_subList)
{
    (*(ptrFunc_subList->tabInsertMaillon[(*ptr)->type]))(*ptr, individuParent);
}

void SUBLIST_free(SUBLIST **ptrMaillon, funcSublist *ptrFunc_subList)
{
    (*(ptrFunc_subList->tabFreeMaillon)[(*ptrMaillon)->type])(ptrMaillon);

    if( (*ptrMaillon) != NULL)
    {
        #ifdef VERBOSE
            printf("[SUBLIST] free sizeof -> %ld | %p | ",sizeof((*ptrMaillon)), (*ptrMaillon));
        #endif
        free((*ptrMaillon));
        (*ptrMaillon) = NULL;
        #ifdef VERBOSE
            if( (*ptrMaillon) == NULL)
                printf("free\n");
            else
                printf("not free\n");
        #endif
    }
}

void SUBLIST_pointeurFunction(funcSublist **ptrFunction)
{
    funcSublist *ptr = NULL;
    ptr = (funcSublist*)malloc(sizeof(funcSublist) * NB_POINTEURFUNCTION);
    if( ptr != NULL)
    {
        #ifdef VERBOSE
            printf("[FuncSUBLIST] malloc sizeof -> %ld | %p\n",sizeof(funcSublist), ptr);
        #endif
        SUBLIST_ptrFunctionInddividu(&ptr);
        SUBLIST_ptrFunctionMariage(&ptr);
    }

    (*ptrFunction) = ptr;
}

void SUBLIST_freePointeurFunction(funcSublist **ptrFunction)
{
    if( (*ptrFunction) != NULL)
    {
        free((*ptrFunction));
        (*ptrFunction) = NULL;
    }
}