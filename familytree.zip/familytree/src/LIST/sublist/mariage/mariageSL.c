#include <stdio.h>
#include <stdlib.h>

#include "../../../../include/LIST/structure.h"
#include "../../../../include/LIST/sublist/mariage/methode/searchMaillonSL.h"
#include "../../../../include/LIST/sublist/mariage/mariageSL.h"

void SUBLISTMARIAGE_create(SUBLIST **ptrMaillon)
{
    SUBLIST *ptr = NULL;

    ptr = (SUBLIST*)malloc(sizeof(SUBLIST));
    #ifdef VERBOSE
        printf("\t[SUBLIST] malloc sizeof -> %ld | %p\n",sizeof(SUBLIST), ptr);
    #endif
    if( ptr != NULL)
    {
        ptr->type = type_sublistMariage;

        ptr->u.sublist_M = (sublist_mariage*)malloc(sizeof(sublist_mariage));

        if( ptr->u.sublist_M != NULL)
        {
            #ifdef VERBOSE
                printf("\t\t[sublist_mariage] malloc sizeof -> %ld | %p\n",sizeof(sublist_mariage), ptr->u.sublist_M);
            #endif
            ptr->u.sublist_M->mariage = NULL;
            ptr->u.sublist_M->suivant = NULL;
            
            (*ptrMaillon) = ptr;
        }
    }
}

void SUBLISTMARIAGE_creatMaillon(SUBLIST **ptrMaillon)
{
    sublist_mariage *ptr = NULL;

    ptr = (sublist_mariage*)malloc(sizeof(sublist_mariage));

    if( ptr != NULL)
    {
        #ifdef VERBOSE
            printf("\t[sublist_mariage] malloc sizeof -> %ld | %p\n",sizeof(sublist_mariage), ptr);
        #endif
        ptr->mariage = NULL;
        ptr->suivant = NULL;
        (*ptrMaillon)->u.sublist_M = ptr;
    }
}

void SUBLISTMARIAGE_freeMaillon(SUBLIST **ptrMaillon)
{
    sublist_mariage *ptr = (*ptrMaillon)->u.sublist_M;

    ptr->mariage = NULL;
    ptr->suivant = NULL;

    if( (ptr) != NULL)
    {
        #ifdef VERBOSE
            printf("[SUBLIST_M] free sizeof -> %ld | %p | ",sizeof((ptr)), (ptr));
        #endif
        free((ptr));
        (ptr) = NULL;
        #ifdef VERBOSE
            if( (ptr) == NULL)
                printf("free\n");
            else
                printf("not free\n");
        #endif
    }

    (*ptrMaillon)->u.sublist_M = ptr;
}

void SUBLISTMARIAGE_insertData(SUBLIST **ptrMaillon, LIST *ptr_mariage)
{
    (*ptrMaillon)->u.sublist_M->mariage = ptr_mariage;
}

void SUBLISTMARIAGE_insertMaillon(SUBLIST *insert, LIST **ptrI_teteListe)
{
    insert->u.sublist_M->suivant = (*ptrI_teteListe)->u.list_individu->sublistMariage;
    (*ptrI_teteListe)->u.list_individu->sublistMariage = insert;
}

void SUBLISTMARAIGE_deleteMaillon(SUBLIST **ptrHead, SUBLIST **maillonDelete, LIST *mariage)
{
    SUBLIST *precedent = NULL;

    SUBLISTMARIAGE_searchMaillon((*ptrHead), mariage, &precedent, maillonDelete);

    if( precedent == NULL)
        (*ptrHead) = (*maillonDelete)->u.sublist_M->suivant;
    else
        precedent->u.sublist_M->suivant = (*maillonDelete)->u.sublist_M->suivant;

    (*maillonDelete)->u.sublist_M->suivant = NULL;
}


void SUBLISTMARIAGE_getNextMaillon(SUBLIST **nextMaillon, SUBLIST *ptrMaillon)
{
    (*nextMaillon) = ptrMaillon->u.sublist_M->suivant;
}