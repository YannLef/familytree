#include <stdio.h>
#include <stdlib.h>

#include "../../../../../include/LIST/structure.h"
#include "../../../../../include/LIST/sublist/mariage/methode/searchMaillonSL.h"

void SUBLISTMARIAGE_searchMaillon(SUBLIST *ptrHead, LIST *maillon, SUBLIST **precedent, SUBLIST **delete)
{
    SUBLIST *ptr = ptrHead;
    SUBLIST *before = NULL;
    
    while( ptr != NULL)
    {
        if( ptr->u.sublist_M->mariage == maillon )
            break;

        before = ptr;
        ptr = ptr->u.sublist_M->suivant;
    }

    (*precedent) = before;
    (*delete) = ptr;
}