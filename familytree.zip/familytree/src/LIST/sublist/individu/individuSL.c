#include <stdio.h>
#include <stdlib.h>

#include "../../../../include/LIST/structure.h"
#include "../../../../include/LIST/sublist/individu/methode/searchMaillonSL.h"
#include "../../../../include/LIST/sublist/individu/individuSL.h"

void SUBLISTINDIVIDU_create(SUBLIST **ptrMaillon)
{
    SUBLIST *ptr = NULL;

    ptr = (SUBLIST*)malloc(sizeof(SUBLIST));

    if( ptr != NULL)
    {
        #ifdef VERBOSE
            printf("\t[SUBLIST] malloc sizeof -> %ld | %p\n",sizeof(SUBLIST), ptr);
        #endif
        ptr->type = type_sublistIndividu;

        ptr->u.sublist_I = (sublist_individu*)malloc(sizeof(sublist_individu));

        if( ptr->u.sublist_I != NULL)
        {
            #ifdef VERBOSE
                printf("\t\t[sublist_individu] malloc sizeof -> %ld | %p\n",sizeof(sublist_individu), ptr->u.sublist_I);
            #endif
            ptr->u.sublist_I->individu = NULL;
            ptr->u.sublist_I->suivant = NULL;
            
            (*ptrMaillon) = ptr;
        }
    }
}

void SUBLISTINDIVIDU_creatMaillon(SUBLIST **ptrMaillon)
{
    sublist_individu *ptr = NULL;

    ptr = (sublist_individu*)malloc(sizeof(sublist_individu));

    if( ptr != NULL)
    {
        #ifdef VERBOSE
            printf("\t[sublist_individu] malloc sizeof -> %ld | %p\n",sizeof(sublist_individu), ptr);
        #endif
        ptr->individu = NULL;
        ptr->suivant = NULL;
        (*ptrMaillon)->u.sublist_I = ptr;
    }
}

void SUBLISTINDIVIDU_insertData(SUBLIST **ptrMaillon, LIST *ptr_individu)
{
    (*ptrMaillon)->u.sublist_I->individu = ptr_individu;
}

void SUBLISTINDIVIDU_insertMaillon(SUBLIST *insert, LIST **ptrI_teteListe)
{
    insert->u.sublist_I->suivant = (*ptrI_teteListe)->u.list_individu->sublistIndividu;
    (*ptrI_teteListe)->u.list_individu->sublistIndividu = insert;
}

void SUBLISTINDIVIDU_insertMaillonSubList(SUBLIST **insert, SUBLIST **ptrHead)
{
    (*insert)->u.sublist_I->suivant = (*ptrHead);  
    (*ptrHead) = (*insert);
}

void SUBLICTINDIVIDU_delateMaillon(SUBLIST **ptrHead, SUBLIST **maillonDelete, LIST *individu)
{
    SUBLIST *precedent = NULL;

    SUBLISTINDIVIDU_searchMaillonIndividu((*ptrHead), individu, &precedent, maillonDelete);

    if( precedent == NULL)
        (*ptrHead) = (*maillonDelete)->u.sublist_I->suivant;
    else
        precedent->u.sublist_I->suivant = (*maillonDelete)->u.sublist_I->suivant;

    (*maillonDelete)->u.sublist_I->suivant = NULL;
}

void SUBLISTINDIVIDU_freeMaillon(SUBLIST **ptrMaillon)
{
    sublist_individu *ptr = (*ptrMaillon)->u.sublist_I;

    ptr->individu = NULL;
    ptr->suivant = NULL;

    if( (ptr) != NULL)
    {
        #ifdef VERBOSE
            printf("[SUBLIST_I] free sizeof -> %ld | %p | ",sizeof((ptr)), (ptr));
        #endif
        free((ptr));
        (ptr) = NULL;
        #ifdef VERBOSE
            if( (ptr) == NULL)
                printf("free\n");
            else
                printf("not free\n");
        #endif
    }

    (*ptrMaillon)->u.sublist_I = ptr;
}

void SUBLISTINDIVIDU_getNextMaillon(SUBLIST **nextMaillon, SUBLIST *ptrMaillon)
{
    (*nextMaillon) = ptrMaillon->u.sublist_I->suivant;
}