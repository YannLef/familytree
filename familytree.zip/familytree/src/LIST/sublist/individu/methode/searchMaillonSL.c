#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../../../../include/LIST/structure.h"
#include "../../../../../include/LIST/sublist/individu/methode/searchMaillonSL.h"

/*
    Permet de retrouver l'adresse du maillon en sublist en question que nous allons retirer
*/

void SUBLISTINDIVIDU_searchMaillonIndividu(SUBLIST *ptrHead, LIST *maillon, SUBLIST **precedent, SUBLIST **delete)
{
    SUBLIST *ptr = ptrHead;
    SUBLIST *before = NULL;

    while( ptr != NULL)
    {
        if( ptr->u.sublist_I->individu == maillon)
            break;

        before = ptr;
        ptr = ptr->u.sublist_I->suivant;
    }
    
    (*precedent) = before;
    (*delete) = ptr;
}