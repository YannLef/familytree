#include <stdio.h>
#include <stdlib.h>

#include "../../../../include/LIST/library/allocation/free.h"

void free_charDoubleDim(char ***d, const int nbCol)
{
    int i;

    for( i = 0; i < nbCol ; i++)
    {
        free((*d)[i]);
        (*d)[i] = NULL;
    }

    free((*d));
    (*d) = NULL;

}

void free_char(char **chaine)
{
    free((*chaine));
    (*chaine) = NULL;
}