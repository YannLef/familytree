#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../../../include/LIST/structure.h"
#include "../../../../include/LIST/library/string/str.h"
#include "../../../../include/LIST/library/string/str_split.h"

void str_getmDataFile(dataFile **file, char *chaine, char *catactere)
{
    int indice = 0;
    char *begin, *end;
    size_t longueur;

    begin = end = chaine;

    while(1)
    {
        if( *end == *catactere && indice == 0)
        {
            if (end == begin )
            {
                (*file)->nb_row = 0;
                indice++;
                begin = end = (end + 1);
            }
            else if(end > begin)
            {
                longueur = end - begin;
                (*file)->nb_row = atoi(str_memcpy(begin,longueur));
                begin = end = (end + 1);
                indice++;
            }
        }
        else if( *end == *catactere)
        {
            indice++;
            end++;
        }
        else if (*end == '\0')
        {   
            if (*(end - 1) == *catactere)
            {
                longueur = end - begin;
                (*file)->headerFile  = str_memcpy(begin,longueur);
                indice++;
                break;
            }
            else if( *(end -1) != *catactere)
            {
                longueur = end - begin;
                (*file)->headerFile = str_memcpy(begin,longueur);
                indice++; 
                break;         
            }
        }
        else
            end++;
    }
    (*file)->nb_column = indice;
}

char** str_splitChaine(const int nb_col, char *chaine, char *caractere)
{
    char **data = (char**)malloc(sizeof(char*) * nb_col);
    int indice = 0;
    char *begin, *end;
    char *chaineEnd = (chaine +  strlen(chaine));
    size_t longueur;

    begin = end = chaine;

    while( indice < nb_col)
    {
        if( *end == *caractere)
        {
            if( end == begin)
            {
                data[indice] = NULL;
                indice++;
                begin = end = (end + 1);
            }
            else if( end > begin)
            {
                if( *(end - 1) == *caractere)
                {
                    data[indice] = NULL;
                    indice++;
                    begin = end = (end + 1);
                }
                else
                {
                    longueur = end - begin;
                    data[indice] = str_memcpy(begin,longueur);
                    indice++;  
                    begin = end = (end + 1);
                }
            }
        }
        else if( end == chaineEnd)
        {
            if (*(end - 1) == *caractere)
            {
                data[indice] = NULL;
                indice++;
            }
            else if( *(end -1) != *caractere)
            {
                longueur = end - begin;
                data[indice] = str_memcpy(begin,longueur);
                indice++;  
            }
        }
        else
            end++;     
    }
    return data;
}
