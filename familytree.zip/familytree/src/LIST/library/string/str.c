#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "../../../../include/LIST/library/string/str.h"

void convertCharMinuscule(char *caracetre)
{
    if( ( (*caracetre) >= 'A') && ( (*caracetre) <= 'Z'))
        (*caracetre) = (*caracetre) | 0x20;
}

char* str_memcpy(char *begin, const size_t size_char)
{
    char *chaine = (char*)malloc(sizeof(char) * (size_char + 1));
    int i;
    char c[2];
    for( i = 0 ; i < size_char ; i++)
    {
        convertCharMinuscule((begin + i));
        sprintf(c,"%c", *(begin + i));  
        
        if( i == 0)
            strcpy(chaine, c);
        else
            strcat(chaine, c);
    }
    return chaine;
}

char* str_modifyChaine(char *chaine)
{
    size_t longueur = 0, longueurChaine = strlen(chaine);
    int i;

    for( i = 0; i < longueurChaine ; i++)
    {
        if( *(chaine + i) == EOF)
            break;
        if( *(chaine + i) == '\n')
            break;
        if( *(chaine + i) == '\0')
            break;
        longueur++;
    }
    return str_memcpy(chaine, longueur);   
}