#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../../../include/LIST/structure.h"

#include "../../../../include/LIST/library/string/str.h"

#include "../../../../include/LIST/library/string/str_createLineCSV.h"

char* str_creatLineCSV(char **data, dataFile *ptr)
{
    int longueur = 0;
    char *chaine = NULL;
    int i;
    
    for( i = 1; i < ptr->nb_column ; i++)
        if( data[i] != NULL)
            longueur += strlen(data[i]);

    longueur = longueur + ptr->nb_column;

    chaine = (char*)malloc(sizeof(char) * (longueur + 1));

    strcpy(chaine, data[0]);

    for( i = 1; i < ptr->nb_column ; i++)
    {
        strcat(chaine,";");
        if( data[i] != NULL)
            strcat(chaine, data[i]);
    }
    return chaine;    
}