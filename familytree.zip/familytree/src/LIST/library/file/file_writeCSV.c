#include <stdio.h>
#include <stdlib.h>
#include "string.h"

#include "../../../../include/LIST/structure.h"
#include "../../../../include/LIST/list/list.h"

#include "../../../../include/LIST/library/allocation/free.h"
#include "../../../../include/LIST/library/string/str_createLineCSV.h"

#include "../../../../include/LIST/library/file/file_writeCSV.h"

void writeLineCSV(FILE *f,LIST **ptrMaillon, funcList *ptrfunc, dataFile *file)
{
    char **data = NULL;
    char *chaine = NULL;
    LIST_getCharData(&data, (*ptrMaillon), ptrfunc, file);
    
    chaine = str_creatLineCSV(data, file);
    
    fprintf(f, "%s\n",chaine);

    free(chaine);
    chaine = NULL;
    
    free_charDoubleDim(&data, file->nb_column);
}

void writeLastLineCSV(FILE *f,LIST **ptrMaillon, funcList *ptrfunc, dataFile *file)
{
    char **data = NULL;
    char *chaine = NULL;
    LIST_getCharData(&data, *ptrMaillon, ptrfunc, file);
    chaine = str_creatLineCSV(data, file);
    
    fprintf(f, "%s",chaine);

    free(chaine);
    chaine = NULL;

    free_charDoubleDim(&data, file->nb_column);
}

void writeHeadLineCSV(FILE *f, dataFile *file)
{
    char *chaine = NULL;
    char tmp[10];

    sprintf(tmp, "%d",file->nb_row);

    chaine = (char*)malloc(sizeof(char) * (strlen(tmp) + strlen(file->headerFile) + 2));

    strcpy(chaine, tmp);
    strcat(chaine,";");
    strcat(chaine, file->headerFile);
    
    fprintf(f, "%s\n",chaine);

    free(chaine);
    chaine = NULL;
}