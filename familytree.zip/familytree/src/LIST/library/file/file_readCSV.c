#include <stdio.h>
#include <stdlib.h>

#define CHAR_SIZE 800

#include "../../../../include/LIST/structure.h"
#include "../../../../include/LIST/library/string/str_split.h"
#include "../../../../include/LIST/library/string/str.h"

#include "../../../../include/LIST/library/file/file_readCSV.h"

void readHeaderLineCSV(FILE *f, dataFile **file, char *caractere)
{
    char ch[CHAR_SIZE];
    fgets(ch,CHAR_SIZE,f);
    
    char *chaine = str_modifyChaine(ch);

    str_getmDataFile(file, chaine, caractere);
}

char** readLineCSV(FILE *f, dataFile *file, char *caractere)
{
    char **data = NULL;
    char ch[CHAR_SIZE];

    fgets(ch,CHAR_SIZE,f);
    
    char *chaine = str_modifyChaine(ch);
    data = str_splitChaine(file->nb_column , chaine, caractere);

    return data;
}