#include <stdio.h>
#include <stdlib.h>

#include "../../../../include/LIST/structure.h"
#include "../../../../include/LIST/library/allocation/free.h"
#include "../../../../include/LIST/list/mariage/mariageL.h"
#include "../../../../include/LIST/list/mariage/methode/updateDataM.h"
#include "../../../../include/LIST/list/mariage/methode/displayTerminalM.h"

#include "../../../../include/LIST/updateMaillonList/mariage/updateMariage.h"

void LISTMARIAGE_updateMaillon(LIST **ptrHeadM, LIST **ptrHeadI, LIST *maillon, char ***data, funcSublist *func)
{
    if( maillon != NULL )
    {
        LISTMARIAGE_updateLieuMariage(&maillon, (*data)[lieuMariage]);

        if( (*data)[dateMariage] != NULL)
        {         
            LISTMARAIGE_deleteMaillon(&maillon, ptrHeadM);
            LISTMARIAGE_updateDateMariage(&maillon, (*data)[dateMariage]);
            LISTMARIAGE_insertMaillon(maillon, ptrHeadM);
        }
        LISTMARIAGE_updateConjoint(ptrHeadI, &maillon, (*data), func);
    }
    free_charDoubleDim(data, 12);
}
