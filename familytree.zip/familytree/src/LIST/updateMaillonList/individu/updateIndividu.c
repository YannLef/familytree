#include <stdio.h>
#include <stdlib.h>

#include "../../../../include/LIST/structure.h"
#include "../../../../include/LIST/list/individu/individuL.h"
#include "../../../../include/LIST/list/individu/methode/updateData.h"
#include "../../../../include/LIST/library/allocation/free.h"
#include "../../../../include/LIST/updateMaillonList/individu/updateIndividu.h"
#include "../../../../include/LIST/list/individu/methode/displayTerminalI.h"

void LISTINDIVIDU_updateMaillon(LIST **ptrHead, LIST *maillon, funcSublist *func, char ***data)
{
    if( maillon != NULL)
    {

        LISTINDIVIDU_updateNom(&maillon, (*data)[nomI]);
        LISTINDIVIDU_updatePrenom(&maillon, (*data)[prenomI]);
        LISTINDIVIDU_updateDateNaissance(&maillon, (*data)[naissanceDateI]);
        LISTINDIVIDU_updateLieuNaissance(&maillon, (*data)[naissanceLieuI]);
        LISTINDIVIDU_updateDateDeces(&maillon, (*data)[decesDateI]);
        LISTINDIVIDU_updateLieuDeces(&maillon, (*data)[decesLieuI]);

        if( (*data)[generationI] != NULL)
        {
            //on retire le maillon en question de la liste
            LISTINDIVIDU_deleteMaillon(&maillon, ptrHead);
            //on met a jour la generation
            LISTINDIVIDU_updateGeneration(&maillon, (*data)[generationI]);
            //on insert le maillon au bon endroit
            LISTINDIVIDU_insertMaillon(&maillon, ptrHead);
        }

        LISTINDIVIDU_updateConjoint(ptrHead, &maillon, func, (*data));

    }

    free_charDoubleDim(data, 12);
}