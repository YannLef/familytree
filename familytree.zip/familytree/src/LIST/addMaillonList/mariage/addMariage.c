#include <stdio.h>
#include <stdlib.h>

#include "../../../../include/LIST/structure.h"
#include "../../../../include/LIST/library/allocation/free.h"
#include "../../../../include/LIST/list/list.h"
#include "../../../../include/LIST/list/individu/individuL.h"
#include "../../../../include/LIST/list/mariage/mariageL.h"
#include "../../../../include/LIST/list/mariage/methode/insertDataM.h"
#include "../../../../include/LIST/list/individu/methode/insertDataI.h"
#include "../../../../include/LIST/sublist/sublist.h"

#include "../../../../include/LIST/list/mariage/mariageL.h"

#include "../../../../include/LIST/addMaillonList/mariage/addMariage.h"

void addMariageListMariage(char ***maillonMariage, LIST **ptrHeadM, LIST **ptrHeadI, funcList *func, funcSUBLIST *funcSL)
{
    LIST *maillon = NULL;

    LIST_creatMaillon(&maillon, type_listMariage, func);
    LISTMARIAGE_insertDataLieu(&maillon, (*maillonMariage)[lieuMariage]);
    LISTMARIAGE_insertDataDate(&maillon, (*maillonMariage)[dateMariage]);

    LISTMARIAGE_insertMaillon(maillon, ptrHeadM);

    LISTMARIAGE_creationLink(maillon, ptrHeadI, (*maillonMariage), generation1, nom1, prenom1, naissanceDate1, naissanceLieu1, 1);
    LISTMARIAGE_creationLink(maillon, ptrHeadI, (*maillonMariage), generation2, nom2, prenom2, naissanceDate2, naissanceLieu2, 2);

    free_charDoubleDim(maillonMariage, 12);
    maillon = NULL;
}
