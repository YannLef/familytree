#include <stdio.h>
#include <stdlib.h>

#include "../../../../include/LIST/structure.h"
#include "../../../../include/LIST/library/allocation/free.h"
#include "../../../../include/LIST/list/list.h"
#include "../../../../include/LIST/list/individu/individuL.h"
#include "../../../../include/LIST/list/individu/methode/insertDataI.h"

#include "../../../../include/LIST/addMaillonList/individu/addIndividu.h"

void addIndividuListIndividu(char ***dataIndividu, LIST **ptrHead, funcList *func)
{
    LIST *maillon = NULL;

    LIST_creatMaillon(&maillon, type_listIndividu, func);

    LISTINDIVIDU_insertGeneration(&maillon, (*dataIndividu)[generationI]);
    LISTINDIVIDU_insertNom(&maillon , (*dataIndividu)[nomI]);
    LISTINDIVIDU_insertPrenom(&maillon, (*dataIndividu)[prenomI]);
    LISTINDIVIDU_insertGenre(&maillon, (*dataIndividu)[genreI]);
    LISTINDIVIDU_insertDateNaissance(&maillon, (*dataIndividu)[naissanceDateI]);
    LISTINDIVIDU_insertLieuNaissance(&maillon, (*dataIndividu)[naissanceLieuI]);
    LISTINDIVIDU_insertDateDeces(&maillon, (*dataIndividu)[decesDateI]);
    LISTINDIVIDU_insertLieuDeces(&maillon, (*dataIndividu)[decesDateI]);
    
    LISTINDIVIDU_insertMaillon(&maillon, ptrHead);

    LISTINDIVIDU_creatLinkParent(maillon, &maillon, (*dataIndividu), nomParent1I, prenomParent1I, 1);
    LISTINDIVIDU_creatLinkParent(maillon, &maillon, (*dataIndividu), nomParent2I, prenomParent2I, 2);
    
    free_charDoubleDim(dataIndividu, 12);
    maillon = NULL;
}