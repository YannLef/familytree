#include <stdio.h>
#include <stdlib.h>

#include "../../../include/LIST/structure.h"

#include "../../../include/LIST/dataTree/dataTree.h"

dataFile* DATAFILE_create(void)
{
    dataFile *ptr = NULL;

    ptr = (dataFile*)malloc(sizeof(dataFile));
    
    if( ptr != NULL)
    {
        ptr->fileName = NULL;
        ptr->nb_column = 0;
        ptr->nb_row = 0;
        ptr->headerFile = NULL;
    }
    return ptr;
}