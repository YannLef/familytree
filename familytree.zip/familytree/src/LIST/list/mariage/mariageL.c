#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../../../include/LIST/structure.h"

#include "../../../../include/LIST/list/mariage/methode/insertDataM.h"

#include "../../../../include/LIST/list/individu/methode/searchMaillonI.h"
#include "../../../../include/LIST/list/individu/methode/insertDataI.h"
#include "../../../../include/LIST/list/individu/individuL.h"

#include "../../../../include/LIST/sublist/mariage/mariageSL.h"

#include "../../../../include/LIST/list/mariage/methode/searchMaillonM.h"

#include "../../../../include/LIST/list/mariage/mariageL.h"

void LISTMARIAGE_createMaillon(LIST **ptrMaillon)
{
    list_mariage *ptr = NULL;

    ptr = (list_mariage*)malloc(sizeof(list_mariage));

    if( ptr != NULL)
    {
        #ifdef VERBOSE
            printf("\t[list_mariage] malloc sizeof -> %ld | %p\n",sizeof(list_mariage), ptr); 
        #endif
        ptr->c1 = NULL;
        ptr->c2 = NULL;
        ptr->data = NULL;
        ptr->suivant = NULL;
        (*ptrMaillon)->u.list_mariage = ptr;
    }
}

void LISTMARIAGE_creatDescription(LIST **ptrMaillon)
{
    list_descriptionMariage *ptr = NULL;

    ptr = (list_descriptionMariage*)malloc(sizeof(list_descriptionMariage));

    if(ptr != NULL)
    {
        #ifdef VERBOSE
            printf("\t\t[list_descriptionMariage] malloc sizeof -> %ld | %p\n",sizeof(list_descriptionMariage), ptr);
        #endif
        ptr->date = (m_date*)malloc(sizeof(m_date));

        if(ptr->date != NULL)
        {
            #ifdef VERBOSE
                printf("\t\t\t[m_date] malloc sizeof -> %ld - %p\n",sizeof(m_date), ptr->date); 
            #endif
            ptr->lieu = NULL;
            (*ptrMaillon)->u.list_mariage->data = ptr;
        }
    }
}

void LISTMARIAGE_insertMaillonHeader(LIST *insert, LIST **ptrTeteList)
{
    insert->u.list_mariage->suivant = (*ptrTeteList);
    (*ptrTeteList) = insert;
}

void LISTMARIAGE_insertData(LIST **ptrMaillon, char **data)
{
    LISTMARIAGE_insertDataDate( ptrMaillon, data[10]);
    LISTMARIAGE_insertDataLieu( ptrMaillon, data[11]);
}

void LISTMARIAGE_insertConjointPtr(LIST **ptrIndividu, LIST *parent, const int nbParent)
{
    if( nbParent == 1)
        (*ptrIndividu)->u.list_mariage->c1 = parent;
    else if( nbParent == 2)
        (*ptrIndividu)->u.list_mariage->c2 = parent;
}

void LISTMARIAGE_creationLink(LIST *ptrMaillon, LIST **ptrHead, char **data, const int generation, const int nom, const int prenom, const int dateNaissance, const int lieuNaissance, const int nbConjoint)
{
    LIST *conjoint = NULL;

    if(data[generation] != NULL && data[nom] != NULL && data[prenom] != NULL)
        LISTINDIVIDU_searchIndividu((*ptrHead), &conjoint, atoi(data[generation]), data[nom], data[prenom]);

    SUBLIST *ptrMaillonSL = NULL;

    if( conjoint != NULL)
    {
        LISTINDIVIDU_insertGeneration(&conjoint, data[generation]);
        LISTINDIVIDU_insertNom(&conjoint, data[nom]);
        LISTINDIVIDU_insertPrenom(&conjoint, data[prenom]);
        LISTINDIVIDU_insertDateNaissance(&conjoint, data[dateNaissance]);
        LISTINDIVIDU_insertLieuNaissance(&conjoint, data[lieuNaissance]);

        LISTMARIAGE_insertConjointPtr(&ptrMaillon, conjoint, nbConjoint);

        SUBLISTMARIAGE_create(&ptrMaillonSL);
        SUBLISTMARIAGE_insertData(&ptrMaillonSL, ptrMaillon);
        SUBLISTMARIAGE_insertMaillon(ptrMaillonSL, &conjoint);
    }
    else if( conjoint == NULL && data[generation] != NULL && data[nom] != NULL && data[prenom] != NULL)
    {
        LISTINDIVIDU_create(&conjoint);
        LISTINDIVIDU_creatDescription(&conjoint);

        LISTINDIVIDU_insertGeneration(&conjoint, data[generation]);
        LISTINDIVIDU_insertNom(&conjoint, data[nom]);
        LISTINDIVIDU_insertPrenom(&conjoint, data[prenom]);
        LISTINDIVIDU_insertDateNaissance(&conjoint, data[dateNaissance]);
        LISTINDIVIDU_insertLieuNaissance(&conjoint, data[lieuNaissance]);
        
        LISTINDIVIDU_insertMaillon(&conjoint, ptrHead);

        LISTMARIAGE_insertConjointPtr(&ptrMaillon, conjoint, nbConjoint);

        SUBLISTMARIAGE_create(&ptrMaillonSL);
        SUBLISTMARIAGE_insertData(&ptrMaillonSL, ptrMaillon);
        SUBLISTMARIAGE_insertMaillon(ptrMaillonSL, &conjoint);
    }
}

void LISTMARIAGE_freeDescription(LIST **ptrMaillon)
{
    list_descriptionMariage *ptr = (*ptrMaillon)->u.list_mariage->data;

    if( ptr->date != NULL)
    {
        #ifdef VERBOSE
            printf("\t\t\t[List_M -> date] free sizeof -> %ld | %p | ",sizeof(ptr->date), ptr->date);
        #endif
        free(ptr->date);
        ptr->date = NULL;
        #ifdef VERBOSE
            if( ptr->date == NULL)
                printf("free\n");
            else
                printf("not free\n");
        #endif
    }

    if( ptr->lieu)
    {
        #ifdef VERBOSE
            printf("\t\t\t[List_M -> lieu] free sizeof -> %ld | %p | ",sizeof(ptr->lieu), ptr->lieu);
        #endif
        free(ptr->lieu);
        ptr->lieu = NULL;
        #ifdef VERBOSE
            if( ptr->lieu == NULL)
                printf("free \n");
            else
                printf("not free\n");
        #endif
    }
    
    if( ptr != NULL)
    {
        #ifdef VERBOSE
            printf("\t\t[Listdescription M] free sizeof -> %ld | %p | ",sizeof(ptr), ptr);
        #endif
        free(ptr);
        ptr = NULL;
        #ifdef VERBOSE
            if( ptr == NULL)
                printf("free\n");
            else
                printf("not free\n");
        #endif
    }
    (*ptrMaillon)->u.list_mariage->data = ptr;
    #ifdef VERBOSE
        printf("Liste deciption M >>>> %ld | %p\n",sizeof(ptr), ptr);
    #endif
}

void LISTMARIAGE_insertMaillon(LIST *insert, LIST **ptrTeteList)
{
    LIST *precedent = NULL;

    LISTMARIAGE_searchMaillonSetDateMariage((*ptrTeteList), &precedent, insert);

    if( precedent == NULL)
    {
        insert->u.list_mariage->suivant = (*ptrTeteList);
        (*ptrTeteList) = insert;
    }
    else
    {
        insert->u.list_mariage->suivant = precedent->u.list_mariage->suivant;
        precedent->u.list_mariage->suivant = insert;
    }
}

void LISTMARAIGE_deleteMaillon(LIST **delete, LIST **ptrHead)
{
    LIST *precedent = NULL;

    LISTMARIAGE_searchMaillonDateMariage((*ptrHead), &precedent, (*delete));

    if( precedent == NULL)
        (*ptrHead) = (*delete)->u.list_mariage->suivant;
    else
        precedent->u.list_mariage->suivant = (*delete)->u.list_mariage->suivant;

    (*delete)->u.list_mariage->suivant = NULL;
}

void LISTMARIAGE_freeMaillon(LIST **ptrMaillon, funcSublist *func_SUBLIST)
{
    list_mariage *ptr = (*ptrMaillon)->u.list_mariage;

    ptr->c1 = NULL;
    ptr->c2 = NULL;
    ptr->data = NULL;
    ptr->suivant = NULL;

    if( ptr != NULL)
    {
        #ifdef VERBOSE
            printf("\t[List Mariage] free sizeof -> %ld | %p | ",sizeof(ptr), ptr);
        #endif
        free(ptr);
        ptr = NULL;
        #ifdef VERBOSE
            if( ptr == NULL)
                printf("free\n");
            else
                printf("not free\n");
        #endif
    }

    (*ptrMaillon)->u.list_mariage = ptr;

    if( (*ptrMaillon) != NULL)
    {
        #ifdef VERBOSE
            printf("[LIST] free sizeof -> %ld | %p | ",sizeof((*ptrMaillon)), (*ptrMaillon));
        #endif
        free((*ptrMaillon));
        (*ptrMaillon) = NULL;
        #ifdef VERBOSE
            if( (*ptrMaillon) == NULL)
                printf("free\n");
            else
                printf("not free\n");
        #endif
    }
    #ifdef VERBOSE
        printf("LIST >>>> %ld | %p\n",sizeof((*ptrMaillon)), (*ptrMaillon));
    #endif
}

void LISTMARIAGE_getNextMaillon(LIST **next, LIST *ptrMaillon)
{
    (*next) = ptrMaillon->u.list_mariage->suivant;
}