#include <stdio.h>
#include <stdlib.h>

#include "../../../../../include/LIST/structure.h"

#include "../../../../../include/LIST/list/mariage/methode/displayTerminalM.h"

void displayListMariage(LIST *ptrTete)
{
    LIST *ptr = ptrTete;

    int i = 0;

    while( ptr != NULL)
    {
        printf("\t\t[Mariage] -> %d\n",i);
        printf("\t\tLieu -> %s\n",ptr->u.list_mariage->data->lieu);
        if(ptr->u.list_mariage->data->date != NULL)
            printf("\t\tDate -> %d/%d/%d\n",ptr->u.list_mariage->data->date->jour, ptr->u.list_mariage->data->date->moi,
            ptr->u.list_mariage->data->date->annee);
        else
            printf("\t\tDate -> ?\n");
        
        printf("\t\t[Conjoint 1]\n");
        printf("\t\t\tNom -> %s\n", ptr->u.list_mariage->c1->u.list_individu->data->nom);
        printf("\t\t\tPrenom -> %s\n", ptr->u.list_mariage->c1->u.list_individu->data->prenom);
        printf("\t\t\tlieu Naissane -> %s\n", ptr->u.list_mariage->c1->u.list_individu->data->lieuNaissance);
        if(ptr->u.list_mariage->c1->u.list_individu->data->naissance != NULL)
            printf("\t\t\tDateNaissance -> %d/%d/%d\n",ptr->u.list_mariage->c1->u.list_individu->data->naissance->jour, 
            ptr->u.list_mariage->c1->u.list_individu->data->naissance->moi, ptr->u.list_mariage->c1->u.list_individu->data->naissance->annee);
        else
            printf("\t\tDate -> ?\n");
        printf("\t\t\t\t[Mariage]\n");
        while(ptr->u.list_mariage->c1->u.list_individu->sublistMariage != NULL)
        {
            printf("\t\t\t\tLieu -> %s\n",ptr->u.list_mariage->c1->u.list_individu->sublistMariage->u.sublist_M->mariage->u.list_mariage->data->lieu);
            
            if(ptr->u.list_mariage->c1->u.list_individu->sublistMariage->u.sublist_M->mariage->u.list_mariage->data->date != NULL)
            {
                printf("\t\t\t\tDate -> %d/%d/%d\n",ptr->u.list_mariage->c1->u.list_individu->sublistMariage->u.sublist_M->mariage->u.list_mariage->data->date->jour,
                ptr->u.list_mariage->c1->u.list_individu->sublistMariage->u.sublist_M->mariage->u.list_mariage->data->date->moi, 
                ptr->u.list_mariage->c1->u.list_individu->sublistMariage->u.sublist_M->mariage->u.list_mariage->data->date->annee);
            }
            else
            {
                printf("\t\t\t\tDate -> ?\n");
            }
            
            ptr->u.list_mariage->c1->u.list_individu->sublistMariage = ptr->u.list_mariage->c1->u.list_individu->sublistMariage->u.sublist_M->suivant;
        }
        printf("\t\t[Conjoint 2]\n");
        printf("\t\t\tNom -> %s\n", ptr->u.list_mariage->c2->u.list_individu->data->nom);
        printf("\t\t\tPrenom -> %s\n", ptr->u.list_mariage->c2->u.list_individu->data->prenom);
        printf("\t\t\tlieu Naissane -> %s\n", ptr->u.list_mariage->c2->u.list_individu->data->lieuNaissance);
        if(ptr->u.list_mariage->c2->u.list_individu->data->naissance != NULL)
            printf("\t\t\tDateNaissance -> %d/%d/%d\n",ptr->u.list_mariage->c2->u.list_individu->data->naissance->jour, 
            ptr->u.list_mariage->c2->u.list_individu->data->naissance->moi, 
            ptr->u.list_mariage->c2->u.list_individu->data->naissance->annee);
        else
            printf("\t\tDate -> ?\n");

        printf("\t\t\t\t[Mariage]\n");
        while(ptr->u.list_mariage->c2->u.list_individu->sublistMariage != NULL)
        {
            printf("\t\t\t\tLieu -> %s\n",ptr->u.list_mariage->c2->u.list_individu->sublistMariage->u.sublist_M->mariage->u.list_mariage->data->lieu);
            
            if( ptr->u.list_mariage->c2->u.list_individu->sublistMariage->u.sublist_M->mariage->u.list_mariage->data->date != NULL)
            {
                printf("\t\t\t\tDate -> %d/%d/%d\n",ptr->u.list_mariage->c2->u.list_individu->sublistMariage->u.sublist_M->mariage->u.list_mariage->data->date->jour,
                ptr->u.list_mariage->c2->u.list_individu->sublistMariage->u.sublist_M->mariage->u.list_mariage->data->date->moi, 
                ptr->u.list_mariage->c2->u.list_individu->sublistMariage->u.sublist_M->mariage->u.list_mariage->data->date->annee);
            }
            else
            {
                printf("\t\t\t\tDate -> ?\n");
            }
            
            ptr->u.list_mariage->c2->u.list_individu->sublistMariage = ptr->u.list_mariage->c2->u.list_individu->sublistMariage->u.sublist_M->suivant;
        }
        printf("\n");
        i++;
        ptr = ptr->u.list_mariage->suivant;
    }
}