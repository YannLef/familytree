#include <stdio.h>
#include <stdlib.h>

#include "../../../../../include/LIST/structure.h"
#include "../../../../../include/LIST/list/mariage/methode/searchMaillonM.h"

void LISTMARIAGE_searchMaillonDateMariage(LIST *ptrHead, LIST **precedent, LIST *insert)
{
    LIST *ptr = ptrHead;
    LIST *tmp = NULL;
    m_date *date = NULL;
    m_date *mariage = insert->u.list_mariage->data->date;

    while( ptr != NULL)
    {
        date = ptr->u.list_mariage->data->date;

        if(  mariage->annee == date->annee )
            if( mariage->moi == date->moi )
                if( mariage->jour == date->jour )
                    break;
        date = NULL;
        tmp = ptr;
        ptr = ptr->u.list_mariage->suivant;
    }

    (*precedent) = tmp;
}

void LISTMARIAGE_searchMaillonSetDateMariage(LIST *ptrHead, LIST **precedent, LIST *insert)
{
    LIST *ptr = ptrHead;
    LIST *tmp = NULL;
    m_date *date = NULL;
    m_date *mariage = insert->u.list_mariage->data->date;

    while( ptr != NULL)
    {
        date = ptr->u.list_mariage->data->date;

        if(  mariage->annee <= date->annee )
            if( mariage->moi <= date->moi )
                if( mariage->jour <= date->jour )
                    break;

        tmp = ptr;
        ptr = ptr->u.list_mariage->suivant;
    }

    (*precedent) = tmp;
}
