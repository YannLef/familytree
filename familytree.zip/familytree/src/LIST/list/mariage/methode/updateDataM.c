#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../../../../include/LIST/structure.h"
#include "../../../../../include/LIST/list/mariage/mariageL.h"
#include "../../../../../include/LIST/sublist/mariage/mariageSL.h"
#include "../../../../../include/LIST/library/allocation/free.h"
#include "../../../../../include/LIST/library/string/str_split.h"
#include "../../../../../include/LIST/sublist/sublist.h"
#include "../../../../../include/LIST/sublist/mariage/methode/searchMaillonSL.h"
#include "../../../../../include/LIST/list/mariage/methode/updateDataM.h"

void LISTMARIAGE_updateLieuMariage(LIST **maillon, char *data)
{
    if(data != NULL)
    {
        free( (*maillon)->u.list_mariage->data->lieu);
        (*maillon)->u.list_mariage->data->lieu = NULL;

        (*maillon)->u.list_mariage->data->lieu = (char*)malloc(sizeof(char) * strlen(data));

        if((*maillon)->u.list_mariage->data->lieu != NULL)
            strcpy((*maillon)->u.list_mariage->data->lieu, data);
    }
}

void LISTMARIAGE_updateDateMariage(LIST **maillon, char *data)
{
    char **date = NULL;
    if(data != NULL)
    {
        date = str_splitChaine(3, data, "/");
        if( date[0] != NULL)
            (*maillon)->u.list_mariage->data->date->jour = atoi(date[0]);
        else
            (*maillon)->u.list_mariage->data->date->jour = 0;

        if( date[1] != NULL)
            (*maillon)->u.list_mariage->data->date->moi = atoi(date[1]);
        else
            (*maillon)->u.list_mariage->data->date->moi = 0;
        
        if( date[2] != NULL)
            (*maillon)->u.list_mariage->data->date->annee = atoi(date[2]);
        else
            (*maillon)->u.list_mariage->data->date->annee = 0;

        free_charDoubleDim(&date, 3); 
    }
    else
        (*maillon)->u.list_mariage->data->date = NULL;
}

void LISTMARIAGE_updateConjoint(LIST **ptrHead, LIST **maillon, char **data, funcSublist *func)
{
    LIST *conjoint = NULL;
    SUBLIST *deleteMaillon = NULL;

    if( data[generation1] != NULL && data[nom1] != NULL && data[prenom1] != NULL)
    {
        conjoint = (*maillon)->u.list_mariage->c1;

        if( conjoint != NULL )
        {
            SUBLIST *tmp = conjoint->u.list_individu->sublistMariage;

            if( tmp != NULL)
            {
                SUBLISTMARAIGE_deleteMaillon(&(tmp), &deleteMaillon, (*maillon));
                SUBLIST_free(&deleteMaillon, func); 
            }   
        }

        LISTMARIAGE_creationLink((*maillon), ptrHead, data, generation1, nom1, prenom1, naissanceDate1, naissanceLieu1, 1);
        conjoint = NULL;
        deleteMaillon = NULL;
    }
    if( data[generation2] != NULL && data[nom2] != NULL && data[prenom2] != NULL)
    {
        conjoint = (*maillon)->u.list_mariage->c2;

        if( conjoint != NULL )
        {
            SUBLIST *tmp = conjoint->u.list_individu->sublistMariage;
            if( tmp != NULL)
            {
                SUBLISTMARAIGE_deleteMaillon(&(tmp), &deleteMaillon, (*maillon));
                SUBLIST_free(&deleteMaillon, func); 
            }
        }
        LISTMARIAGE_creationLink((*maillon), ptrHead, data, generation2, nom2, prenom2, naissanceDate2, naissanceLieu2, 1);
        conjoint = NULL;
        deleteMaillon = NULL;
    }
}