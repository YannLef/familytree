#include <stdio.h>
#include <stdlib.h>

#include "../../../../../include/LIST/structure.h"

#include "../../../../../include/LIST/list/mariage/methode/toolM.h"

int LISTMARIAGE_compteNbMaillon(LIST *ptr)
{
    int compteur = 0;
    LIST *tmp = ptr;
    while( tmp != NULL)
    {
        compteur++;
        tmp = tmp->u.list_mariage->suivant;
    }
    return compteur;
}