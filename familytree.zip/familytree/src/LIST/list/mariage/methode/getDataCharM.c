#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../../../../include/LIST/structure.h"

#include "../../../../../include/LIST/list/mariage/methode/getDataCharM.h"

char* LISTMARIAGE_getDataCharGenerationI(LIST *ptrMaillon)
{
    char tmp[9];
    char *chaine = NULL;

    if( ptrMaillon->u.list_mariage->c1->u.list_individu->data->generation != 0)
    {
        sprintf(tmp, "%d", ptrMaillon->u.list_mariage->c1->u.list_individu->data->generation);
        chaine = (char*)malloc(sizeof(char) * (strlen(tmp) + 1));
        strcpy(chaine, tmp);
    }

    return chaine;
}

char* LISTMARIAGE_getDataCharNomI(LIST *ptrMaillon)
{
    char *chaine = NULL;
    if(ptrMaillon->u.list_mariage->c1->u.list_individu->data->nom != NULL)
    {
        chaine = (char*)malloc(sizeof(char) * (strlen(ptrMaillon->u.list_mariage->c1->u.list_individu->data->nom) + 1));
        strcpy(chaine, ptrMaillon->u.list_mariage->c1->u.list_individu->data->nom);
    }
    return chaine;
}

char* LISTMARIAGE_getDataCharPrenomI(LIST *ptrMaillon)
{
    char *chaine = NULL;
    if(ptrMaillon->u.list_mariage->c1->u.list_individu->data->prenom != NULL)
    {
        chaine = (char*)malloc(sizeof(char) * (strlen(ptrMaillon->u.list_mariage->c1->u.list_individu->data->prenom) + 1));
        strcpy(chaine, ptrMaillon->u.list_mariage->c1->u.list_individu->data->prenom);
    }
    return chaine;
}

char* LISTMARIAGE_getDataCharDateNaissanceI(LIST *ptrMaillon)
{
    char tmp[11];
    char *chaine = NULL;

    if(ptrMaillon->u.list_mariage->c1->u.list_individu->data->naissance != NULL)
    {
        sprintf(tmp, "%d/%d/%d",ptrMaillon->u.list_mariage->c1->u.list_individu->data->naissance->jour, ptrMaillon->u.list_mariage->c1->u.list_individu->data->naissance->moi, ptrMaillon->u.list_mariage->c1->u.list_individu->data->naissance->annee);
        
        chaine = (char*)malloc(sizeof(char) * (strlen(tmp) + 1));

        strcpy(chaine, tmp);
    }
    return chaine;
}

char* LISTMARIAGE_getDataCharLieuNaissanceI(LIST *ptrMaillon)
{
    char *chaine = NULL;
    if(ptrMaillon->u.list_mariage->c1->u.list_individu->data->lieuNaissance != NULL)
    {
        chaine = (char*)malloc(sizeof(char) * (strlen(ptrMaillon->u.list_mariage->c1->u.list_individu->data->lieuNaissance) + 1));

        strcpy(chaine, ptrMaillon->u.list_mariage->c1->u.list_individu->data->lieuNaissance);
    }

    return chaine;
}

char* LISTMARIAGE_getDataCharGenerationII(LIST *ptrMaillon)
{
    char tmp[9];
    char *chaine = NULL;
    if( ptrMaillon->u.list_mariage->c2->u.list_individu->data->generation != 0)
    {
        sprintf(tmp, "%d", ptrMaillon->u.list_mariage->c2->u.list_individu->data->generation);

        chaine = (char*)malloc(sizeof(char) * (strlen(tmp) + 1));
        strcpy(chaine, tmp);
    }

    return chaine;
}

char* LISTMARIAGE_getDataCharNomII(LIST *ptrMaillon)
{
    char *chaine = NULL;
    if(ptrMaillon->u.list_mariage->c2->u.list_individu->data->nom != NULL)
    {
        chaine = (char*)malloc(sizeof(char) * (strlen(ptrMaillon->u.list_mariage->c2->u.list_individu->data->nom) + 1));

        strcpy(chaine, ptrMaillon->u.list_mariage->c2->u.list_individu->data->nom);
    }

    return chaine;
}

char* LISTMARIAGE_getDataCharPrenomII(LIST *ptrMaillon)
{
    char *chaine = NULL;
    if(ptrMaillon->u.list_mariage->c2->u.list_individu->data->prenom != NULL)
    {
        chaine = (char*)malloc(sizeof(char) * (strlen(ptrMaillon->u.list_mariage->c2->u.list_individu->data->prenom) + 1));

        strcpy(chaine, ptrMaillon->u.list_mariage->c2->u.list_individu->data->prenom);
    }

    return chaine;
}

char* LISTMARIAGE_getDataCharDateNaissanceII(LIST *ptrMaillon)
{
    char tmp[11];
    char *chaine = NULL;
    if(ptrMaillon->u.list_mariage->c2->u.list_individu->data->naissance != NULL)
    {
        sprintf(tmp, "%d/%d/%d",ptrMaillon->u.list_mariage->c2->u.list_individu->data->naissance->jour, ptrMaillon->u.list_mariage->c2->u.list_individu->data->naissance->moi, ptrMaillon->u.list_mariage->c2->u.list_individu->data->naissance->annee);
        
        chaine = (char*)malloc(sizeof(char) * (strlen(tmp) + 1));

        strcpy(chaine, tmp);
    }
    return chaine;
}

char* LISTMARIAGE_getDataCharLieuNaissanceII(LIST *ptrMaillon)
{
    char *chaine = NULL;
    if(ptrMaillon->u.list_mariage->c2->u.list_individu->data->lieuNaissance != NULL)
    {
        chaine = (char*)malloc(sizeof(char) * (strlen(ptrMaillon->u.list_mariage->c2->u.list_individu->data->lieuNaissance) + 1));

        strcpy(chaine, ptrMaillon->u.list_mariage->c2->u.list_individu->data->lieuNaissance);
    }
    return chaine;
}

char* LISTMARIAGE_getDataCharDateMariage(LIST *ptrMaillon)
{
    char tmp[11];
    char *chaine = NULL;
    if(ptrMaillon->u.list_mariage->data->date != NULL)
    {
        sprintf(tmp, "%d/%d/%d",ptrMaillon->u.list_mariage->data->date->jour, ptrMaillon->u.list_mariage->data->date->moi, ptrMaillon->u.list_mariage->data->date->annee);
        
        chaine = (char*)malloc(sizeof(char) * (strlen(tmp) + 1));

        strcpy(chaine, tmp);
    }

    return chaine;
}

char* LISTMARIAGE_getDataCharLieuMariage(LIST *ptrMaillon)
{
    char *chaine = NULL;
    if(ptrMaillon->u.list_mariage->data->lieu != NULL)
    {
        chaine = (char*)malloc(sizeof(char) * (strlen(ptrMaillon->u.list_mariage->data->lieu) + 1));

        strcpy(chaine, ptrMaillon->u.list_mariage->data->lieu);
    }
    return chaine;
}