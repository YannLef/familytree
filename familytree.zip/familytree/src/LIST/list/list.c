#include <stdio.h>
#include <stdlib.h>

#include "../../../include/LIST/structure.h"

#include "../../../include/LIST/list/methode/ptrFunctionL.h"

#include "../../../include/LIST/list/list.h"

void LIST_creatMaillon(LIST **ptrMaillon, type_list type, funcList *func)
{
    LIST *ptr = NULL;

    ptr = (LIST*)malloc(sizeof(LIST));

    if( ptr != NULL)
    {
        #ifdef VERBOSE
            printf("[LIST] malloc sizeof -> %ld | %p\n",sizeof(LIST), ptr);
        #endif
        ptr->type = type;
        (*(func->maillon)[ptr->type])(&ptr);
        (*(func->maillonDesc)[ptr->type])(&ptr);

        (*ptrMaillon) = ptr;
    }
}

void LIST_insertData(LIST **ptrMaillon, char **data, funcList *func)
{
    (*(func->insertData)[(*ptrMaillon)->type])(ptrMaillon, data);
}

void LIST_insertMaillon(LIST *insert, LIST **ptrListHead, funcList *func)
{
    (*(func->insertMaillonHead)[insert->type])(insert, ptrListHead);
}

void LIST_getCharData(char ***data, LIST *ptrMaillon, funcList *func, dataFile *file)
{
    int i;
    (*data) = (char**)malloc(sizeof(char*) * file->nb_column);
    
    if( (*data) != NULL)
    {
        for(i = 0; i < file->nb_column ; i++)
        {
            (*data)[i] = (*(func->getData)[ptrMaillon->type][i])(ptrMaillon);
        }
    }
}

void LIST_pointeurFunction(funcList **ptrFunction)
{
    funcList *ptr = NULL;
    ptr = (funcList*)malloc(sizeof(funcList) * NB_POINTEURFUNCTION);
    
    if( ptr != NULL)
    {
        #ifdef VERBOSE
            printf("[FuncLIST] malloc sizeof -> %ld | %p\n",sizeof(funcList), ptr);
        #endif
        ptrFunctionInddividu(&ptr);
        ptrFunctionMariage(&ptr);
    }

    (*ptrFunction) = ptr;
}

void LIST_freePointeurFonction(funcList **ptrFunction)
{
    if( (*ptrFunction) != NULL)
    {
        free_ptrFunctionIndividu(ptrFunction);
        free_ptrFunctionMariage(ptrFunction);

        free((*ptrFunction));
        (*ptrFunction) = NULL;
    }
}

void LIST_getNexMaillon(LIST **next, LIST *ptrMaillon, funcList *ptrFunc)
{
    (*(ptrFunc->getNextMaillon)[ptrMaillon->type])(next, ptrMaillon);
}