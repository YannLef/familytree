#include <stdio.h>
#include <stdlib.h>

#include "../../../../../include/LIST/structure.h"

#include "../../../../../include/LIST/list/event/methode/displayTerminalE.h"

void displayListEvent(LIST *head)
{
    LIST *ptr = head;
    int i = 0;

    while( ptr != NULL)
    {


        
    }
}