#include <stdio.h>
#include <stdlib.h>
#include "string.h"

#include "../../../../include/LIST/structure.h"

#include "../../../../include/LIST/sublist/sublist.h"

#include "../../../../include/LIST/library/allocation/free.h"

#include "../../../../include/LIST/sublist/individu/individuSL.h"

#include "../../../../include/LIST/list/individu/methode/insertDataI.h"
#include "../../../../include/LIST/list/individu/methode/searchMaillonI.h"

#include "../../../../include/LIST/sublist/methode/deleteSL.h"

#include "../../../../include/LIST/list/individu/individuL.h"

void LISTINDIVIDU_create(LIST **ptrMaillon)
{
    LIST *ptr = NULL;

    ptr = (LIST*)malloc(sizeof(LIST));
    
    if( ptr != NULL)
    {
        #ifdef VERBOSE
            printf("[LIST] malloc sizeof -> %ld | %p\n",sizeof(LIST), ptr);
        #endif
        ptr->type = type_listIndividu;

        ptr->u.list_individu = (list_individu*)malloc(sizeof(list_individu));

        if( ptr->u.list_individu != NULL)
        {
            #ifdef VERBOSE
                printf("\t[list_individu] malloc sizeof -> %ld | %p\n",sizeof(list_individu), ptr->u.list_individu);
            #endif
            ptr->u.list_individu->sublistIndividu = NULL;
            ptr->u.list_individu->sublistMariage = NULL; 
            ptr->u.list_individu->c1 = NULL;
            ptr->u.list_individu->c2 = NULL;
            ptr->u.list_individu->suivant = NULL;

            (*ptrMaillon) = ptr;
        }
    }
}

void LISTINDIVIDU_createMaillon(LIST **ptrMaillon)
{
    list_individu *ptr = NULL;

    ptr = (list_individu*)malloc(sizeof(list_individu));

    if( ptr != NULL)
    {   
        #ifdef VERBOSE
            printf("\t[list_individu] malloc sizeof -> %ld | %p\n",sizeof(list_individu), ptr);
        #endif
        ptr->sublistIndividu = NULL;
        ptr->sublistMariage = NULL; 
        ptr->c1 = NULL;
        ptr->c2 = NULL;
        ptr->suivant = NULL;

        (*ptrMaillon)->u.list_individu = ptr;
    }
}

void LISTINDIVIDU_creatDescription(LIST **ptrMaillon)
{
    list_descriptionIndividu *ptr = NULL;

    ptr = (list_descriptionIndividu*)malloc(sizeof(list_descriptionIndividu));

    if(ptr != NULL)
    {
        #ifdef VERBOSE
            printf("\t\t[list_descriptionIndividu] malloc sizeof -> %ld | %p\n",sizeof(list_descriptionIndividu), ptr);
        #endif
        ptr->generation = 0;
        ptr->deces = NULL;
        ptr->naissance = NULL;
        ptr->genre = NULL;
        ptr->lieuDeces = NULL;
        ptr->lieuNaissance = NULL;
        ptr->nom = NULL;
        ptr->prenom = NULL;
        (*ptrMaillon)->u.list_individu->data = ptr;
    }
}

void LISTINDIVIDU_insertMaillonHeader(LIST *insert, LIST **ptrTeteList)
{
    insert->u.list_individu->suivant = (*ptrTeteList);
    (*ptrTeteList) = insert;
}

void LISTINDIVIDU_insertMaillon(LIST **insert, LIST **ptrTeteList)
{
    LIST *precedent = NULL;

    LISTINDIVIDU_searchGeneration((*ptrTeteList), &precedent, (*insert));
  
    if( precedent == NULL)
    {
        (*insert)->u.list_individu->suivant = (*ptrTeteList);
        (*ptrTeteList) = (*insert);
    }
    else
    {
        (*insert)->u.list_individu->suivant = precedent->u.list_individu->suivant;
        precedent->u.list_individu->suivant = (*insert);
    }
}
//retire le maillon de la liste sans le supprimer
void LISTINDIVIDU_deleteMaillon(LIST **delete, LIST **ptrHead)
{
    LIST *precedent = NULL;

    LISTINDIVIDU_searchIndividuMaillon((*ptrHead), &precedent, (*delete));
   
    if( precedent == NULL)
    {
        (*ptrHead) = (*delete)->u.list_individu->suivant;
        (*delete)->u.list_individu->suivant = NULL;
    }
    else
    {
        precedent->u.list_individu->suivant = (*delete)->u.list_individu->suivant;
        (*delete)->u.list_individu->suivant = NULL;
    }
}

void LISTINDIVIDU_insertData(LIST **ptrMaillon, char **data)
{
    LISTINDIVIDU_insertGeneration(ptrMaillon, data[generationI]);
    LISTINDIVIDU_insertNom(ptrMaillon, data[nomI]);
    LISTINDIVIDU_insertPrenom(ptrMaillon, data[prenomI]);
    LISTINDIVIDU_insertGenre(ptrMaillon, data[genreI]);
    LISTINDIVIDU_insertDateNaissance(ptrMaillon, data[naissanceDateI]);
    LISTINDIVIDU_insertDateDeces(ptrMaillon, data[decesDateI]);
    LISTINDIVIDU_insertLieuNaissance(ptrMaillon, data[naissanceLieuI]);
    LISTINDIVIDU_insertLieuDeces(ptrMaillon, data[decesLieuI]);
}

void LISTINDIVIDU_insertDataNameSurNameGeneration(LIST **ptrMaillon, char **data, const int nom, const int prenom, int nbParent)
{
    LISTINDIVIDU_insertGenerationSupplementaire(ptrMaillon, data[0]);
    LISTINDIVIDU_insertNom(ptrMaillon, data[nom]);
    LISTINDIVIDU_insertPrenom(ptrMaillon, data[prenom]);  
}

void LISTINDIVIDU_insertConjointPtr(LIST **ptrIndividu, LIST *parent, const int nbParent)
{
    if( nbParent == 1)
        (*ptrIndividu)->u.list_individu->c1 = parent;
    else if( nbParent == 2)
        (*ptrIndividu)->u.list_individu->c2 = parent;
}

void LISTINDIVIDU_creatLinkParent(LIST *ptrMaillon, LIST **ptrIndividu, char **data, const int nom, const int prenom, const int nbParent)
{
    LIST *parent = NULL;
    
    if( data[nom] != NULL && data[prenom] != NULL)
        LISTINDIVIDU_searchIndividuParent((*ptrIndividu), &parent, ptrMaillon->u.list_individu->data->generation, data[nom] ,data[prenom]);

    SUBLIST *ptrMaillonSL = NULL;

    if( parent != NULL)
    {
        LISTINDIVIDU_insertConjointPtr(&ptrMaillon, parent, nbParent);

        SUBLISTINDIVIDU_create(&ptrMaillonSL);
        SUBLISTINDIVIDU_insertData(&ptrMaillonSL, *ptrIndividu);
        SUBLISTINDIVIDU_insertMaillon(ptrMaillonSL, &parent);
    }
    else if( parent == NULL && data[nom] != NULL && data[prenom] != NULL)
    {
        LISTINDIVIDU_create(&parent);
        LISTINDIVIDU_creatDescription(&parent);
        LISTINDIVIDU_insertDataNameSurNameGeneration(&parent, data, nom, prenom, nbParent);
        LISTINDIVIDU_insertMaillon(&parent, ptrIndividu);

        LISTINDIVIDU_insertConjointPtr(&ptrMaillon, parent, nbParent);
        SUBLISTINDIVIDU_create(&ptrMaillonSL);
        SUBLISTINDIVIDU_insertData(&ptrMaillonSL, *ptrIndividu);
        SUBLISTINDIVIDU_insertMaillon(ptrMaillonSL, &parent);
    }
}

void LISTINDIVIDU_freeMaillon(LIST **ptrMaillon, funcSublist *func_SUBLIST)
{
    list_individu *ptr = (*ptrMaillon)->u.list_individu;
    SUBLIST *mariage = (*ptrMaillon)->u.list_individu->sublistMariage;
    SUBLIST *individu = (*ptrMaillon)->u.list_individu->sublistIndividu;
    
    if(individu != NULL)
        SUBLIST_deleteAll(&individu, func_SUBLIST);
    
    if(mariage != NULL)
        SUBLIST_deleteAll(&mariage, func_SUBLIST);

    (*ptrMaillon)->u.list_individu->sublistIndividu = individu;
    (*ptrMaillon)->u.list_individu->sublistMariage = mariage;

    ptr->c1 = NULL;
    ptr->c2 = NULL;
    ptr->suivant = NULL;

    if( ptr != NULL)
    {
        #ifdef VERBOSE
            printf("\t[LIST_individu] free sizeof -> %ld | %p | ",sizeof((ptr)), (ptr));
        #endif
        free(ptr);
        ptr = NULL;
        #ifdef VERBOSE
            if( (ptr) == NULL)
            {
                printf("free\n");
            }
            else
            {
                printf(" not free\n");
            }
        #endif
    }

    (*ptrMaillon)->u.list_individu = ptr;

    #ifdef VERBOSE  
        printf("Liste individu >>>> %ld | %p\n",sizeof(ptr), ptr);
    #endif

    if( (*ptrMaillon) != NULL)
    {
        #ifdef VERBOSE
            printf("[LIST] free sizeof -> %ld | %p | ",sizeof((*ptrMaillon)), (*ptrMaillon));
        #endif
        free((*ptrMaillon));
        (*ptrMaillon) = NULL;
        #ifdef VERBOSE
            if( (*ptrMaillon) == NULL)
            {
                printf("free\n");
            }
            else
            {
                printf(" not free\n");
            }
        #endif
    }
    #ifdef VERBOSE
        printf("LIST >>>> %ld | %p\n",sizeof((*ptrMaillon)), (*ptrMaillon));
    #endif
}

void LISTINDIVIDU_freeDescription(LIST **ptrMaillon)
{
    list_descriptionIndividu *ptr = (*ptrMaillon)->u.list_individu->data;

    ptr->generation = 0;
    #ifdef VERBOSE
        if( ptr->generation == 0)
            printf("\t\t[List_I -> Gener] free sizeof -> %ld | X\n",sizeof(ptr->generation));
    #endif

    if( ptr->deces != NULL)
    {
        #ifdef VERBOSE
            printf("\t\t[List_I -> deces] free sizeof -> %ld | %p | ",sizeof(ptr->deces), ptr->deces);
        #endif
        free(ptr->deces); 
        ptr->deces = NULL;
        #ifdef VERBOSE
            if( (ptr->deces) == NULL)
            {
                printf("free\n");
            }
            else
            {
                printf(" not free\n");
            }
        #endif
    }

    if( ptr->genre != NULL)
    {
        #ifdef VERBOSE
            printf("\t\t[List_I -> genre] free sizeof -> %ld | %p | ",sizeof(ptr->genre), ptr->genre);
        #endif
        free(ptr->genre);
        ptr->genre = NULL;
        #ifdef VERBOSE
            if( (ptr->genre) == NULL)
            {
                printf("free\n");
            }
            else
            {
                printf(" not free\n");
            }
        #endif
    }

    if( ptr->lieuDeces != NULL)
    {
        #ifdef VERBOSE
            printf("\t\t[List_I -> lieuDeces] free sizeof -> %ld | %p | ",sizeof(ptr->lieuDeces), ptr->lieuDeces);
        #endif
        free(ptr->lieuDeces);
        ptr->lieuDeces = NULL;
        #ifdef VERBOSE
            if( (ptr->lieuDeces) == NULL)
            {
                printf("free\n");
            }
            else
            {
                printf(" not free\n");
            }
        #endif
    }

    if( ptr->lieuNaissance != NULL)
    {
        #ifdef VERBOSE
            printf("\t\t\t[List_I -> lieuNaissance] free sizeof -> %ld | %p |",sizeof(ptr->lieuNaissance), ptr->lieuNaissance);
        #endif
        free(ptr->lieuNaissance);
        ptr->lieuNaissance = NULL;
        #ifdef VERBOSE
            if( (ptr->lieuNaissance) == NULL)
            {
                printf("free\n");
            }
            else
            {
                printf(" not free\n");
            }
        #endif
    }

    if( ptr->naissance != NULL)
    {
        #ifdef VERBOSE
            printf("\t\t\t[List_I -> naissance] free sizeof -> %ld | %p |",sizeof(ptr->naissance), ptr->naissance);
        #endif
        free(ptr->naissance);
        ptr->naissance = NULL;
        #ifdef VERBOSE
            if( (ptr->naissance) == NULL)
            {
                printf("free\n");
            }
            else
            {
                printf(" not free\n");
            }
        #endif
    }

    if( ptr->nom != NULL)
    {
        #ifdef VERBOSE
            printf("\t\t\t[List_I -> nom] free sizeof -> %ld | %p |",sizeof(ptr->nom), ptr->nom);
        #endif
        free(ptr->nom);
        ptr->nom = NULL; 
        #ifdef VERBOSE
            if( (ptr->nom) == NULL)
            {
                printf("free\n");
            }
            else
            {
                printf(" not free\n");
            }
        #endif
    }

    if( ptr->prenom != NULL)
    {
        #ifdef VERBOSE
            printf("\t\t\t[List_I -> prenom] free sizeof -> %ld | %p |",sizeof(ptr->prenom), ptr->prenom);
        #endif
        free(ptr->prenom);
        ptr->prenom = NULL;
        #ifdef VERBOSE
            if( (ptr->prenom) == NULL)
            {
                printf("free\n");
            }
            else
            {
                printf(" not free\n");
            }
        #endif
    }

    if( ptr != NULL)
    {
        #ifdef VERBOSE
            printf("\t\t[Listdescription] free sizeof -> %ld | %p |",sizeof(ptr), ptr);
        #endif
        free(ptr);
        ptr = NULL;
        #ifdef VERBOSE
            if( (ptr) == NULL)
            {
                printf("free\n");
            }
            else
            {
                printf(" not free\n");
            }
        #endif
    }

    (*ptrMaillon)->u.list_individu->data = ptr;

    #ifdef VERBOSE
        printf("Liste decription I >>>> %ld | %p\n",sizeof(ptr), ptr);
    #endif
}

void LISTINDIVIDU_getNextMaillon(LIST **next, LIST *ptrMaillon)
{
    (*next) = ptrMaillon->u.list_individu->suivant;
}