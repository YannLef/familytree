#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../../../../include/LIST/structure.h"

#include "../../../../../include/LIST/list/individu/methode/searchMaillonI.h"

void LISTINDIVIDU_searchIndividuParent(LIST *ptrTeteListe, LIST **ptrIndividu, const int generation, char *nom, char *prenom)
{
    LIST *ptr = ptrTeteListe;
    const int genMin = generation;
    const int genMax = generation + 3;

    while( ptr != NULL)
    {           
        if( ptr->u.list_individu->data->generation > genMin && ptr->u.list_individu->data->generation < genMax)
            if( strcmp(nom, ptr->u.list_individu->data->nom) == 0)
                if( strcmp(prenom, ptr->u.list_individu->data->prenom) == 0)
                    break;

        ptr = ptr->u.list_individu->suivant;
    }
    (*ptrIndividu) = ptr;
}

void LISTINDIVIDU_searchIndividu(LIST *ptrTeteListe, LIST **ptrIndividu,const int generation, char *nom, char *prenom)
{
    LIST *ptr = ptrTeteListe;

    while( ptr != NULL)
    {
        if( generation == ptr->u.list_individu->data->generation)
            if( strcmp(nom, ptr->u.list_individu->data->nom) == 0)
                if( strcmp(prenom , ptr->u.list_individu->data->prenom) == 0)
                    break;

        ptr = ptr->u.list_individu->suivant;
    }
    (*ptrIndividu) = ptr;
}

void LISTINDIVIDU_searchGeneration(LIST *ptrTeteListe, LIST **ptrIndividu, LIST *parent)
{
    LIST *ptr = ptrTeteListe;
    LIST *tmp = NULL;

    while( ptr != NULL)
    {
        if( parent->u.list_individu->data->generation <= ptr->u.list_individu->data->generation)
        {
            break;
        }           

        (tmp) = ptr;
        ptr = ptr->u.list_individu->suivant;
    }
    (*ptrIndividu) = tmp;
}

void LISTINDIVIDU_searchIndividuMaillon(LIST *ptrHead, LIST **precedent, LIST *delete)
{
    LIST *ptr = ptrHead;
    LIST *before = NULL;

    while( ptr != NULL)
    {
        if( ptr->u.list_individu->data->generation == delete->u.list_individu->data->generation)
            if( strcmp(ptr->u.list_individu->data->nom, delete->u.list_individu->data->nom) == 0)
                if( strcmp(ptr->u.list_individu->data->prenom, delete->u.list_individu->data->prenom) == 0)
                    break;
                    
        before = ptr;
        ptr = ptr->u.list_individu->suivant;
    }
    (*precedent) = before;
}
