#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Structure liste Chainé
#include "../../../../../include/LIST/structure.h"
//Library
#include "../../../../../include/LIST/library/string/str_split.h"
#include "../../../../../include/LIST/library/allocation/free.h"

#include "../../../../../include/LIST/list/individu/methode/insertDataI.h"

void LISTINDIVIDU_insertGeneration(LIST **ptrMaillon, char *data)
{
    if(data != NULL && (*ptrMaillon)->u.list_individu->data->generation == 0)
    {
        (*ptrMaillon)->u.list_individu->data->generation = atoi(data);

        #ifdef VERBOSE
            printf("\t\t\t[List_I -> generation] malloc sizeof -> %ld | X\n",sizeof(int));
        #endif
    }
}

void LISTINDIVIDU_insertGenerationSupplementaire(LIST **ptrMaillon, char *data)
{
    if(data != NULL && (*ptrMaillon)->u.list_individu->data->generation == 0)
    {
        (*ptrMaillon)->u.list_individu->data->generation = atoi(data) + 1;
        #ifdef VERBOSE
            printf("\t\t\t[List_I -> generation] malloc sizeof -> %ld | X\n",sizeof(int));
        #endif
    }
}

void LISTINDIVIDU_insertNom(LIST **ptrMaillon, char *data)
{
    if(data != NULL && (*ptrMaillon)->u.list_individu->data->nom == NULL)
    {
        (*ptrMaillon)->u.list_individu->data->nom = (char*)malloc(sizeof(char) * strlen(data));
        #ifdef VERBOSE
            printf("\t\t\t[List_I -> Nom] malloc sizeof -> %ld | %p\n",sizeof((*ptrMaillon)->u.list_individu->data->nom), (*ptrMaillon)->u.list_individu->data->nom);
        #endif
        if( (*ptrMaillon)->u.list_individu->data->nom != NULL)
            strcpy((*ptrMaillon)->u.list_individu->data->nom, data);
    }
}

void LISTINDIVIDU_insertPrenom(LIST **ptrMaillon, char *data)
{
    if(data != NULL && (*ptrMaillon)->u.list_individu->data->prenom == NULL)
    {
        (*ptrMaillon)->u.list_individu->data->prenom = (char*)malloc(sizeof(char) * strlen(data));
        #ifdef VERBOSE
            printf("\t\t\t[List_I -> Prenom] malloc sizeof -> %ld | %p\n",sizeof((*ptrMaillon)->u.list_individu->data->prenom), (*ptrMaillon)->u.list_individu->data->prenom);
        #endif
        if( (*ptrMaillon)->u.list_individu->data->prenom != NULL)
            strcpy((*ptrMaillon)->u.list_individu->data->prenom, data);
    }
}

void LISTINDIVIDU_insertGenre(LIST **ptrMaillon, char *data)
{
    if(data != NULL && (*ptrMaillon)->u.list_individu->data->genre == NULL)
    {
        (*ptrMaillon)->u.list_individu->data->genre = (char*)malloc(sizeof(char) * strlen(data));
        #ifdef VERBOSE
            printf("\t\t\t[List_I -> Genre] malloc sizeof -> %ld | %p\n",sizeof((*ptrMaillon)->u.list_individu->data->genre), (*ptrMaillon)->u.list_individu->data->genre);
        #endif
        if( (*ptrMaillon)->u.list_individu->data->genre != NULL)
            strcpy((*ptrMaillon)->u.list_individu->data->genre, data);
    }
}

void LISTINDIVIDU_insertDateNaissance(LIST **ptrMaillon, char *data)
{
    char **date = NULL;
    if(data != NULL && (*ptrMaillon)->u.list_individu->data->naissance == NULL)
    {
        date = str_splitChaine( 3, data, "/");
        (*ptrMaillon)->u.list_individu->data->naissance = (m_date*)malloc(sizeof(m_date));
        #ifdef VERBOSE
            printf("\t\t\t[m_date] malloc sizeof -> %ld | %p\n",sizeof(m_date),(*ptrMaillon)->u.list_individu->data->naissance); 
        #endif
        if( date[0] != NULL)
            (*ptrMaillon)->u.list_individu->data->naissance->jour = atoi(date[0]);
        else
            (*ptrMaillon)->u.list_individu->data->naissance->jour = 0;
        
        if( date[1] != NULL)
            (*ptrMaillon)->u.list_individu->data->naissance->moi = atoi(date[1]);
        else
            (*ptrMaillon)->u.list_individu->data->naissance->moi = 0;

        if( date[2] != NULL)
            (*ptrMaillon)->u.list_individu->data->naissance->annee = atoi(date[2]);
        else
            (*ptrMaillon)->u.list_individu->data->naissance->annee = 0;

        free_charDoubleDim(&date, 3); 
    }
}

void LISTINDIVIDU_insertDateDeces(LIST **ptrMaillon, char *data)
{
    char **date = NULL;
    if(data != NULL && (*ptrMaillon)->u.list_individu->data->deces == NULL)
    {
        date = str_splitChaine( 3, data, "/");

        (*ptrMaillon)->u.list_individu->data->deces = (m_date*)malloc(sizeof(m_date));
        #ifdef VERBOSE
            printf("\t\t\t[m_date] malloc sizeof -> %ld | %p\n",sizeof(m_date), (*ptrMaillon)->u.list_individu->data->deces); 
        #endif
        if( date[0] != NULL)
            (*ptrMaillon)->u.list_individu->data->deces->jour = atoi(date[0]);
        else
            (*ptrMaillon)->u.list_individu->data->deces->jour = 0;
        
        if( date[1] != NULL)
            (*ptrMaillon)->u.list_individu->data->deces->moi = atoi(date[1]);
        else
            (*ptrMaillon)->u.list_individu->data->deces->moi = 0;
            
        if( date[2] != NULL)
            (*ptrMaillon)->u.list_individu->data->deces->annee = atoi(date[2]);
        else
            (*ptrMaillon)->u.list_individu->data->deces->annee = 0;

        free_charDoubleDim(&date, 3); 
    }
}

void LISTINDIVIDU_insertLieuNaissance(LIST **ptrMaillon, char *data)
{
    if(data != NULL && (*ptrMaillon)->u.list_individu->data->lieuNaissance == NULL)
    {
        (*ptrMaillon)->u.list_individu->data->lieuNaissance = (char*)malloc(sizeof(char) * strlen(data));
        #ifdef VERBOSE
            printf("\t\t\t[List_I -> LieuNaissance] malloc sizeof -> %ld | %p\n",sizeof((*ptrMaillon)->u.list_individu->data->lieuNaissance),(*ptrMaillon)->u.list_individu->data->lieuNaissance);
        #endif
        if( (*ptrMaillon)->u.list_individu->data->lieuNaissance != NULL)
            strcpy((*ptrMaillon)->u.list_individu->data->lieuNaissance, data);
    }
}

void LISTINDIVIDU_insertLieuDeces(LIST **ptrMaillon, char *data)
{
    if(data != NULL && (*ptrMaillon)->u.list_individu->data->lieuDeces == NULL)
    {
        (*ptrMaillon)->u.list_individu->data->lieuDeces = (char*)malloc(sizeof(char) * strlen(data));
        #ifdef VERBOSE
            printf("\t\t\t[List_I -> LieuDeces] malloc sizeof -> %ld | %p\n",sizeof((*ptrMaillon)->u.list_individu->data->lieuDeces), (*ptrMaillon)->u.list_individu->data->lieuDeces);
        #endif
        if( (*ptrMaillon)->u.list_individu->data->lieuDeces != NULL)
            strcpy((*ptrMaillon)->u.list_individu->data->lieuDeces, data);
    }
}