#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../../../../include/LIST/structure.h"

#include "../../../../../include/LIST/list/individu/methode/getDataCharI.h"

char* LISTINDIVIDU_getDataCharGeneration(LIST *ptrMaillon)
{
    char tmp[9];
    char *chaine = NULL;
    if( ptrMaillon->u.list_individu->data->generation != 0)
    {
        sprintf(tmp, "%d", ptrMaillon->u.list_individu->data->generation);

        chaine = (char*)malloc(sizeof(char) * (strlen(tmp) + 1));

        strcpy(chaine, tmp);
    }
    return chaine;
}

char* LISTINDIVIDU_getDataCharNom(LIST *ptrMaillon)
{
    char *chaine = NULL;
    if(ptrMaillon->u.list_individu->data->nom != NULL)
    {
        chaine = (char*)malloc(sizeof(char) * (strlen(ptrMaillon->u.list_individu->data->nom) + 1));

        strcpy(chaine, ptrMaillon->u.list_individu->data->nom);
    }
    return chaine;
}

char* LISTINDIVIDU_getDataCharPrenom(LIST *ptrMaillon)
{
    char *chaine = NULL;
    if(ptrMaillon->u.list_individu->data->nom != NULL)
    {
        chaine = (char*)malloc(sizeof(char) * (strlen(ptrMaillon->u.list_individu->data->prenom) + 1));

        strcpy(chaine, ptrMaillon->u.list_individu->data->prenom);
    }
    return chaine;
}

char* LISTINDIVIDU_getDataCharGenre(LIST *ptrMaillon)
{
    char *chaine = NULL;
    if(ptrMaillon->u.list_individu->data->genre != NULL)
    {
        chaine = (char*)malloc(sizeof(char) * (strlen(ptrMaillon->u.list_individu->data->genre) + 1));

        strcpy(chaine, ptrMaillon->u.list_individu->data->genre);
    }
    return chaine;
}

char* LISTINDIVIDU_getDataCharLieuNaissance(LIST *ptrMaillon)
{
    char *chaine = NULL;
    if(ptrMaillon->u.list_individu->data->lieuNaissance != NULL)
    {
        chaine = (char*)malloc(sizeof(char) * (strlen(ptrMaillon->u.list_individu->data->lieuNaissance) + 1));

        strcpy(chaine, ptrMaillon->u.list_individu->data->lieuNaissance);
    }
    return chaine;
}

char* LISTINDIVIDU_getDataCharLieuDeces(LIST *ptrMaillon)
{
    char *chaine = NULL;
    if(ptrMaillon->u.list_individu->data->lieuDeces != NULL)
    {
        chaine = (char*)malloc(sizeof(char) * (strlen(ptrMaillon->u.list_individu->data->lieuDeces) + 1));

        strcpy(chaine, ptrMaillon->u.list_individu->data->lieuDeces);
    }
    return chaine;
}

char* LISTINDIVIDU_getDataCharC1Nom(LIST *ptrMaillon)
{
    char *chaine = NULL;
    LIST *ptr = NULL;
    if(ptrMaillon->u.list_individu->c1 != NULL)
    {
        ptr = ptrMaillon->u.list_individu->c1;
        chaine = (char*)malloc(sizeof(char) * (strlen(ptr->u.list_individu->data->nom) + 1));

        strcpy(chaine, ptr->u.list_individu->data->nom);
    }
    return chaine;
}

char* LISTINDIVIDU_getDataCharC1Prenom(LIST *ptrMaillon)
{
    char *chaine = NULL;
    LIST *ptr = NULL;
    if(ptrMaillon->u.list_individu->c1 != NULL)
    {
        ptr = ptrMaillon->u.list_individu->c1;
        chaine = (char*)malloc(sizeof(char) * (strlen(ptr->u.list_individu->data->prenom) + 1));

        strcpy(chaine, ptr->u.list_individu->data->prenom);
    }
    return chaine;
}

char* LISTINDIVIDU_getDataCharC2Nom(LIST *ptrMaillon)
{
    char *chaine = NULL;
    LIST *ptr = NULL;
    if(ptrMaillon->u.list_individu->c2 != NULL)
    {
        ptr = ptrMaillon->u.list_individu->c2;
        chaine = (char*)malloc(sizeof(char) * (strlen(ptr->u.list_individu->data->nom) + 1));

        strcpy(chaine, ptr->u.list_individu->data->nom);
    }
    return chaine;
}

char* LISTINDIVIDU_getDataCharC2Prenom(LIST *ptrMaillon)
{
    char *chaine = NULL;
    LIST *ptr = NULL;
    if(ptrMaillon->u.list_individu->c2 != NULL)
    {
        ptr = ptrMaillon->u.list_individu->c2;
        chaine = (char*)malloc(sizeof(char) * (strlen(ptr->u.list_individu->data->prenom) + 1));

        strcpy(chaine, ptr->u.list_individu->data->prenom);
    }
    return chaine;
}

char* LISTINDIVIDU_getDataCharDateNaissance(LIST *ptrMaillon)
{
    char tmp[30];
    char *chaine = NULL;
    if(ptrMaillon->u.list_individu->data->naissance != NULL)
    {
        sprintf(tmp, "%d/%d/%d",ptrMaillon->u.list_individu->data->naissance->jour,ptrMaillon->u.list_individu->data->naissance->moi, ptrMaillon->u.list_individu->data->naissance->annee);
        
        chaine = (char*)malloc(sizeof(char) * (strlen(tmp) + 1));

        strcpy(chaine, tmp);
    }
    return chaine;
}

char* LISTINDIVIDU_getDataCharDateDeces(LIST *ptrMaillon)
{
    char tmp[30];
    char *chaine = NULL;
    if(ptrMaillon->u.list_individu->data->deces != NULL)
    {
        sprintf(tmp, "%d/%d/%d",ptrMaillon->u.list_individu->data->deces->jour,ptrMaillon->u.list_individu->data->deces->moi, ptrMaillon->u.list_individu->data->deces->annee);
        
        chaine = (char*)malloc(sizeof(char) * (strlen(tmp) + 1));

        strcpy(chaine, tmp);
    }
    return chaine;
}