#include <stdio.h>
#include <stdlib.h>

#include "../../../../../include/LIST/structure.h"

#include "../../../../../include/LIST/list/individu/methode/displayTerminalI.h"

void displayListIndividu(LIST *ptrTete)
{
    LIST *ptr = ptrTete;
    int i = 0;
    SUBLIST *ptrSL = NULL;
    while( ptr!= NULL )
    {
        printf("\t\t[INDIVIDU] -> %d\n",i);
        printf("\t\tGeneration -> %d\n",ptr->u.list_individu->data->generation);
        printf("\t\tNom -> %s\n",ptr->u.list_individu->data->nom);
        printf("\t\tPrenom -> %s\n",ptr->u.list_individu->data->prenom);

        if( ptr->u.list_individu->data->genre != NULL)
            printf("\t\tGenre -> %s\n", ptr->u.list_individu->data->genre);
        else
            printf("\t\tGenre -> null\n");
        
        if( ptr->u.list_individu->data->naissance != NULL)
            printf("\t\tDateNaissance -> %d/%d/%d\n",ptr->u.list_individu->data->naissance->jour,
            ptr->u.list_individu->data->naissance->moi, ptr->u.list_individu->data->naissance->annee);
        else
            printf("\t\tDateNaissance -> ?\n");
        
        printf("\t\tLieuNaissance -> %s\n",ptr->u.list_individu->data->lieuNaissance);
        if( ptr->u.list_individu->data->deces != NULL)
            printf("\t\tDateDeces -> %d/%d/%d\n",ptr->u.list_individu->data->deces->jour,
            ptr->u.list_individu->data->deces->moi, ptr->u.list_individu->data->deces->annee);
        else
            printf("\t\tDateDeces -> ?\n");

        printf("\t\tLieuDeces -> %s\n",ptr->u.list_individu->data->lieuDeces);
        printf("\t\t[Parent 1]\n");
        if( ptr->u.list_individu->c1 != NULL)
        {
            
            printf("\t\t\tNom -> %s\n",ptr->u.list_individu->c1->u.list_individu->data->nom);
            printf("\t\t\tPrenom -> %s\n",ptr->u.list_individu->c1->u.list_individu->data->prenom);
        }
        else
        {
            printf("\t\t\t ?\n");
        }
        printf("\t\t[Parent 2]\n");
        if( ptr->u.list_individu->c2 != NULL)
        {
            printf("\t\t\tNom -> %s\n",ptr->u.list_individu->c2->u.list_individu->data->nom);
            printf("\t\t\tPrenom -> %s\n",ptr->u.list_individu->c2->u.list_individu->data->prenom);
        }
        else
        {
            printf("\t\t\t ?\n");
        }
        
        ptrSL = ptr->u.list_individu->sublistIndividu;
        printf("\t\t[ENFANT]\n");
        while (ptrSL != NULL)
        {
            printf("\t\t\tNom -> %s\n",ptrSL->u.sublist_I->individu->u.list_individu->data->nom);
            printf("\t\t\tPrenom -> %s\n",ptrSL->u.sublist_I->individu->u.list_individu->data->prenom);
            ptrSL = ptrSL->u.sublist_I->suivant;
        } 
        printf("\n");
        i++;
        ptr = ptr->u.list_individu->suivant;
    }
}