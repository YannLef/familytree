#include <stdio.h>
#include <stdlib.h>

#include "../../../../../include/LIST/structure.h"

#include "../../../../../include/LIST/list/individu/methode/toolI.h"

int LISTINDIVIDU_compteNbMaillon(LIST *ptr)
{
    int compteur = 0;
    LIST *tmp = ptr;
    while( tmp != NULL)
    {
        compteur++;
        tmp = tmp->u.list_individu->suivant;
    }
    return compteur;
}