#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../../../../include/LIST/structure.h"
#include "../../../../../include/LIST/library/allocation/free.h"
#include "../../../../../include/LIST/library/string/str_split.h"
#include "../../../../../include/LIST/sublist/individu/individuSL.h"
#include "../../../../../include/LIST/sublist/sublist.h"
#include "../../../../../include/LIST/list/individu/individuL.h"

#include "../../../../../include/LIST/list/individu/methode/updateData.h"

void LISTINDIVIDU_updateGeneration(LIST **ptr, char *data)
{
    if( data != NULL)
    {
        (*ptr)->u.list_individu->data->generation = atoi(data);
    }
}

void LISTINDIVIDU_updateNom(LIST **ptr, char *data)
{
    if( data != NULL)
    {
        if( (*ptr)->u.list_individu->data->nom != NULL)
        {
            free((*ptr)->u.list_individu->data->nom);
            (*ptr)->u.list_individu->data->nom = NULL;
        }

        (*ptr)->u.list_individu->data->nom = (char*)malloc(sizeof(char) * (strlen(data) + 1));
        strcpy( (*ptr)->u.list_individu->data->nom, data);       
    }
}

void LISTINDIVIDU_updatePrenom(LIST **ptr, char *data)
{
    if( data != NULL)
    {
        if( (*ptr)->u.list_individu->data->prenom != NULL)
        {
            free((*ptr)->u.list_individu->data->prenom);
            (*ptr)->u.list_individu->data->prenom = NULL;
        }

        (*ptr)->u.list_individu->data->prenom = (char*)malloc(sizeof(char) * (strlen(data) + 1));
        strcpy( (*ptr)->u.list_individu->data->prenom, data);       
    }
}

void LISTINDIVIDU_updateGenre(LIST **ptr, char *data)
{
    if( data != NULL)
    {
        if( (*ptr)->u.list_individu->data->genre != NULL)
        {
            free((*ptr)->u.list_individu->data->genre);
            (*ptr)->u.list_individu->data->genre = NULL;
        }

        (*ptr)->u.list_individu->data->genre = (char*)malloc(sizeof(char) * (strlen(data) + 1));
        strcpy( (*ptr)->u.list_individu->data->genre, data);       
    }
}

void LISTINDIVIDU_updateLieuNaissance(LIST **ptr, char *data)
{
    if( data != NULL)
    {
        if( (*ptr)->u.list_individu->data->lieuNaissance != NULL)
        {
            free((*ptr)->u.list_individu->data->lieuNaissance);
            (*ptr)->u.list_individu->data->lieuNaissance = NULL;
        }

        (*ptr)->u.list_individu->data->lieuNaissance = (char*)malloc(sizeof(char) * (strlen(data) + 1));
        strcpy( (*ptr)->u.list_individu->data->lieuNaissance, data);       
    }
}

void LISTINDIVIDU_updateLieuDeces(LIST **ptr, char *data)
{
    if( data != NULL)
    {
        if( (*ptr)->u.list_individu->data->lieuDeces != NULL)
        {
            free((*ptr)->u.list_individu->data->lieuDeces);
            (*ptr)->u.list_individu->data->lieuDeces = NULL;
        }

        (*ptr)->u.list_individu->data->lieuDeces = (char*)malloc(sizeof(char) * (strlen(data) + 1));
        strcpy( (*ptr)->u.list_individu->data->lieuDeces, data);       
    }
}

void LISTINDIVIDU_updateDateNaissance(LIST **ptr, char *data)
{
    char **date = NULL;

    if( data != NULL)
    {
        date = str_splitChaine( 3, data, "/");

        if( date != NULL)
        {
            if( (*ptr)->u.list_individu->data->naissance != NULL)
            {
                free((*ptr)->u.list_individu->data->naissance);
                (*ptr)->u.list_individu->data->naissance = NULL;
            }

            (*ptr)->u.list_individu->data->naissance = (m_date*)malloc(sizeof(m_date));
            
            if( date[0] != NULL)
            {
                (*ptr)->u.list_individu->data->naissance->jour = atoi(date[0]);
            }
            else
            {
                (*ptr)->u.list_individu->data->naissance->jour = 0;
            }

            if( date[1] != NULL)
            {
                (*ptr)->u.list_individu->data->naissance->moi = atoi(date[1]);
            }
            else
            {
                (*ptr)->u.list_individu->data->naissance->moi = 0;
            }

            if( date[2] != NULL)
            {
                (*ptr)->u.list_individu->data->naissance->annee = atoi(date[2]);
            }
            else
            {
                (*ptr)->u.list_individu->data->naissance->annee = 0;
            }  
            free_charDoubleDim(&date, 3);           
        }
    }
}

void LISTINDIVIDU_updateDateDeces(LIST **ptr, char *data)
{
    char **date = NULL;
    printf("%s \n", data);
    if( data != NULL)
    {
        date = str_splitChaine( 3, data, "/");

        if( date != NULL)
        {
            if( (*ptr)->u.list_individu->data->deces != NULL)
            {
                free((*ptr)->u.list_individu->data->deces);
                (*ptr)->u.list_individu->data->deces = NULL;
            }

            (*ptr)->u.list_individu->data->deces = (m_date*)malloc(sizeof(m_date));
            
            if( date[0] != NULL)
            {
                (*ptr)->u.list_individu->data->deces->jour = atoi(date[0]);
            }
            else
            {
                (*ptr)->u.list_individu->data->deces->jour = 0;
            }

            if( date[1] != NULL)
            {
                (*ptr)->u.list_individu->data->deces->moi = atoi(date[1]);
            }
            else
            {
                (*ptr)->u.list_individu->data->deces->moi = 0;
            }

            if( date[2] != NULL)
            {
                (*ptr)->u.list_individu->data->deces->annee = atoi(date[2]);
            }
            else
            {
                (*ptr)->u.list_individu->data->deces->annee = 0;
            }  
            free_charDoubleDim(&date, 3);           
        }
    }
}

void LISTINDIVIDU_updateConjoint(LIST **ptrHead, LIST **maillon, funcSublist *func, char **data)
{
    LIST *conjoint = NULL;
    SUBLIST *maillonDelete = NULL;

    if( data[prenomParent1I]!= NULL && data[nomParent1I] != NULL)
    {
        conjoint = (*maillon)->u.list_individu->c1;

        if( conjoint != NULL)
        {         
            if( conjoint->u.list_individu->sublistIndividu != NULL)
            {
                SUBLICTINDIVIDU_delateMaillon(&conjoint->u.list_individu->sublistIndividu, &maillonDelete, (*maillon));
                SUBLIST_free(&maillonDelete, func);
            }

            LISTINDIVIDU_creatLinkParent((*maillon), ptrHead, data, nomParent1I, prenomParent1I, 1);
            conjoint = NULL;
            maillonDelete = NULL;
        }
    }

    if( data[prenomParent2I]!= NULL && data[nomParent2I] != NULL)
    {
        conjoint = (*maillon)->u.list_individu->c2;
        if( conjoint != NULL)
        {    
            if( conjoint->u.list_individu->sublistIndividu != NULL)
            {
                SUBLICTINDIVIDU_delateMaillon(&conjoint->u.list_individu->sublistIndividu, &maillonDelete, (*maillon));
                SUBLIST_free(&maillonDelete, func);
            }
            LISTINDIVIDU_creatLinkParent((*maillon), ptrHead, data, nomParent2I, prenomParent2I, 2);
            conjoint = NULL;
        }
    }
}