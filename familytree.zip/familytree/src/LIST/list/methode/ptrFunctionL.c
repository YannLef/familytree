#include <stdio.h>
#include <stdlib.h>

#include "../../../../include/LIST/structure.h"

#include "../../../../include/LIST/list/list.h"

#include "../../../../include/LIST/list/individu/individuL.h"
#include "../../../../include/LIST/list/mariage/mariageL.h"

#include "../../../../include/LIST/list/individu/methode/getDataCharI.h"
#include "../../../../include/LIST/list/mariage/methode/getDataCharM.h"

#include "../../../../include/LIST/list/methode/ptrFunctionL.h"

void ptrFunctionInddividu(funcList **ptr)
{
    (*ptr)->maillon[type_listIndividu] = &LISTINDIVIDU_createMaillon;
    (*ptr)->maillonDesc[type_listIndividu] = &LISTINDIVIDU_creatDescription;
    (*ptr)->insertData[type_listIndividu] = &LISTINDIVIDU_insertData;
    (*ptr)->insertMaillonHead[type_listIndividu] = &LISTINDIVIDU_insertMaillonHeader;
    (*ptr)->freeDescription[type_listIndividu] = &LISTINDIVIDU_freeDescription; 
    (*ptr)->freeMaillon[type_listIndividu] = &LISTINDIVIDU_freeMaillon;
    (*ptr)->getNextMaillon[type_listIndividu] = &LISTINDIVIDU_getNextMaillon;

    (*ptr)->getData[type_listIndividu] = (getDataChar*)malloc(sizeof(getDataChar) * 12);

    (*ptr)->getData[type_listIndividu][generationI] = &LISTINDIVIDU_getDataCharGeneration;
    (*ptr)->getData[type_listIndividu][nomI] = &LISTINDIVIDU_getDataCharNom;
    (*ptr)->getData[type_listIndividu][prenomI] = &LISTINDIVIDU_getDataCharPrenom;
    (*ptr)->getData[type_listIndividu][genreI] = &LISTINDIVIDU_getDataCharGenre;
    (*ptr)->getData[type_listIndividu][naissanceDateI] = &LISTINDIVIDU_getDataCharDateNaissance;
    (*ptr)->getData[type_listIndividu][naissanceLieuI] = &LISTINDIVIDU_getDataCharLieuNaissance;
    (*ptr)->getData[type_listIndividu][decesDateI] = &LISTINDIVIDU_getDataCharDateDeces;
    (*ptr)->getData[type_listIndividu][decesLieuI] = &LISTINDIVIDU_getDataCharLieuDeces;
    (*ptr)->getData[type_listIndividu][nomParent1I] = &LISTINDIVIDU_getDataCharC1Nom;
    (*ptr)->getData[type_listIndividu][prenomParent1I] = &LISTINDIVIDU_getDataCharC1Prenom;
    (*ptr)->getData[type_listIndividu][nomParent2I] = &LISTINDIVIDU_getDataCharC2Nom;
    (*ptr)->getData[type_listIndividu][prenomParent2I] = &LISTINDIVIDU_getDataCharC2Prenom;
}

void free_ptrFunctionIndividu(funcList **ptr)
{
    if( (*ptr)->getData[type_listIndividu] != NULL)
    {
        free( (*ptr)->getData[type_listIndividu]);
        (*ptr)->getData[type_listIndividu] = NULL;
    }
}

void ptrFunctionMariage(funcList **ptr)
{
    (*ptr)->maillon[type_listMariage] = &LISTMARIAGE_createMaillon;
    (*ptr)->maillonDesc[type_listMariage] = &LISTMARIAGE_creatDescription;
    (*ptr)->insertData[type_listMariage] = &LISTMARIAGE_insertData;
    (*ptr)->insertMaillonHead[type_listMariage] = &LISTMARIAGE_insertMaillonHeader;
    (*ptr)->freeDescription[type_listMariage] = &LISTMARIAGE_freeDescription; 
    (*ptr)->freeMaillon[type_listMariage] = &LISTMARIAGE_freeMaillon;
    (*ptr)->getNextMaillon[type_listMariage] = &LISTMARIAGE_getNextMaillon;

    (*ptr)->getData[type_listMariage] = (getDataChar*)malloc(sizeof(getDataChar) * 12);

    (*ptr)->getData[type_listMariage][generation1] = &LISTMARIAGE_getDataCharGenerationI;
    (*ptr)->getData[type_listMariage][nom1] = &LISTMARIAGE_getDataCharNomI;
    (*ptr)->getData[type_listMariage][prenom1] = &LISTMARIAGE_getDataCharPrenomI;
    (*ptr)->getData[type_listMariage][naissanceDate1] = &LISTMARIAGE_getDataCharDateNaissanceI;
    (*ptr)->getData[type_listMariage][naissanceLieu1] = &LISTMARIAGE_getDataCharLieuNaissanceI;
    (*ptr)->getData[type_listMariage][generation2] = &LISTMARIAGE_getDataCharGenerationII;
    (*ptr)->getData[type_listMariage][nom2] = &LISTMARIAGE_getDataCharNomII;
    (*ptr)->getData[type_listMariage][prenom2] = &LISTMARIAGE_getDataCharPrenomII;
    (*ptr)->getData[type_listMariage][naissanceDate2] = &LISTMARIAGE_getDataCharDateNaissanceII;
    (*ptr)->getData[type_listMariage][naissanceLieu2] = &LISTMARIAGE_getDataCharLieuNaissanceII;
    (*ptr)->getData[type_listMariage][dateMariage] = &LISTMARIAGE_getDataCharDateMariage;
    (*ptr)->getData[type_listMariage][lieuMariage] = &LISTMARIAGE_getDataCharLieuMariage;
}

void free_ptrFunctionMariage(funcList **ptr)
{
    if( (*ptr)->getData[type_listMariage] != NULL)
    {
        free( (*ptr)->getData[type_listMariage]);
        (*ptr)->getData[type_listMariage] = NULL;
    }
}