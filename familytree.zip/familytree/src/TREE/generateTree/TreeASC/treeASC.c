#include <stdio.h>
#include <stdlib.h>

#include "../../../../include/LIST/structure.h"
#include "../../../../include/IHM/structures.h"
#include "../../../../include/TREE/structure.h"
#include "../../../../include/TREE/tree/NodeASC/nodeASC.h"

#include "../../../../include/IHM/Couleur.h"
#include "../../../../include/IHM/Rectangle.h"

#include "../../../../include/TREE/generationTree/treeASC/treeASC.h"

NoeudASC* TREEASC_createTree(LIST *ptrIndividu, NoeudData **noeudData)
{
    if(ptrIndividu == NULL)
        return NULL;
    else
    {
        NoeudASC *node = NULL;
        NoeudASC *ptrDroite = NULL;
        NoeudASC *ptrGauche = NULL;

        if( ptrIndividu->u.list_individu->data->generation > (*noeudData)->nombreGeneration )
            (*noeudData)->nombreGeneration = (*noeudData)->nombreGeneration + 1;

        ptrDroite = TREEASC_createTree(ptrIndividu->u.list_individu->c1, noeudData);

        ptrGauche = TREEASC_createTree(ptrIndividu->u.list_individu->c2, noeudData);

        NODEASC_createNode(&node);
        NODEASC_insertData(&node,ptrIndividu, ptrDroite, ptrGauche);
        

        return node;
    }
}

void TREEASC_deletetree(NoeudASC **root)
{
    if( (*root)->droite == NULL || (*root)->gauche == NULL)
        return;
    else
    {
        NoeudASC *droite = (*root)->droite;
        NoeudASC *gauche = (*root)->gauche;
        #ifdef VERBOSE
            printf("DROITE -> %p | GAUCHE -> %p\n",(*root)->droite, (*root)->gauche);
        #endif
        TREEASC_deletetree(&droite);
        TREEASC_deletetree(&gauche);
        (*root)->droite = droite;
        (*root)->gauche = gauche;

        NODEASC_deleteNode(root);  
    }
}


void TREEASC_display(NoeudASC *root)
{
    if(root == NULL)
        return;
    else
    {
        printf("\t[NODE]\n");
        printf("\t\tNom : %s\n",root->ptrIndividu->u.list_individu->data->nom);
        printf("\t\tPrenom : %s\n",root->ptrIndividu->u.list_individu->data->prenom);
        printf("DROITE -> %p | GAUCHE -> %p\n",root->droite, root->gauche);
        printf("\n");
        TREEASC_display(root->droite);
        TREEASC_display(root->gauche);
    }
}