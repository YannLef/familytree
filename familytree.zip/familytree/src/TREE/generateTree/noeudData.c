#include <stdio.h>
#include <stdlib.h>

#include "../../../include/LIST/structure.h"
#include "../../../include/IHM/structures.h"
#include "../../../include/TREE/structure.h"

#include "../../../include/TREE/generationTree/noeudData.h"

void NOEUDDATA_createStructure(NoeudData **noeudData, LIST *ptrIndividu)
{
    NoeudData *ptr = NULL;

    ptr = (NoeudData*)malloc(sizeof(NoeudData));
    
    if(ptr != NULL)
    {
        ptr->nombreEnfantMax = 0;
        ptr->nombreEnfantMaxGeneration = NULL;
        ptr->nombreGeneration = ptrIndividu->u.list_individu->data->generation;
    }
    (*noeudData) = ptr;
}

void NOEUDDATA_deleteStructure(NoeudData **noeudData)
{
    int i;

    if( (*noeudData) != NULL)
    {
        if( (*noeudData)->nombreEnfantMaxGeneration != NULL)
        {
            free((*noeudData)->nombreEnfantMaxGeneration);
            (*noeudData)->nombreEnfantMaxGeneration = NULL;
        }

        free((*noeudData));
        (*noeudData) = NULL;
    }
}

void NOEUDDATA_displayStructure(NoeudData *noeudData)
{
    int i;

    if( noeudData != NULL)
    {
        printf("[NOMBRE DE GENERATION] %d\n", noeudData->nombreGeneration);
        printf("[NOMBRE DE GENERATION MAX] %d\n",noeudData->nombreEnfantMax);

        if( noeudData->nombreEnfantMaxGeneration != NULL)
        {
            printf("NOMBRE ENFANT PAR GEN]\n");
            for( i = 0; i < noeudData->nombreGeneration ; i++)
            {
                printf("\t[Generation %d] -> %d\n",i,noeudData->nombreEnfantMaxGeneration[i]);
            }
        }
    }
}