#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../../../include/LIST/structure.h"
#include "../../../../include/IHM/structures.h"
#include "../../../../include/TREE/structure.h"
#include "../../../../include/TREE/tree/NodeDESC/nodeDESC.h"
#include "../../../../include/TREE/tree/NodeDESC/nodeHeadDESC.h"
#include "../../../../include/IHM/Couleur.h"
#include "../../../../include/IHM/Rectangle.h"

#include "../../../../include/TREE/generationTree/treeDESC/treeDESC.h"

extern couleurTab c; // Définit le tableau de couleurs

NoeudHeadDESC* TREEDESC_createHeadNode(SUBLIST *sublistEnfant, NoeudData **noeudData)
{
    if(sublistEnfant == NULL)
        return NULL;
    else
    { 
        SUBLIST *ptrSubEnfant = sublistEnfant;
        NoeudDESC *ptrHead = NULL;
        NoeudDESC *maillon = NULL;
        int compteurEnfant = 0;

 
        while( ptrSubEnfant != NULL )
        {
            maillon = TREEDESC_initialize(ptrSubEnfant->u.sublist_I->individu, noeudData);
            NODEDESC_insertMaillonHeadList(&ptrHead, &maillon);

            maillon = NULL;
            compteurEnfant++;
            ptrSubEnfant = ptrSubEnfant->u.sublist_I->suivant;
        }

        NoeudHeadDESC *nodeHead = NULL;

        NODEHEADDESC_create(&nodeHead);
        nodeHead->nbEnfants = compteurEnfant;
        nodeHead->ptrListNoeudDESC = ptrHead;

        return nodeHead;
    }
}

NoeudDESC *TREEDESC_initialize(LIST *individu, NoeudData **noeudData)
{
    NoeudDESC *node = NULL;
    NODEDESC_create(&node);
    NODEDESC_insertIndividu(individu, &node);

    if( (*noeudData)->nombreGeneration > individu->u.list_individu->data->generation)
        (*noeudData)->nombreGeneration = individu->u.list_individu->data->generation;

    if (node->ptrIndividu->u.list_individu->data->genre != NULL) {
		if( strcmp(node->ptrIndividu->u.list_individu->data->genre,"m") == 0){
			initRectangle(&(node->rect),0,0,200,100,10,c.blanc,c.couleurHomme);
		}else if(strcmp(node->ptrIndividu->u.list_individu->data->genre,"f") == 0){
			initRectangle(&(node->rect),0,0,200,100,10,c.blanc,c.couleurFemme);
		}else{
			initRectangle(&(node->rect),0,0,200,100,10,c.blanc,c.gris180);
		}
	} else {
		initRectangle(&(node->rect),0,0,200,100,10,c.blanc,c.gris180);	
	}

    
    node->nextNode = TREEDESC_createHeadNode(individu->u.list_individu->sublistIndividu, noeudData);

    return node;
}

void TREEDESC_initializeNoeudData(LIST *individu, NoeudData **noeudData, NoeudDESC *node)
{
    (*noeudData)->nombreGeneration = (individu->u.list_individu->data->generation + 1 ) - ((*noeudData)->nombreGeneration);

    (*noeudData)->nombreEnfantMaxGeneration = (int*)malloc(sizeof(int) * (*noeudData)->nombreGeneration);

    int i;
    for(i = 0; i < (*noeudData)->nombreGeneration ; i++)
    {
        (*noeudData)->nombreEnfantMaxGeneration[i] = 0;
    }
    int compteur = 0;
    NOEUDDATA_noeudDESC(node, noeudData,compteur);

    for( i = 0 ; i < (*noeudData)->nombreGeneration ; i++)
    {
        if((*noeudData)->nombreEnfantMaxGeneration[i] > (*noeudData)->nombreEnfantMax)
            (*noeudData)->nombreEnfantMax = (*noeudData)->nombreEnfantMaxGeneration[i];
    }
}

void displayTreeDESCNode(NoeudDESC *node)
{
    if( node == NULL)
        return;
    else
    {  
        printf("\t [MAILLON] -> %p\n", node);
        printf("\t Nom : %s | Prenom : %s \n", node->ptrIndividu->u.list_individu->data->nom, node->ptrIndividu->u.list_individu->data->prenom);
        printf("\tNext maillon -> %p\n",node->nextMaillon);
        printf("\tNext node : %p\n", node->nextNode);
        displayTreeDESCNodeHead(node->nextNode);   
    }
}

void displayTreeDESCNodeHead(NoeudHeadDESC *node)
{
    if( node == NULL)
        return;
    else
    {
        printf("NODE -> %p\n", node);
        printf("Nb enfant : %d\n", node->nbEnfants);
        printf("List Head -> %p\n", node->ptrListNoeudDESC);

        NoeudDESC *liste = node->ptrListNoeudDESC;

        while( liste != NULL)
        {
            displayTreeDESCNode(liste);
            liste = liste->nextMaillon;
        }
    }   
}


void TREEDESC_freeNoeudDESC(NoeudDESC **node)
{
    if( (*node) == NULL)
        return;
    else
    {   
        NoeudHeadDESC *ptr = (*node)->nextNode;
        TREEDESC_freeNoeudHeadDESC(&ptr); 
        (*node)->nextNode = NULL;    
        (*node)->ptrIndividu = NULL;
        (*node)->nextMaillon = NULL;
        
        free((*node));
        (*node) = NULL; 
         
        #ifdef VERBOSE 
            printf("\t\tnext node : %p\n", (*node)->nextNode);
            printf("\t\tindividu : %p\n", (*node)->ptrIndividu);  
            printf("\t\tnext maillon : %p\n", (*node)->nextMaillon);
            printf("\t[NodeDESC] : %p\n", (*node));   
        #endif
    }
}

void TREEDESC_freeNoeudHeadDESC(NoeudHeadDESC **node)
{
    if( (*node) == NULL)
        return;
    else
    {
        NoeudDESC *liste = (*node)->ptrListNoeudDESC;
        NoeudDESC *tmp = NULL;
        while( liste != NULL)
        {   
            tmp = liste;
            TREEDESC_freeNoeudDESC(&tmp);
            liste = liste->nextMaillon;
        }
        (*node)->nbEnfants = 0;
        (*node)->ptrListNoeudDESC = NULL;
    
        free((*node));
        (*node) = NULL;
        #ifdef VERBOSE
            printf("\tPtr LIST : %p\n", (*node)->ptrListNoeudDESC);
            printf("NODE : %p\n", (*node));
        #endif
    }   
}


void NOEUDDATA_noeudDESC(NoeudDESC *node, NoeudData **noeudData, int compteur)
{
    if( (node) == NULL)
        return;
    else
    {
        if( node->nextNode != NULL)
        {
            if((*noeudData)->nombreEnfantMaxGeneration[compteur] < node->nextNode->nbEnfants)
                (*noeudData)->nombreEnfantMaxGeneration[compteur] = node->nextNode->nbEnfants;
        }
        NOEUDDATA_noeudHeadDESC(node->nextNode, noeudData, compteur ); 
        
    }
}

void NOEUDDATA_noeudHeadDESC(NoeudHeadDESC *node, NoeudData **noeudData, int compteur)
{
    if( (node) == NULL)
        return;
    else
    {
        NoeudDESC *liste = (node)->ptrListNoeudDESC;
        while( liste != NULL)
        {   
            NOEUDDATA_noeudDESC(liste, noeudData, compteur + 1);
            liste = liste->nextMaillon;
        }
    }
}