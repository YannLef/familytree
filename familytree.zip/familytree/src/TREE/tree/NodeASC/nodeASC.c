#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../../../include/LIST/structure.h"
#include "../../../../include/IHM/structures.h"
#include "../../../../include/TREE/structure.h"

#include "../../../../include/IHM/Couleur.h"
#include "../../../../include/IHM/Rectangle.h"

#include "../../../../include/TREE/tree/NodeASC/nodeASC.h"

extern couleurTab c; // Définit le tableau de couleurs

void NODEASC_createNode(NoeudASC **ptrNode)
{
    NoeudASC *node = NULL;

    node = (NoeudASC*)malloc(sizeof(NoeudASC));

    if(node != NULL)
    {
        node->droite = NULL;
        node->gauche = NULL;
        node->ptrIndividu = NULL;
        
        (*ptrNode) = node;
    }
}

void NODEASC_insertData(NoeudASC **ptrNode, LIST *ptrIndvidu, NoeudASC *ptrDroite, NoeudASC *ptrGauche)
{
    (*ptrNode)->droite = ptrDroite;
    (*ptrNode)->gauche = ptrGauche;
    (*ptrNode)->ptrIndividu = ptrIndvidu;
    if (ptrIndvidu->u.list_individu->data->genre != NULL) {
		if( strcmp(ptrIndvidu->u.list_individu->data->genre,"m") == 0 ){
			initRectangle(&((*ptrNode)->rect),0,0,200,100,10,c.blanc,c.couleurHomme);
		}else if(strcmp(ptrIndvidu->u.list_individu->data->genre,"f") == 0){
			initRectangle(&((*ptrNode)->rect),0,0,200,100,10,c.blanc,c.couleurFemme);
		}else{
			initRectangle(&((*ptrNode)->rect),0,0,200,100,10,c.blanc,c.gris180);
		}
	} else {
		initRectangle(&((*ptrNode)->rect),0,0,200,100,10,c.blanc,c.gris180);
	}

}

void NODEASC_deleteData(NoeudASC **ptrNode)
{
    (*ptrNode)->droite = NULL;
    (*ptrNode)->gauche = NULL; 
    (*ptrNode)->ptrIndividu = NULL;
    #ifdef VERBOSE
        printf("\t\tnode parent -> %p\n",(*ptrNode)->ptrIndividu);
        printf("\t\tnode gauche -> %p\n",(*ptrNode)->gauche);
        printf("\t\tnode droite -> %p\n",(*ptrNode)->droite);
    #endif
}

void NODEASC_deleteNode(NoeudASC **ptrNode)
{
    NODEASC_deleteData(ptrNode);

    free((*ptrNode));
    (*ptrNode) = NULL;
    #ifdef VERBOSE
        printf("NODE -> %p\n",(*ptrNode));
    #endif
}