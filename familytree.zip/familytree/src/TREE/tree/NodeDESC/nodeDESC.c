#include <stdio.h>
#include <stdlib.h>

#include "../../../../include/LIST/structure.h"
#include "../../../../include/IHM/structures.h"
#include "../../../../include/TREE/structure.h"

#include "../../../../include/TREE/tree/NodeDESC/nodeDESC.h"


//#include "../../../include/TREE/"

void NODEDESC_create(NoeudDESC **ptrNode)
{
    NoeudDESC *ptr = NULL;

    ptr = (NoeudDESC*)malloc(sizeof(NoeudDESC));

    if( ptr != NULL)
    {
        ptr->ptrIndividu = NULL;
        ptr->nextMaillon = NULL;
        ptr->nextNode = NULL;

        (*ptrNode) = ptr;
    }
}

void NODEDESC_insertIndividu(LIST *ptrIndividu, NoeudDESC **node)
{
    (*node)->ptrIndividu = ptrIndividu;
}

void NODEDESC_insertDatatNextMaillon(NoeudDESC *nextMaillon, NoeudDESC **node)
{
    (*node)->nextMaillon = nextMaillon;
}

void NODEDESC_insertDataNextNode(NoeudHeadDESC *nextNode, NoeudDESC **node)
{
    (*node)->nextNode = nextNode;
}

void NODEDESC_insertMaillonHeadList(NoeudDESC **ptrHead, NoeudDESC **ptrMaillon)
{
    (*ptrMaillon)->nextMaillon = (*ptrHead);
    (*ptrHead) = (*ptrMaillon);
}

void NODEDESC_deleteData(NoeudDESC **node)
{
    (*node)->nextNode = NULL;
    (*node)->ptrIndividu = NULL;
    (*node)->nextMaillon = NULL;
}

void NODEDESC_deleteNode(NoeudDESC **node)
{
    NODEDESC_deleteData(node);

    free((*node));
    (*node) = NULL;
}