#include <stdio.h>
#include <stdlib.h>

#include "../../../../include/LIST/structure.h"
#include "../../../../include/IHM/structures.h"
#include "../../../../include/TREE/structure.h"

#include "../../../../include/TREE/tree/NodeDESC/nodeHeadDESC.h"

void NODEHEADDESC_create(NoeudHeadDESC **ptrNode)
{
    NoeudHeadDESC *ptr = NULL;

    ptr = (NoeudHeadDESC*)malloc(sizeof(NoeudHeadDESC));

    if( ptr != NULL)
    {
        ptr->nbEnfants = 0;
        ptr->ptrListNoeudDESC = NULL;

        (*ptrNode) = ptr;
    }
}

void NODEHEADDESC_insertDataEnfant(int nbEnfant, NoeudHeadDESC **node)
{
    (*node)->nbEnfants = nbEnfant;
}

void NODEHEADDESC_insertDataList(NoeudDESC *list, NoeudHeadDESC **node)
{
    (*node)->ptrListNoeudDESC = list;
}

void NODEHEADDESC_deleteData(NoeudHeadDESC **node)
{
    (*node)->nbEnfants = 0;
    (*node)->ptrListNoeudDESC = NULL;
}

void NODEHEADDESC_deleteNode(NoeudHeadDESC **node)
{
    NODEHEADDESC_deleteNode(node);

    free((*node));
    (*node) = NULL;
}