#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "../../../../GFX/GfxLib.h"
#include "../../../../include/ML//tools/linearRegression.h"
#include "../../../../include/ML/view/components/components.h"

//[BEGIN_BOUNDED_RECTANGLE]

void newBoundedRectangle(
    BoundedRectangle *b,
    int radius,
    int x,
    int y,
    int width,
    int height,
    Color *c,
    int t)
{
    b->r = radius;
    b->x = x;
    b->y = y;
    b->w = width;
    b->h = height;
    b->c = c;
    b->t = t;
}

void drawCircularArc(
    int x_origin,
    int y_origin,
    int radius,
    float theta_min,
    float theta_max)
{
    float step = 2 * PI / NB_POINTS_BOUND;
    int x, y;
    int previous_x = x_origin + radius * cos(theta_min);
    int previous_y = y_origin - radius * sin(theta_min);

    for (float i = theta_min; i < theta_max; i += step)
    {
        x = x_origin + radius * cos(i);
        y = y_origin - radius * sin(i);
        ligne(previous_x, previous_y, x, y);
        previous_x = x;
        previous_y = y;
    }
    x = x_origin + radius * cos(theta_max);
    y = y_origin - radius * sin(theta_max);
    ligne(previous_x, previous_y, x, y);
}

void drawBoundedRectangle(BoundedRectangle *b)
{
    epaisseurDeTrait(b->t);
    couleurCourante(b->c->r, b->c->g, b->c->b);

    ligne(b->x, b->y + b->r, b->x, b->y + b->h - b->r);               //left
    ligne(b->x + b->r, b->y, b->x + b->w - b->r, b->y);               //bottom
    ligne(b->x + b->w, b->y + b->r, b->x + b->w, b->y + b->h - b->r); //right
    ligne(b->x + b->r, b->y + b->h, b->x + b->w - b->r, b->y + b->h); //top

    drawCircularArc(b->x + b->w - b->r, b->y + b->r, b->r, 0, PI * 0.5);               //bottom right
    drawCircularArc(b->x + b->r, b->y + b->r, b->r, PI * 0.5, PI);                   //bottom left
    drawCircularArc(b->x + b->r, b->y + b->h - b->r, b->r, PI, PI * 1.5);            //top left
    drawCircularArc(b->x + b->w - b->r, b->y + b->h - b->r, b->r, PI * 1.5, PI * 2); //top right
}

//[END_BOUNDED_RECTANGLE]

//[BEGIN_GRAPH_COMPONENT]

void newColor(Color *c, int r, int g, int b)
{
    c->r = r;
    c->b = b;
    c->g = g;
}

void newGraph(
    Graph *g,
    BoundedRectangle *frame,
    PointsCloud *data,
    char *mainTitle,
    char *xAxisTitle,
    char *yAxisTitle,
    Color *cp,
    Color *fr,
    Color *li)
{
    g->frame = frame;
    g->data = data;
    g->mainTitle = mainTitle;
    g->xAxisTitle = xAxisTitle;
    g->yAxisTitle = yAxisTitle;
    g->colorOfFrame = fr;
    g->colorOfLine = li;
    g->colorOfPoints = cp;
    if (g->data->nb != 0)
        g->step = g->data->nb + 2;
    else
        g->step = 0;
}

void drawGraph(Graph *g)
{
    drawBoundedRectangle(g->frame);

    couleurCourante(g->colorOfPoints->r,g->colorOfPoints->g,g->colorOfPoints->b);
    for (int i = 0; i < g->data->nb; i++)
    {
        
    }
    
}

