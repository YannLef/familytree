#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../../GFX/GfxLib.h" 
#include "../../../GFX/BmpLib.h"
#include "../../../include/IHM/structures.h"
#include "../../../include/IHM/Conversation.h"
#include "../../../include/LIST/structure.h"
#include "../../../include/ML/tools/strsplit.h"
#include "../../../include/ML/ML.h"

void displayWelcomeMessage(void) {
    printf("Hello, I'm Carole !\n");
    printf("How can I help you ?\n");
}

void displayBotMessageFromQueryInTerminal(token input, searchRequestData** data)
{
    searchRequestData* srd = NULL;
    srd = malloc(sizeof *srd);
    if (srd == NULL) {
        return;
    }

    if (strcmp(input, HELP_COMMAND) == 0) {
        printf("Here is a list of command that you can use : \n");
        printf("!search - search a new place or a date \n");
        printf("!search <search_type> <event_type> <name> <surname> <generation>");
        printf("the search_type means : place or date \n");
        printf("the event_type means : mariage, birth, death \n");
        printf("please provide me all parameters \n");
    }
    else if (strcmp(input, SEARCH_COMMAND) == 0) {
        
    } else {
        tokenner argv;
        unsigned int argc;
        printf("%s \n", input);
        argc = split(input, " ", &argv);
        if (argc == 6) {
            if (strcmp(argv[0], SEARCH_COMMAND) == 0) {
                if (strcmp(argv[1],"place") == 0 ) {
                    srd->st = PLACE;
                } else if (strcmp(argv[1],"date") == 0) {
                    srd->st = DATE;
                } else {
                    printf("The 1st argument is wrong dude ! \n");
                }
                if (strcmp(argv[2],"birth") == 0 ) {
                    srd->et = BIRTH;
                } else if (strcmp(argv[2],"death") == 0) {
                    srd->et = DESCES;
                } else if (strcmp(argv[2],"mariage") == 0) {
                    srd->et = MARIAGE;
                } else {
                    printf("Looks like your 2nd argument is wrong ! \n");
                }

                srd->name = argv[3];
                srd->surname = argv[4];
                srd->generation = atoi(argv[5]);
                (*data) = srd;
            }
        } else {
            printf("missing %d arguments in your request ! \n", 6-argc);
        } 
    }
}

void getChatBotMessageFromRequest(message* response, char* input, int* state, searchRequestData* data)
{
    if (strcmp(input, "hello") == 0) {
        initMessage(response, 0, "Hello, I'm Carole ! How can I help you ?");
    }else if(strcmp(input, "hi") == 0){
        initMessage(response, 0, "Hello, I'm Carole ! How can I help you ?");
	}else if (strcmp(input, "help") == 0) {
        initMessage(response, 0, "Type searchPlace or searchDate to begin !");
    } else if (strcmp(input, "searchPlace") == 0) {
        data->st = PLACE;
        initMessage(response, 0, "What kind of place (wedding, birth, death) !");
        *state = 1;
    } else if (strcmp(input, "searchDate") == 0) {
        data->st = DATE;
        initMessage(response, 0, "What kind of date (wedding, birth, death) !");
        *state = 1;
    } else {
        //~ printf("%d \n", *state);
        if (*state == 0) {
            initMessage(response, 0, "Wtf ?");
        } else if(*state == 1) {
            if (strcmp(input, "wedding") == 0) {
                data->et = MARIAGE;
                initMessage(response, 0, "What's his or her firstname ? !");
                *state = 2;
            } else if (strcmp(input, "death") == 0) {
                data->et = DESCES;
                initMessage(response, 0, "What's his or her firstname ? !");
                *state = 2;
            } else if (strcmp(input, "birth") == 0) {
                data->et = BIRTH;
                initMessage(response, 0, "What's his or her firstname ? !");
                *state = 2;
            } else {
                initMessage(response, 0, "You are kidding right ? try again !");
            }
        } else if(*state == 2) {
            initMessage(response, 0, "What's his or her lastname ? !");
            data->name = malloc((strlen(input) + 1) *sizeof(char));
            int i = 0;
            while( input[i] != '\0') {
                data->name[i] = input[i];
                i++;
            }
            data->name[i] = '\0';
            *state = 3;
        } else if(*state == 3) {
            initMessage(response, 0, "What's his or her generation ? !");
            data->surname = malloc(( strlen(input) + 1) *sizeof(char));
            int i = 0;
            while( input[i] != '\0') {
                data->surname[i] = input[i];
                i++;
            }
            data->surname[i] = '\0';
            *state = 4;
        } else if(*state == 4) {
            data->generation = atoi(input);
            initMessage(response, 0, "Ok hold on a sec ...");
            *state = 5;
        } 
    }
}
