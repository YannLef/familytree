#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../../../include/LIST/structure.h"
#include "../../../../include/ML/list/event/Event.h"
#include "../../../../include/ML/tools/average.h"
#include "../../../../include/ML/model/Score.h"
#include "../../../../include/ML/model/Coordinate.h"
#include "../../../../include/ML/list/place/Place.h"

void searchPreviousPlaceNode(Place *head, Place **searched, Place *insert) {
	Place *tmp = head;
	Place *prec = NULL;
	
	while( tmp != NULL && strcmp(tmp->data->name, insert->data->name) < 0) {
		prec = tmp;
		tmp = tmp->next;
	}
	(*searched) = prec;
}

void insertPlaceNode(Place **head, Place *insert) {
	Place *prec = NULL;
	
	searchPreviousPlaceNode(*head, &prec, insert);
	
	if( prec == NULL) {
		insert->next = (*head);
		(*head) = insert;
	} else {
		insert->next = prec->next;
		prec->next = insert;
	}
}

void freePlace(Place **p) {
    if ((*p) != NULL) {
        if ((*p)->data->listOfEvent != NULL) {
            deleteListOfEvent(&((*p)->data->listOfEvent));
        }
        if ((*p)->data->scoreOfPlace->arrayOfAverages != NULL) {
#ifdef VERBOSE
            printf("[LOG] clear averages ... : %p \n", (*p)->data->scoreOfPlace->arrayOfAverages);
#endif
            clearAllDataOfAverage(&((*p)->data->scoreOfPlace->arrayOfAverages[AVERAGE_YEAR_OF_MARIAGE_ALL]));
            clearAllDataOfAverage(&((*p)->data->scoreOfPlace->arrayOfAverages[AVERAGE_YEAR_OF_DEATH_ALL]));
            clearAllDataOfAverage(&((*p)->data->scoreOfPlace->arrayOfAverages[AVERAGE_YEAR_OF_BIRTH_ALL]));
#ifdef VERBOSE
            printf("[LOG] averages cleaned ... \n");
#endif
        }
        free((*p)->data->scoreOfPlace->arrayOfAverages);
        (*p)->data->scoreOfPlace->arrayOfAverages = NULL;

        free((*p)->data->scoreOfPlace);
        (*p)->data->scoreOfPlace = NULL;

        free((*p)->data->geographicalPosition);
        (*p)->data->geographicalPosition = NULL;

        free((*p)->data);
        (*p)->data = NULL;

        (*p)->next = NULL;

        free((*p));
        (*p) = NULL;
    }
}

void deleteListOfPlace(Place **head) {
	if ( head != NULL) {
		Place *tmp = NULL;
		
		while( (*head) != NULL ) {
			tmp = (*head);
			(*head) = (*head)->next;
			#ifdef VERBOSE
				printf("[LOG] tmp place -> %p \n", tmp);
			#endif
			freePlace(&tmp);
			#ifdef VERBOSE
				printf("[LOG] tmp place OK \n");
			#endif
		}
		head = NULL;
	}
}	

void deletePlace(Place **head, Place *toDelete) {
	Place *prec = NULL;
	
	searchPreviousPlaceNode(*head, &prec, toDelete);
	
	if( prec == NULL) {
		(*head) = toDelete->next;
		freePlace(&toDelete);
		toDelete->next = NULL;
	} else {
		prec->next = toDelete->next;
		freePlace(&toDelete);
		toDelete->next = NULL;
	}
}

void createPlace(Place **ptr) {
	(*ptr) = NULL;
	Place *p = NULL;
	p = malloc(sizeof *p);
	if (p == NULL) {
	    printf("[ERROR malloc place \n");
	    return;
	}
	p->next = NULL;
	p->data = NULL;
	p->data = malloc(sizeof(*(p->data)));
	if (p->data == NULL) {
	    printf("[ERROR] malloc place data \n");
	    return;
	}
    //score
    p->data->scoreOfPlace = NULL;
	p->data->scoreOfPlace = malloc(sizeof *(p->data->scoreOfPlace));
    if (p->data->scoreOfPlace == NULL) {
        printf("[ERROR] malloc score create place");
        return;
    }
    //coordinate
    p->data->geographicalPosition = malloc(sizeof *(p->data->geographicalPosition));
    if (p->data->geographicalPosition == NULL) {
        printf("[ERROR] malloc coordinate create place");
        return;
    }
    p->data->listOfEvent = NULL;
    p->data->name = NULL;
    p->next = NULL;
    (*ptr) = p;
}

int insertPlace(Place **head, char* name) {
	Place *p = NULL;
	int nbPlaceCreated = 0;
	searchPlace(*head, &p, name);
	if (p == NULL) {
		nbPlaceCreated = 1;
		createPlace(&p);
		
		p->data->name = name;
		#ifdef VERBOSE
			printf("[LOG] fetching coordinate ... \n");
		#endif
		newCoordinateFromCityName(&(p->data->geographicalPosition), name, "../assets/db/villes.db");
		#ifdef VERBOSE
			printf("[LOG] coordinate finded : %f , %f \n", p->data->geographicalPosition->latitude, p->data->geographicalPosition->longitude);
			printf("[LOG] score allocation ... \n");
		#endif
		newScore(&(p->data->scoreOfPlace));
		#ifdef VERBOSE
			printf("[LOG] score allocated \n");
		#endif

		for(int i = 0; i < MIN_AVERAGE_IN_SCORE; i++) {
			newAverageInScore(p->data->scoreOfPlace);
		}

		p->data->listOfEvent = NULL;
		p->data->numberOfEvent = 0;
		#ifdef VERBOSE
			printf("[LOG] insert the place in list ... \n");
		#endif
		insertPlaceNode(head, p);
		#ifdef VERBOSE
			printf("[LOG] place inserted \n");
		#endif
	} else {
		#ifdef VERBOSE
			printf("[LOG] %s already exist ! \n", name);
		#endif
	}
	return nbPlaceCreated;
}

void displayPlace(Place *p){
	if (p != NULL) {
		printf("[PLACE] name-> %s nb_event -> %d \n",p->data->name, p->data->numberOfEvent);
		printCoordinate(p->data->geographicalPosition);
		printScore(p->data->scoreOfPlace);
		ptrFunc *f = initPtrFunc();
		displayListEvent(p->data->listOfEvent, f);
		freePtrFunc(&f);
	}
}

void displayListOfPlace(Place *head){
	if ( head != NULL) {
		Place *tmp = head;
		while( tmp != NULL ) {
			displayPlace(tmp);
			tmp = tmp->next;
		}
	}
}

Event** getEventListOfPlace(Place *head, char* name) {
	Place *tmp = head;
	while( strcmp(tmp->data->name, name) != 0 ) {
		tmp = tmp->next;
	}
	return &(tmp->data->listOfEvent);
}

void searchPlace(Place *head, Place **searched, char* name)
{
	if (head != NULL) {
		(*searched) = NULL;
		Place *tmp = head;
		while(tmp != NULL) {
			if (strcmp(tmp->data->name, name) == 0 || strcmp(tmp->data->name, name) == 32 ) {
				(*searched) = tmp;
			} 
			tmp = tmp->next;
		}
	}
}

void findPlaceWithMaxEvent(Place *head, Place **searched)
{
	Place *tmp = head;
	int nb = 0;
	while(tmp != NULL) { 
		if (tmp->data->numberOfEvent > nb) {
			nb = tmp->data->numberOfEvent;
			(*searched) = tmp;
		}
		tmp = tmp->next;
	}
}

void insertBirthInPlace(Place *head, list_individu* individu)
{
	if (individu != NULL && individu->data->lieuNaissance != NULL) {
		Place *p;
		searchPlace(head, &p, individu->data->lieuNaissance);
		if (p == NULL) {
			printf("[ERROR] can't find the place %s \n", individu->data->lieuNaissance);
			return;
		}
		ptrFunc *f = initPtrFunc();
		#ifdef VERBOSE
			printf("[LOG] insert event ... \n");
		#endif
		insertBirth(&(p->data->listOfEvent), f, individu);
		#ifdef VERBOSE
			printf("[LOG] inserted sucessfully \n");
		#endif
		freePtrFunc(&f);

		#ifdef VERBOSE
			printf("[LOG] increasing score ... \n");
		#endif
		(p->data->numberOfEvent)++;
		(p->data->scoreOfPlace->births_counter)++;
		
		#ifdef VERBOSE
			printf("[LOG] add data to average \n");
		#endif
			if (individu->data->naissance != NULL && individu->data->naissance->annee != 0) {
			addDataToAverage(&(p->data->scoreOfPlace->arrayOfAverages[AVERAGE_YEAR_OF_BIRTH_ALL]), individu->data->naissance->annee);
			
			#ifdef VERBOSE
				printf("[LOG] computing averages ... \n");
			#endif
			computeAverage(&(p->data->scoreOfPlace->arrayOfAverages[AVERAGE_YEAR_OF_BIRTH_ALL]));
			computeStandardErrorOfAverage(&(p->data->scoreOfPlace->arrayOfAverages[AVERAGE_YEAR_OF_BIRTH_ALL]));
			
			computeScoreGlobalStandardError(p->data->scoreOfPlace);
		}
		#ifdef VERBOSE
			printf("[LOG] birth sucessfully inserted \n");
		#endif 
	}
}


void insertDeathInPlace(Place *head, list_individu* individu)
{
	if (individu != NULL && individu->data->lieuDeces != NULL) {
		Place *p = NULL;
		searchPlace(head, &p, individu->data->lieuDeces);
		if (p == NULL) {
			printf("[ERROR] can't find the place %s \n", individu->data->lieuDeces);
			return;
		}
		ptrFunc *f = initPtrFunc();
		insertDeath(&(p->data->listOfEvent), f, individu);
		freePtrFunc(&f);

		#ifdef VERBOSE
			printf("[LOG] increasing score ... \n");
		#endif
		(p->data->numberOfEvent)++;
		(p->data->scoreOfPlace->desces_counter)++;
		
		#ifdef VERBOSE
			printf("[LOG] add data to average \n");
		#endif
		if (individu->data->deces != NULL && individu->data->deces->annee != 0) {
			addDataToAverage(&(p->data->scoreOfPlace->arrayOfAverages[AVERAGE_YEAR_OF_DEATH_ALL]), individu->data->deces->annee);	
			#ifdef VERBOSE
				printf("[LOG] computing averages ... \n");
			#endif
			computeAverage(&(p->data->scoreOfPlace->arrayOfAverages[AVERAGE_YEAR_OF_DEATH_ALL]));
			computeStandardErrorOfAverage(&(p->data->scoreOfPlace->arrayOfAverages[AVERAGE_YEAR_OF_DEATH_ALL]));
			
			computeScoreGlobalStandardError(p->data->scoreOfPlace);
		}
		#ifdef VERBOSE
			printf("[LOG] death sucessfully inserted \n");
		#endif 
	}
}

void insertMariageInPlace(Place *head, list_mariage* mariage)
{
	if (mariage != NULL && mariage->data->lieu != NULL) {
		Place *p;
		searchPlace(head, &p, mariage->data->lieu);
		if (p == NULL) {
			printf("[ERROR] can't find the place %s \n", mariage->data->lieu);
			return;
		}
		ptrFunc *f = initPtrFunc();
		insertMariage(&(p->data->listOfEvent), f, mariage);
		freePtrFunc(&f);

		#ifdef VERBOSE
			printf("[LOG] increasing score ... \n");
		#endif
		(p->data->numberOfEvent)++;
		(p->data->scoreOfPlace->mariages_counter)++;
		
		#ifdef VERBOSE
			printf("[LOG] add data to average \n");
		#endif
		if (mariage->data->date != NULL && mariage->data->date->annee != 0) {
			addDataToAverage(&(p->data->scoreOfPlace->arrayOfAverages[AVERAGE_YEAR_OF_MARIAGE_ALL]), mariage->data->date->annee);
			
			#ifdef VERBOSE
				printf("[LOG] computing averages ... \n");
			#endif
			computeAverage(&(p->data->scoreOfPlace->arrayOfAverages[AVERAGE_YEAR_OF_MARIAGE_ALL]));
			computeStandardErrorOfAverage(&(p->data->scoreOfPlace->arrayOfAverages[AVERAGE_YEAR_OF_MARIAGE_ALL]));
			
			computeScoreGlobalStandardError(p->data->scoreOfPlace);
		}
		#ifdef VERBOSE
			printf("[LOG] mariage sucessfully inserted \n");
		#endif 		
	}
}

void fetchDataBaseOfCityInFile(char *pathToDb, char *pathToFile)
{
	char command[200];
    strcpy(command, "sqlite3 ");
    strcat(command, pathToDb);
    strcat(command, " \"SELECT nom,latitude,longitude FROM villes ORDER BY nom\"");
    strcat(command, " > ");
	strcat(command, pathToFile);
    #ifdef VERBOSE
		printf("[LOG] command -> %s , length -> %ld \n", command, strlen(command));
	#endif
    int error = system(command);
}