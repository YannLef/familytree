#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../../../include/LIST/structure.h"
#include "../../../../include/ML/list/event/Event.h"

void displayEventDesces(Event *ptr)
{
    printf("\t[EVENT] type-> %d \n",ptr->data->typeOfEvent);
    if (ptr->data->desc.i != NULL) {
        if (ptr->data->desc.i->data->nom != NULL && ptr->data->desc.i->data->prenom != NULL)
            printf("\t\t[NAME] %s %s \n", ptr->data->desc.i->data->nom, ptr->data->desc.i->data->prenom);
        if (ptr->data->desc.i->data->deces != NULL) 
            printf("\t\t[DATE] %d/%d/%d \n",ptr->data->desc.i->data->deces->jour,ptr->data->desc.i->data->deces->moi,ptr->data->desc.i->data->deces->annee);
        if (ptr->data->desc.i->data->lieuDeces)
        printf("\t\t[LIEU] %s \n", ptr->data->desc.i->data->lieuDeces);
    }
}

void displayEventMariage(Event *ptr)
{
    printf("\t[EVENT] type-> %d \n", ptr->data->typeOfEvent);
    if (ptr->data->desc.m != NULL) {
        if (ptr->data->desc.m->data != NULL && ptr->data->desc.m->data->date != NULL && ptr->data->desc.m->data->lieu != NULL) {
            if (ptr->data->desc.m->c1 != NULL && ptr->data->desc.m->c1 != NULL) {
                printf("\t\t[MARIAGE] data -> %s %s maried with %s %s on %d/%d/%d at %s \n", 
                    ptr->data->desc.m->c1->u.list_individu->data->nom, 
                    ptr->data->desc.m->c1->u.list_individu->data->prenom,
                    ptr->data->desc.m->c2->u.list_individu->data->nom, 
                    ptr->data->desc.m->c2->u.list_individu->data->prenom,
                    ptr->data->desc.m->data->date->jour,
                    ptr->data->desc.m->data->date->moi,
                    ptr->data->desc.m->data->date->annee,
                    ptr->data->desc.m->data->lieu
                );
            }
        }
    }
}

void displayEventBirth(Event *ptr)
{
    printf("\t[EVENT] type-> %d \n",ptr->data->typeOfEvent);
    if (ptr->data->desc.i != NULL) {
        if (ptr->data->desc.i->data != NULL) {
            if (ptr->data->desc.i->data->nom != NULL && ptr->data->desc.i->data->prenom != NULL)
                printf("\t\t[NAME] %s %s \n", ptr->data->desc.i->data->nom, ptr->data->desc.i->data->prenom);
            if (ptr->data->desc.i->data->naissance != NULL)
                printf("\t\t[DATE] %d/%d/%d \n",ptr->data->desc.i->data->naissance->jour,ptr->data->desc.i->data->naissance->moi,ptr->data->desc.i->data->naissance->annee);
            if (ptr->data->desc.i->data->lieuNaissance != NULL)
                printf("\t\t[LIEU] %s \n", ptr->data->desc.i->data->lieuNaissance);
        }
    }
}

int compareDates(m_date* d1, m_date* d2)
{
    #ifdef VERBOSE
        printf("[LOG] comparison between d1 -> %p and d2 -> %p \n", d1, d2);
    #endif
    int equals = -2;
    if (d1 != NULL && d2 != NULL) {
        if (d1->annee < d2->annee) {
            equals = -1;
        } else if (d1->annee > d2->annee) {
            equals = 1;
        } else {
            if (d1->moi == d2->moi) {
                if (d1->jour == d2->jour) {
                    equals = 0;
                } else if (d1->jour < d2->jour) {
                    equals = -1;
                } else {
                    equals = 1;
                }
            } else if (d1->moi < d2->moi) {
                equals = -1;
            } else {
                equals = 1;
            }
        }
    } 
    #ifdef VERBOSE
        printf("[LOG] equals -> %d \n", equals);
    #endif
    return equals;
}

int compareEventsMariage(Event *e1, Event *e2) {
    int equals = -2;
    if (e1->data->typeOfEvent == e2->data->typeOfEvent) {
        if (e1->data->desc.m->data->date != NULL && e2->data->desc.m->data->date != NULL)
            equals = compareDates(e1->data->desc.m->data->date, e2->data->desc.m->data->date);
    } 
    return equals;
}

int compareEventsDesces(Event *e1, Event *e2) 
{
    int equals = -2;
    if (e1->data->typeOfEvent == e2->data->typeOfEvent) {
        equals = compareDates(e1->data->desc.i->data->deces, e2->data->desc.i->data->deces);
    } 
    return equals;
}

int compareEventsBirth(Event *e1, Event *e2) 
{
    int equals = -2;
    if (e1->data->typeOfEvent == e2->data->typeOfEvent) {
        equals = compareDates(e1->data->desc.i->data->naissance, e2->data->desc.i->data->naissance);
    } 
    return equals;
}

void searchPreviousEventDesces(Event *head, Event **searched, Event *insert)
{
    Event *tmp = head;
    (*searched) = NULL;
    #ifdef VERBOSE
        printf("[LOG] searching previous ... \n");
    #endif
    while( tmp != NULL)
    {
        if (compareEventsDesces(tmp, insert) == 1)
            (*searched) = tmp;
        tmp = tmp->next;
    }
}

void searchPreviousEventMariage(Event *head, Event **searched, Event *insert)
{
    Event *tmp = head;
    (*searched) = NULL;
    while( tmp != NULL)
    {
        if (compareEventsMariage(tmp, insert) == 1) 
            (*searched) = tmp;
        tmp = tmp->next;
    }
}

void searchPreviousEventBirth(Event *head, Event **searched, Event *insert)
{
    Event *tmp = head;
    (*searched) = NULL;
    #ifdef VERBOSE
        printf("[LOG] searching previous ... \n");
    #endif
    while( tmp != NULL)
    {
        if (compareEventsBirth(tmp, insert) == 1)
            (*searched) = tmp;
            
        tmp = tmp->next;
    }
}

ptrFunc* initPtrFunc(void)
{
    ptrFunc *ptr = NULL;
    ptr = malloc(sizeof *ptr);
    if (ptr == NULL)
        return NULL;

    ptr->ptrSearchEvent[DESCES] = &searchPreviousEventDesces;
    ptr->ptrSearchEvent[MARIAGE] = &searchPreviousEventMariage;
    ptr->ptrSearchEvent[BIRTH] = &searchPreviousEventBirth;

    ptr->ptrDisplayList[DESCES] = &displayEventDesces;
    ptr->ptrDisplayList[MARIAGE] = &displayEventMariage;
    ptr->ptrDisplayList[BIRTH] = &displayEventBirth;

    return ptr;
}

void freePtrFunc(ptrFunc** f) 
{
    free(*f);
    *f = NULL;
}

void createEvent(Event **ptr)
{
    #ifdef VERBOSE
        printf("[LOG] create an event \n");
    #endif
    (*ptr) = NULL;
    Event *e = malloc(sizeof *e);
    if (e == NULL) {
        printf("[ERROR] malloc event \n");
        return;
    }
    e->next = NULL;

    e->data = NULL;
    e->data = malloc(sizeof *(e->data));
    if (e->data == NULL) {
        printf("[ERROR malloc event data \n");
        return;
    }

    (*ptr) = e;

    #ifdef VERBOSE    
        printf("[LOG] event created \n");
    #endif
}

void displayListEvent(Event *head, ptrFunc *f)
{
    Event *tmp = head;
    while (tmp != NULL)
    {
        (*(f->ptrDisplayList[tmp->data->typeOfEvent]))(tmp);
        tmp = tmp->next;
    }
}

void freeEvent(Event **e)
{
    if (e != NULL) {
        if ((*e)->data != NULL) {
            free((*e)->data);
            (*e)->data = NULL;
        }
        free((*e));
        (*e) = NULL;
    }
}

void insertEventNode(Event **head, Event *insert, ptrFunc *f)
{
    Event *prec = NULL;
    #ifdef VERBOSE
        printf("[LOG] %d \n", insert->data->typeOfEvent);
    #endif
    (*(f->ptrSearchEvent[insert->data->typeOfEvent]))((*head), &prec, insert);
    #ifdef VERBOSE
        printf("[LOG] prec -> %p \n", prec);
    #endif
    
    if( prec == NULL) {
        insert->next = (*head);
        (*head) = insert;
    } else {
        insert->next = prec->next;
        prec->next = insert;
    } 
}

void deleteListOfEvent(Event **head)
{
    if ( head != NULL) {
        Event *tmp = NULL;

        while( (*head) != NULL ) {
            tmp = (*head);
            (*head) = (*head)->next;
            freeEvent(&tmp);
        }
        free( (*head) );
        (*head) = NULL;
    }
}

void deleteEvent(Event **head, Event *toDelete, ptrFunc *f)
{
    Event *prec = NULL;
    (*(f->ptrSearchEvent[toDelete->data->typeOfEvent]))((*head), &prec, toDelete);

    if( prec == NULL) {
        (*head) = toDelete->next;
        toDelete->next = NULL;
    } else {
        prec->next = toDelete->next;
        toDelete->next = NULL;
    }
}

void insertMariage(Event **head, ptrFunc *f, list_mariage* mariage)
{
    Event *newEvent = NULL;
    createEvent(&newEvent);
    if (newEvent != NULL) {
        newEvent->data->typeOfEvent = MARIAGE;
        newEvent->data->desc.m = mariage;
        insertEventNode(head, newEvent, f);
    }
}

void insertDeath(Event **head, ptrFunc *f, list_individu* individu)
{
    Event *newEvent = NULL;
    createEvent(&newEvent);
    if (newEvent != NULL) {
        newEvent->data->typeOfEvent = DESCES;
        newEvent->data->desc.i = individu;
#ifdef VERBOSE
        printf("[LOG] insert node \n");
#endif
        insertEventNode(head, newEvent, f);
    }
}

void insertBirth(Event **head, ptrFunc *f, list_individu* individu)
{
    Event *newEvent = NULL;
    createEvent(&newEvent);
    #ifdef VERBOSE
        printf("[LOG] creating a birth event \n");
    #endif
    if (newEvent != NULL) {
        newEvent->data->typeOfEvent = BIRTH;
        newEvent->data->desc.i = individu;
#ifdef VERBOSE
        printf("[LOG] type and data inserted \n");
#endif
        insertEventNode(head, newEvent, f);
#ifdef VERBOSE
        printf("[LOG] birth node inserted \n");
#endif
    }

}