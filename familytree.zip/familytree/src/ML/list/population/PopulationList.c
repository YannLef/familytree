#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../../../include/LIST/structure.h"
#include "../../../../include/ML/list/event/Event.h"
#include "../../../../include/ML/tools/average.h"
#include "../../../../include/ML/model/Score.h"
#include "../../../../include/ML/model/Coordinate.h"
#include "../../../../include/ML/list/place/Place.h"
#include "../../../../include/ML/model/Population.h"

#include "../../../../include/ML/list/population/PopulationList.h" 


void searchPreviousPopulationListNode(PopulationList *head, PopulationList **searched, PopulationList *insert)
{
    PopulationList *tmp = head;
	PopulationList *prec = NULL;
	#ifdef VERBOSE
		printf("[LOG] begin searching ... with insert -> %p \n", insert);
	#endif
	if(insert != NULL ) {
		while( tmp != NULL) {
			if (tmp->data != NULL && insert->data != NULL) {
				if (tmp->data->nbPlace > insert->data->nbPlace)
					prec = tmp;
			}
			tmp = tmp->next;
		}
	}
	#ifdef VERBOSE
		printf("[LOG] finish searching previous \n");
	#endif
	(*searched) = prec;
}

void insertPopulationListNode(PopulationList **head, PopulationList *insert)
{
	PopulationList *prec = NULL;
	#ifdef VERBOSE
		printf("[LOG] searching previous \n");
	#endif
	searchPreviousPopulationListNode(*head, &prec, insert);
	#ifdef VERBOSE
		printf("[LOG] prec -> %p \n", prec);
	#endif
	if( prec == NULL) {
		#ifdef VERBOSE
			printf("[LOG] insert in head of the list \n");
		#endif
		insert->next = (*head);
		(*head) = insert;
	} else {
		#ifdef VERBOSE
			printf("[LOG] found previous of type %d \n", prec->data->typeOfPopulation);
		#endif
		insert->next = prec->next;
		prec->next = insert;
	}
}

void insertPopulationList(PopulationList **head, Population *p)
{
    PopulationList *node = NULL;
    createPopulationList(&node);
	#ifdef VERBOSE
		printf("[LOG] Population node created \n");
	#endif
    #ifdef VERBOSE
		printf("[LOG] population to add in node : %p \n", p);
	#endif
	if (p != NULL)
		node->data = p;
	else
		node->data = NULL;
	node->next = NULL;
    insertPopulationListNode(head, node);
	#ifdef VERBOSE
		printf("[LOG] node inserted \n");
	#endif
}

void freePopulationList(PopulationList **p)
{
	if ( p != NULL) {
		#ifdef VERBOSE
			printf("[LOG] free population list data at %p \n", (*p)->data);
		#endif
		freePopulation(&((*p)->data));
		p = NULL;
	}
}

void deleteListOfPopulationList(PopulationList **head)
{
	if ( head != NULL) {
		PopulationList *tmp = NULL;
		#ifdef VERBOSE
			printf("[LOG] browse list of population list to free \n");
		#endif
		while( (*head) != NULL ) {
			tmp = (*head);
			(*head) = (*head)->next;
			freePopulationList(&tmp);
		}
		#ifdef VERBOSE
			printf("[LOG] population list free ok \n");
        #endif
	}
}	

void deletePopulationList(PopulationList **head, PopulationList *toDelete)
{
	PopulationList *prec = NULL;
	
	searchPreviousPopulationListNode(*head, &prec, toDelete);
	
	if( prec == NULL) {
		(*head) = toDelete->next;
		freePopulationList(&toDelete);
		toDelete->next = NULL;
	} else {
		prec->next = toDelete->next;
		freePopulationList(&toDelete);
		toDelete->next = NULL;
	}
}

void createPopulationList(PopulationList **ptr)
{
	(*ptr) = NULL;
	PopulationList *p = NULL;
	p = malloc(sizeof *p);
	if (p == NULL) {
		printf("[ERROR] malloc populationList \n");
		return;
	}

	p->data = malloc(sizeof(*(p->data)));
	if (p->data == NULL) {
		printf("[ERROR] malloc populationList data \n");
		return;
	}
	p->data->historyOfPlaceFrequented=NULL;

	p->next = NULL;
	(*ptr) = p;
}

void displayListOfPopulationList(PopulationList *head)
{
	if ( head != NULL) {
		PopulationList *tmp = head;
		while( tmp != NULL ) {
			displayPopulation(tmp->data);
			tmp = tmp->next;
		}
	}
}

void searchPopulationList(PopulationList *head, PopulationList **searched, int nbEvent, population_type type)
{
	if (head != NULL) {
		(*searched) = NULL;
		PopulationList *tmp = head;
		while(tmp != NULL) {
			if (tmp->data->typeOfPopulation == type || nbEvent == tmp->data->nbPlace ) {
				(*searched) = tmp;
			} 
			tmp = tmp->next;
		}
	}
}

int newPopulationListFromDataList(PopulationList **head, population_type type, LIST *data)
{
    #ifdef VERBOSE
		printf("[POPULATION_LIST] type -> %d \n", type);
	#endif
	Population *tmpPopulation = NULL;
    LIST *tmp = data;
    ptrFuncPopulation *f = initPtrFuncPopulation();
	int nb_population = 0;
	while(tmp != NULL) {
        #ifdef VERBOSE
			printf("[LOG] individu -> %s %s \n", tmp->u.list_individu->data->nom, tmp->u.list_individu->data->prenom);
        	printf("\t[LOG] create population \n");
		#endif
		f->tab[type](&tmpPopulation, tmp);
		//displayPopulation(tmpPopulation);
	
		tmp = tmp->u.list_individu->suivant;
		
        #ifdef VERBOSE
			printf("\t[LOG] succes creating population \n");
		#endif
        //displayPopulation(tmpPopulation);
		#ifdef VERBOSE
			printf("[LOG] population displayed \n");
		#endif
        insertPopulationList(head, tmpPopulation);
		nb_population++;
		#ifdef VERBOSE
			printf("[LOG] insertion in list ok \n");
        #endif
    }
    freePtrFuncPopulation(&f);
	return nb_population;
}