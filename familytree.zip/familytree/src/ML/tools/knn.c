#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "../../../include/ML/tools/knn.h"

void getEuclidianDistance(double *distance, Point p1, Point p2)
{
    *distance = sqrt( (p2.x - p1.x)*(p2.x - p1.x) + (p2.y - p1.y)*(p2.y - p1.y) );
}

