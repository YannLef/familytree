#include <stdio.h>
#include <stdlib.h>

#include "../../../include/ML/tools/linearRegression.h"

void newPointsCloud(PointsCloud *pc, int nb)
{
    pc->nb = nb;
    pc->x = malloc(nb * sizeof *(pc->x));
    pc->y = malloc(nb * sizeof *(pc->y));
}

void clearPointsCloud(PointsCloud *pc)
{
    free(pc->x);
    pc->x = NULL;   
    free(pc->y);
    pc->y = NULL;
}

void printPointsCloud(PointsCloud *pc)
{
    for ( unsigned int point = 0; point < pc->nb; point++)
    {
        printf("Point : %d {x: %f, y: %f }", point, pc->x[point], pc->y[point]);
    }
}

void savePointsCloud(PointsCloud *pc, char *filename)
{
    //openthe file called filename
    FILE *f = fopen(filename, "w");
    //manage exeption
    if (f == NULL)
    {
        printf("error : file could not be open !");
        return;
    }
    //write the number of points
    fprintf(f, "%d\n", pc->nb);
    //for each points
    for (int point = 0; point < pc->nb; point++)
    {
        //write in the file according to the format specified 
        fprintf(f, "{x: %f, y: %f }\n", pc->x[point], pc->y[point]);
    }
    //close the file
    fclose(f);
}

void readPointsCloud(PointsCloud *pc, char *filename)
{
    int nb; //tmp variable to store the number of point
    
    //open the file
    FILE *f = fopen(filename, "r");
    //exception
    if (f == NULL)
    {
        printf("error : file could not be open !");
        return;
    }
    //scan the number of point
    fscanf(f, "%d\n", &nb);
    
    //create a point of cloud
    newPointsCloud(pc, nb);
    
    //for each point
    for (int point = 0; point < pc->nb; point++)
    {
        //scan it
        fscanf(f, "{x: %lf, y: %lf }\n", &(pc->x[point]), &(pc->y[point]));
    }
    //close the file
    fclose(f);
}

void copyPointsCloudAtoB(PointsCloud *a, PointsCloud *b)
{
    //the second points of cloud is not NULL
    if (b != NULL)
    {
        //free it
        free(b->x);
        free(b->y);
        b->x = NULL;
        b->y = NULL;
    }

    //copy the number of points
    b->nb = a->nb;

    //allocate the table to store the value of a
    b->x = malloc((b->nb) * sizeof *(b->x));
    //exception
    if (b->x == NULL)
        return;

    //allocate the table to store the value of b
    b->y = malloc((b->nb) * sizeof *(b->y));
    //exception
    if (b->y == NULL)
        return;
    //for each point in a, copy it to b
    for (int point = 0; point < a->nb; point++)
    {
        b->x[point] = a->x[point];
        b->y[point] = a->y[point];
    }
}

void addValueToPointsCloud(PointsCloud *pc, double x, double y)
{
    //increment nb
    (pc->nb)++;

    //reallocate pc->x and pc->y
    pc->x = realloc(pc->x, pc->nb * sizeof *(pc->x));
    if (pc->x == NULL)
    {
        printf("error reallocation \n");
        return;
    }

    pc->y = realloc(pc->y, pc->nb * sizeof *(pc->y));
    if (pc->y == NULL)
    {
        printf("error reallocation \n");
        return;
    }

    //add x and y
    pc->x[pc->nb - 1] = x;
    pc->y[pc->nb - 1] = y;
}

void computeQuickAverage(double *average, double *data, int n)
{
    //for each value in data, sum it to average
    for (unsigned int i = 0; i < n; i++)
    {
        *average = *average + data[i];
    }
    //divide the result by the number of value
    *average = *average / n;
}

void computeSumOfDouble(double* sum,double** data, int* n)
{
    //reinitialize sum
    *sum = 0;    
    //for each value in data, sum it to the pointer's value sum
    for(int i = 0; i < *n; i++){
        *sum += (*data)[i];
    }
    
}

void computeSumOfDoubleOfXY(double* sum,double** x,double** y, int* n)
{
    double product; //tmp variable

    //init
    *sum = 0; 

    //for each value in x and y
    for(int i = 0; i < *n; i++){
        //compute the product
        product = (*x)[i] * (*y)[i];
        //sum it to sum
        *sum += product;
    }
}

void newPolynome(Polynome *p, int degre)
{
    //init the degre
    p->degre = degre;
    //allocate the table of coefficient of degre cells
    p->tabCoeff = malloc(degre * sizeof *(p->tabCoeff));
    //exception
    if (p->tabCoeff == NULL)
    {
        printf("error allocation tabCoeff in p ! \n");
        return;
    }
    //init to 0 each cell of tabCoeff
    for(int i = 0; i < p->degre ; i++){
        p->tabCoeff[0] = 0;
    }

    
}

void addCoeff(Polynome *p, double coeff)
{
    //increment the degree
    (p->degre)++;
    //reallocate the table of coefficient
    p->tabCoeff = realloc(p->tabCoeff, p->degre * sizeof *(p->tabCoeff));
    //exception
    if (p->tabCoeff == NULL)
    {
        printf("error reallocation \n");
        return;
    }
    //add the new coefficient add the end in the table
    p->tabCoeff[p->degre - 1] = coeff;
}

void clearPolynome(Polynome *p)
{
    if(p->tabCoeff != NULL){
        free(p->tabCoeff);
        p->tabCoeff = NULL;
    }
}

void computeIdealPolynome(LinearRegression *lr, PointsCloud *pc)
{    
    //tmp variable to compute ŷ = a*x+b with :
    // a = a1 / divider
    // b = b1 / divider
    double a1,b1,divider;
    
    //init the polynome of 2 coefficient (linear polynome)
    newPolynome(&(lr->ideal), 2);
    
    //compute sumX
    computeSumOfDouble(&(lr->sumX),&(pc->x),&(pc->nb));
    //compute sumY
    computeSumOfDouble(&(lr->sumY),&(pc->y),&(pc->nb));

    //compute sumXY
    computeSumOfDoubleOfXY(&(lr->sumXY), &(pc->x), &(pc->y), &(pc->nb));
    //compute sumXX
    computeSumOfDoubleOfXY(&(lr->sumXX), &(pc->x), &(pc->x), &(pc->nb));
    //compute sumYY
    computeSumOfDoubleOfXY(&(lr->sumYY), &(pc->y), &(pc->y), &(pc->nb));

    // a1 = nb * sumXY - sumX * sumY
    a1 = pc->nb * lr->sumXY - lr->sumX * lr->sumY;
    // b1 = sumY * sumXX - sumX * sumXY
    b1 = lr->sumY * lr->sumXX - lr->sumX * lr->sumXY;
    // divider = nb * sumXX - (sumX)²
    divider = pc->nb * lr->sumXX - lr->sumX * lr->sumX;
    
    //can't divide by 0
    if( divider != 0){
        //add to a, a1 / divider
        lr->ideal.tabCoeff[0] = a1/divider;
        //add to b, b1 / divider
        lr->ideal.tabCoeff[1] = b1/divider;
    }
}

void newLinearRegression(LinearRegression *lr, PointsCloud *pc)
{
    float a = 0; //yi -ŷi
    float b = 0; //yi - ÿ
    double average;
    int i;
    
    computeQuickAverage(&average, pc->y, pc->nb);

    computeIdealPolynome(lr, pc);

    //compute yi -ŷi
    for (i = 0; i < pc->nb; (i)++)
    {
        a += (pc->y[i] - (lr->ideal.tabCoeff[0] * pc->x[i] + lr->ideal.tabCoeff[1])) *
              (pc->y[i] - (lr->ideal.tabCoeff[0] * pc->x[i] + lr->ideal.tabCoeff[1])); 
    }

    //compute yi - ÿ
    for (i = 0; i < pc->nb; (i)++)
    {
        b += (pc->y[i] - average) * (pc->y[i] - average); 
    }

    //can't divide by 0
    if (b != 0)
    {
        if (lr->ideal.tabCoeff[0] != 0 && lr->ideal.tabCoeff[1] != 0)
            lr->r = 1 - a/b;
        else
            lr->r = 0;
    }
}

void clearLinearRegression(LinearRegression *lr)
{
    clearPolynome(&(lr->ideal));
    lr->r = 0;
}


