#include <stdio.h>
#include <stdlib.h>
#include "../../../include/LIST/structure.h"
#include "../../../include/ML/tools/average.h"
#include <math.h>

void newAverage(Average *a)
{
    a->standardError = 0;
    a->averageValue = 0;
    a->numberOfData = 0;
    a->arrayOfData = NULL;
}

void addDataToAverage(Average *a, float newData)
{
    #ifdef VERBOSE
        printf("[LOG] adding %f \n", newData);
    #endif
    if (a->numberOfData == 0)
    {
        a->numberOfData = 1;
        a->arrayOfData = malloc(sizeof *a->arrayOfData);
        if(a->arrayOfData != NULL) {
            a->arrayOfData[0] = newData;
            #ifdef VERBOSE
                printf("[LOG] value added \n");
            #endif
        }
        //printf("data %f added at %d \n", a->arrayOfData[0], 0);
    }
    else if (a->numberOfData > 0)
    {
        (a->numberOfData)++;
        a->arrayOfData = realloc(a->arrayOfData, a->numberOfData * sizeof *a->arrayOfData);
        if(a->arrayOfData != NULL)
            a->arrayOfData[a->numberOfData - 1] = newData;
        
        //printf("data %f added at %d \n", a->arrayOfData[a->numberOfData - 1], a->numberOfData - 1);
    }

    if ((a->arrayOfData) == NULL)
    {
        printf("Error of reallocation !\n");
        return;
    }
    
}

void computeAverage(Average *a)
{

    float sum = 0;
    if (a->numberOfData >= 2)
    {

        for (int i = 0; i < (a->numberOfData); i++)
        {
            sum = sum + a->arrayOfData[i];
        }
    }
    //printf("%lf , %d \n",sum, a->numberOfData);
    a->averageValue = (sum / a->numberOfData);
}

void computeStandardErrorOfAverage(Average *a)
{
    float variance = 0.0;
    if (a->numberOfData >= 2)
    {
        if (a->averageValue != 0)
        {
            for (int i = 0; i < a->numberOfData; i++)
            {
                variance += ((a->arrayOfData[i]) - (a->averageValue)) * ((a->arrayOfData[i]) - (a->averageValue));
            }
            variance = variance/(a->numberOfData);
            a->standardError = sqrt(variance);
        }
    }
}

void clearAllDataOfAverage(Average *a)
{
    if (a != NULL) {
        a->averageValue = 0.0;
        a->standardError = 0.0;
        a->numberOfData = 0;
        if (a->arrayOfData != NULL) {
            free(a->arrayOfData);
            a->arrayOfData = NULL;
        }
    }
}

void saveAverageToTextFile(Average *a, char *filename)
{
    FILE *f;
    f = fopen("log.txt", "w");
    if (f != NULL)
    {
        fprintf(f, "{value:%f,error:%f,nbData:%d,{", a->averageValue, a->standardError, a->numberOfData);
        for (int i = 0; i < a->numberOfData; i++)
        {
            fprintf(f, "%f,",a->arrayOfData[i]);
        }
        fprintf(f, "}}\n");
        fclose(f);
    }
}

void readAverageFromTextFile(Average *a, char *filename)
{
    float tmp;
    int nbDataTmp;
    FILE *f;
    f = fopen("log.txt", "r");
    if (f != NULL)
    {
        fscanf(f, "{value:%f,error:%f,nbData:%d,{", &(a->averageValue), &(a->standardError), &(nbDataTmp));
        for (int i = 0; i < nbDataTmp; i++)
        {
            fscanf(f, "%f,",&tmp);
            //printf("%f \n",tmp);
            addDataToAverage(a, tmp);
        }
        fclose(f);
    }
}

void printAverage(Average *a)
{
    if (a != NULL) {
        printf("\t\t[AVERAGE] value -> %f, error -> %f, nb_data -> %d \n", a->averageValue, a->standardError, a->numberOfData);          
        if (a->numberOfData != 0) {
            for (int i = 0; i < a->numberOfData; i++) {
                printf("\t\t\t[DATA] value -> %f \n", a->arrayOfData[i]);
            }
        }
    }
}