#include <stdio.h>
#include <stdlib.h>

#include <string.h>
#include <ctype.h>

char* strupr(char *src)
{
    char *s = malloc(sizeof(src));
    strcpy(s, src);
    int i = 0;
    while( s[i] != '\0') {
        s[i] = toupper(s[i]);
        i++;
    }
    return s;
}