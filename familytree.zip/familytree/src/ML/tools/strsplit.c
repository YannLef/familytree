#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../../include/ML/tools/strsplit.h"

/**
 * @brief split a string into substrings stored in a tokenner 
 * (table of string) separated by a character sep
 * 
 * thanks to the string.h library we can easily separate a string into substrings
 * and stored each of them into a table
 * 
 * @param {token} main string
 * @param {character} separator
 * @param {tokenner} table of string
 * 
 * @return {unsigned integer} number of token
 * */
unsigned int split(token mainStr,char* sep,tokenner *tkn){
	//temporary token
	token found; 
	//memory allocation of the table of string (we use a local table firstly)
	//start from 1 cell
	tokenner t = malloc(sizeof(*t)); 
	//allocation error management
	if(t == NULL){
		printf("[error] malloc str split \n");
		return 0;
	}
	//counter for the number of token and to reallocate the table
	unsigned int k=0;
	//while the main string can be separated by sep , we add the new substring into
	//the table of string which is reallocated each time a new string is added
	while( (found = strsep(&mainStr,sep)) != NULL){
		//add the string
		t[k] = found;
		//update the counter
		k++;
		//reallocate (more than 1 cell)
		if( k>0){
			//k start from 0 and we have already 1 cell
			//so add 1 to k for the size to start after
			t = realloc(t,sizeof(*t)*(k+1));
		} 
	}
	//the table of string is return by adress
	*tkn = t;
	return k;
}