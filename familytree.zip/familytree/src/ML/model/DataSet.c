#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../../include/LIST/structure.h"
#include "../../../include/ML/list/event/Event.h"
#include "../../../include/ML/tools/average.h"
#include "../../../include/ML/model/Score.h"
#include "../../../include/ML/model/Coordinate.h"
#include "../../../include/ML/list/place/Place.h"
#include "../../../include/ML/model/Population.h"
#include "../../../include/ML/list/population/PopulationList.h"
#include "../../../include/ML/model/DataSet.h"

void initDataSet(DataSet **d, population_type type)
{
    DataSet *set = NULL;
    set = malloc(sizeof *d);
    if (set == NULL) {
        printf("[ERROR] malloc dataset \n");
        (*d) = NULL;
        return;
    }
    set->listOfPopulation = NULL;
    set->nbPopulation = 0;
    set->type = type;

    (*d) = set;
}

void newDataSetFromDataList(DataSet **d, LIST *data, population_type type)
{
    DataSet *set = NULL;
    initDataSet(&set, type);
    #ifdef VERBOSE
        printf("[LOG] dataset initialised \n");
    #endif
    if ( set != NULL) {
        if (set->listOfPopulation == NULL) {
            set->nbPopulation = newPopulationListFromDataList(&(set->listOfPopulation), type, data);
            #ifdef VERBOSE
                printf("[LOG] population in dataset -> %d \n", set->nbPopulation);
            #endif
        }
        (*d) = set;
    } else {
        (*d) = NULL;
    }
}

void displayDataSet(DataSet *d)
{
    displayListOfPopulationList(d->listOfPopulation);
}

void freeDataSet(DataSet **d)
{
    if (d != NULL) {
        if ((*d)->listOfPopulation != NULL) {
            #ifdef VERBOSE
                printf("[LOG] deleting list of population \n");
            #endif
            deleteListOfPopulationList(&((*d)->listOfPopulation));
        }        
        #ifdef VERBOSE
            printf("[LOG] free OK for list of population in dataset : nb -> %d \n", (*d)->nbPopulation);
        #endif
    }
    free(*d);
    *d = NULL;
}

