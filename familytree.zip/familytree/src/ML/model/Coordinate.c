#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../../include/ML/model/Coordinate.h"
void initCoordinate(Coordinate **c)
{
    *c = malloc(sizeof **c);
    if (*c == NULL) {
        printf("[ERROR] error malloc new coordinate 1 \n");
        return;
    }
}

void newCoordinate(Coordinate **c, float latitude, float longitude)
{
    initCoordinate(c);
    (*c)->latitude = latitude;
    (*c)->longitude = longitude;
}

int getCityNameFromCoordinate(Coordinate *c, char **cityNameFound, char *pathToDb)
{
    char* latitude = malloc(7 * sizeof *latitude);
    char* longitude = malloc(7 * sizeof *longitude);
    sprintf(latitude, "%f", c->latitude);
    sprintf(longitude, "%f", c->longitude);

    char *command = malloc(200 * sizeof *command);
    if (command == NULL) {
        printf("[ERROR] command malloc \n");
        return 0;
    }
    strcpy(command, "sqlite3 ");
    strcat(command, pathToDb);
    strcat(command, " \"SELECT nom FROM villes WHERE latitude='");
    strcat(command, latitude);
    strcat(command, "' AND longitude='");
    strcat(command, longitude);
    strcat(command, " COLLATE NOCASE\" > cityname.txt");
    
    free(latitude);
    latitude = NULL;
    free(longitude);
    longitude = NULL;

    #ifdef VERBOSE
        printf("[LOG] command -> %s , length -> %ld \n", command, strlen(command));
    #endif
    int error = system(command);
    free(command);
    command = NULL;
    if (error != -1) {
        FILE *f = fopen("cityname", "rt");
        if (f == NULL) {
            printf("[ERROR] no city for coordinates given \n");
            error = -1;
        }
        fscanf(f, "%s", *cityNameFound);
        fclose(f);
        system("rm -f cityname.txt");
    }
    return error;
}

int newCoordinateFromCityName(Coordinate **c, char *cityName, char *pathToDb)
{
    char *command = malloc(200 * sizeof *command);
    if (command == NULL) {
        printf("[ERROR] command malloc \n");
        return 0;
    }
    strcpy(command, "sqlite3 ");
    strcat(command, pathToDb);
    strcat(command, " \"SELECT latitude,longitude FROM villes WHERE nom='");
    strcat(command, cityName);
    strcat(command, "' COLLATE NOCASE\" > coord.txt");
    #ifdef VERBOSE
        printf("[LOG] command -> %s , length -> %ld \n", command, strlen(command));
    #endif
    int error = system(command);
    free(command);
    command = NULL;
    if (error != -1) {
        readCoordinateFromTextFile(c, "coord.txt");
        system("rm -f coord.txt");
    }
    return error;
}

void printCoordinate(Coordinate *c)
{
    printf("\t[COORDINATE] latitude : %f | longitude : %f \n", c->latitude, c->longitude);
}

void freeCoordinate(Coordinate **c)
{
    free(*c);
    *c = NULL;
}

void saveCoordinateToTextFile(Coordinate *c, char *filename)
{
    FILE *f = fopen(filename, "wt");
    fprintf(f, "%f|%f", c->latitude, c->longitude);
    fclose(f);
}

void readCoordinateFromTextFile(Coordinate **c, char *filename) {
    initCoordinate(c);
    FILE *f = fopen(filename, "rt");
    if (f == NULL) {
        printf("[ERROR] coordinate file does not exist \n");
    }
    int error = fscanf(f, "%f|%f", &((*c)->latitude), &((*c)->longitude));
    fclose(f);
    //printf("%f, %f \n", (*c)->latitude, (*c)->longitude);
}
