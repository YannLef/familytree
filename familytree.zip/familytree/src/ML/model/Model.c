#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../../include/LIST/structure.h"
#include "../../../include/IHM/structures.h"
#include "../../../include/ML/ML.h"

void initModel(Model **m, int nbSets)
{
    Model *mod = NULL;
    mod = malloc(sizeof *mod);
    if (mod == NULL) {
        printf("[ERROR] allocation model \n");
        return;
    }
    mod->nbSets = nbSets;
    mod->sets = NULL;
    mod->sets = malloc(nbSets * sizeof *(mod->sets));
    for (int i = 0; i < mod->nbSets; i++) {
        mod->sets[i] = NULL;
    }
    if (mod->sets == NULL) {
        printf("[ERROR] allocation set in model \n");
        return;
    }
    (*m) = mod;
}

void createModel(Model *m, LIST *data)
{
    if (data != NULL) {
        m->data = data;
        #ifdef VERBOSE
            printf("[LOG] data -> %p \n", data);
        #endif
      
        for (int i = 0; i < m->nbSets; i++) {
            newDataSetFromDataList(&(m->sets[i]), data, i);
            #ifdef VERBOSE
                printf("[LOG] dataset sucessfully settled at %d \n\n\n", i);
            #endif
        }
    }
    computeModelError(m);
}

void displayModel(Model *m)
{
    if (m != NULL) {
        printf("[MODEL] nbDataSet -> %d, error -> %f \n", m->nbSets, m->error);
        if (m->sets != NULL) {
            for (int i = 0; i < m->nbSets; i++) {
                if (m->sets[i] != NULL) {
                    printf("[DATASET] nb -> %d, type -> %d \n", m->sets[i]->nbPopulation, m->sets[i]->type);
                    displayDataSet(m->sets[i]);
                }
            }
        }
    }
}

void freeDataSetsInModel(Model *m)
{
    if (m->sets != NULL) {
        for (int i = 0; i < m->nbSets; i++) {
            if (m->sets[i] != NULL) {
                #ifdef VERBOSE
                    printf("[LOG] free dataset %d \n", i);
                #endif
                freeDataSet(&(m->sets[i]));
                #ifdef VERBOSE
                    printf("[LOG] free dataset %d OK \n", i);
                #endif
            }
        }
    }
}

void freeModel(Model **m)
{
    if (*m != NULL) {
        freeDataSetsInModel(*m);
        
        (*m)->data = NULL;

        free((*m)->sets);
        (*m)->sets = NULL;

        free(*m);
        *m = NULL;
    }
}

void getPopulationFromModel(Population **searched, Model *m, char** formData, population_type type, int nbData)
{
    (*searched) = NULL;
    if (formData != NULL) {
        switch(type) {
            case GENERATION:
                if (nbData == 1) {
                    getGenerationPopulationFromModel(searched, m, atoi(formData[0]));
                }
                break;
            case FAMILY:
                if (nbData == 1) {
                    getFamilyPopulationFromModel(searched, m, formData[0]);
                }
                break;
            case I_ASC:
                if (nbData == 3) {
                    getIndividuPopulationFromModel(searched, m, type, formData[0], formData[1], atoi(formData[2]));
                }
                break;
            case I_DESC:
                if (nbData == 3) {
                    getIndividuPopulationFromModel(searched, m, type, formData[0], formData[1], atoi(formData[2]));
                }
                break;
        }
    }
}

void getFamilyPopulationFromModel(Population **searched, Model *m, char *familyName)
{
    #ifdef VERBOSE
        printf("[SEARCHING POPULATION] type -> FAMILY, name -> %s \n", familyName);
    #endif
    (*searched) = NULL;
    if (m != NULL && m->sets[FAMILY] != NULL) {
        PopulationList* tmpPopList = m->sets[FAMILY]->listOfPopulation;
        if (tmpPopList != NULL) {
            while( tmpPopList != NULL) {
                if (tmpPopList->data != NULL) {
                    if (tmpPopList->data->historyOfPlaceFrequented != NULL) {
                        if (tmpPopList->data->historyOfPlaceFrequented->data != NULL) {
                            Event *tmpEvent = tmpPopList->data->historyOfPlaceFrequented->data->listOfEvent;                        
                            if ( tmpEvent != NULL) {
                                    //individu to search data
                                    #ifdef VERBOSE
                                        printf("[LOG] in first event : \n");
                                    #endif
                                    list_individu *tmpIndividu = NULL;
                                    if (tmpEvent->data->typeOfEvent == BIRTH || tmpEvent->data->typeOfEvent == DESCES) {
                                        //not a mariage => get the individu information
                                        #ifdef VERBOSE
                                            printf("[LOG] first event type -> %d \n", tmpEvent->data->typeOfEvent);
                                        #endif
                                        tmpIndividu = tmpEvent->data->desc.i;
                                    } else if (tmpEvent->data->typeOfEvent == MARIAGE) {
                                        #ifdef VERBOSE
                                            printf("[LOG] first event type -> mariage \n");
                                        #endif
                                        //the event is mariage => get the first individu
                                        tmpIndividu = tmpEvent->data->desc.m->c1->u.list_individu;
                                        //check if c1 is potential
                                        if (tmpIndividu != NULL) {
                                            #ifdef VERBOSE
                                                printf("[LOG] check c1 at %p \n", tmpIndividu);
                                            #endif
                                            //check the name
                                            if( strcmp(tmpIndividu->data->nom, familyName) != 0) {
                                                //wrong name => try the fiancé after
                                                #ifdef VERBOSE
                                                    printf("[LOG] wrong name -> test c2 \n");
                                                #endif
                                                tmpIndividu = tmpEvent->data->desc.m->c2->u.list_individu;
                                            } 
                                        }
                                    }
                                    // check individu potential
                                    if (tmpIndividu != NULL) {
                                        #ifdef VERBOSE
                                            printf("[LOG] check individu at %p \n", tmpIndividu);
                                        #endif
                                        //check name
                                        if( strcmp(tmpIndividu->data->nom, familyName) == 0) {
                                            #ifdef VERBOSE
                                                printf("[LOG] wrong name -> not found \n");
                                            #endif
                                            (*searched) = tmpPopList->data;
                                        }
                                    }
                            }
                        }
                    }
                }
                tmpPopList = tmpPopList->next;
            }
        }
    }
}

void getIndividuPopulationFromModel(Population **searched, Model *m, population_type type, char *name, char *lastname, int generation)
{
    //#ifdef VERBOSE
        printf("[SEARCHING POPULATION] type -> %d, name -> %s, lastname -> %s, generation -> %d \n", type, name, lastname, generation);
    //#endif
    (*searched) = NULL; //find nothing
    //the population is not a generation or a family
    if (m != NULL && m->sets[type] != NULL) {
        if (type == I_ASC || type == I_DESC) {
            //get the according dataset
            PopulationList* tmpPopList = m->sets[type]->listOfPopulation;
            //#ifdef VERBOSE
                printf("[LOG] found list of population \n");
            //#endif
            //found the dataset
            if (tmpPopList != NULL) {
                //browse list of population
                //#ifdef VERBOSE
                    printf("[LOG] browse population \n");
                //#endif
                while( tmpPopList != NULL) {
                    //if exist, get the first event
                    if (tmpPopList->data != NULL) {
                        if (tmpPopList->data->historyOfPlaceFrequented != NULL) {
                            if (tmpPopList->data->historyOfPlaceFrequented->data != NULL) {
                                //#ifdef VERBOSE
                                    printf("[LOG] get first event : %p \n", tmpPopList->data->historyOfPlaceFrequented);
                                //#endif

                                Event *tmpEvent = tmpPopList->data->historyOfPlaceFrequented->data->listOfEvent;
                                if ( tmpEvent != NULL) {
                                    //individu to search data
                                    //#ifdef VERBOSE
                                        printf("[LOG] in first event : \n");
                                    //#endif
                                    list_individu *tmpIndividu = NULL;
                                    if (tmpEvent->data->typeOfEvent == BIRTH || tmpEvent->data->typeOfEvent == DESCES) {
                                        //not a mariage => get the individu information
                                        //#ifdef VERBOSE
                                            printf("[LOG] first event type -> %d \n", tmpEvent->data->typeOfEvent);
                                        //#endif
                                        tmpIndividu = tmpEvent->data->desc.i;
                                    } else if (tmpEvent->data->typeOfEvent == MARIAGE) {
                                        //#ifdef VERBOSE
                                            printf("[LOG] first event type -> mariage \n");
                                        //#endif
                                        //the event is mariage => get the first individu
                                        tmpIndividu = tmpEvent->data->desc.m->c1->u.list_individu;
                                        //check if c1 is potential
                                        if (tmpIndividu != NULL) {
                                            //#ifdef VERBOSE
                                                printf("[LOG] check c1 at %p \n", tmpIndividu);
                                            //#endif
                                            //check the name
                                            if (tmpIndividu->data != NULL) {
                                                if (tmpIndividu->data->nom != NULL) {
                                                    if( strcmp(tmpIndividu->data->nom, name) != 0) {
                                                        //wrong name => try the fiancé after
                                                        //#ifdef VERBOSE
                                                            printf("[LOG] wrong name -> test c2 \n");
                                                        //#endif
                                                        tmpIndividu = tmpEvent->data->desc.m->c2->u.list_individu;
                                                    } else {
                                                        //check the last name
                                                        if (tmpIndividu->data->prenom != NULL) {
                                                            if ( strcmp(tmpIndividu->data->prenom, lastname) != 0) {
                                                                //#ifdef VERBOSE
                                                                    printf("[LOG] wrong lastname -> test c2 \n");
                                                                //#endif
                                                                tmpIndividu = tmpEvent->data->desc.m->c2->u.list_individu;
                                                            } else {
                                                                //check generation
                                                                if ( tmpIndividu->data->generation == generation) {
                                                                    //#ifdef VERBOSE
                                                                        printf("[LOG] wrong generation -> test c2 \n");
                                                                    //#endif
                                                                    tmpIndividu = tmpEvent->data->desc.m->c2->u.list_individu;
                                                                } else {
                                                                    //#ifdef VERBOSE
                                                                        printf("[LOG] individu found -> return his/her population \n");
                                                                    //#endif
                                                                    (*searched) = tmpPopList->data;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    // check individu potential
                                    if (tmpIndividu != NULL) {
                                        //#ifdef VERBOSE
                                            printf("[LOG] check individu at %p \n", tmpIndividu);
                                        //#endif
                                        //check name
                                        if( strcmp(tmpIndividu->data->nom, name) == 0) {
                                            //#ifdef VERBOSE
                                                printf("[LOG] wrong name -> not found \n");
                                            //#endif
                                            //check lastname
                                            if ( strcmp(tmpIndividu->data->prenom, lastname) == 0) {
                                                //#ifdef VERBOSE
                                                    printf("[LOG] wrong lastname -> not found \n");
                                                //#endif
                                                //check generation
                                                if ( tmpIndividu->data->generation == generation) {
                                                    //#ifdef VERBOSE
                                                        printf("[LOG] individu found \n");
                                                    //#endif
                                                    (*searched) = tmpPopList->data;
                                                }
                                            }
                                        }
                                    }
                                }
                                //try next population
                            }
                        }
                    }
                    tmpPopList = tmpPopList->next;
                }
            }
        }
    }
    //#ifdef VERBOSE
        printf("[LOG] searching population from individu finish \n");
    //#endif
} 
void getGenerationPopulationFromModel(Population **searched, Model *m, int generation)
{
    #ifdef VERBOSE
        printf("[SEARCHING POPULATION] type -> GENERATION, number -> %d \n", generation);
    #endif
    (*searched) = NULL;
    if (m != NULL && m->sets[GENERATION] != NULL) { 
        PopulationList* tmpPopList = m->sets[GENERATION]->listOfPopulation;
        //displayDataSet(m->sets[GENERATION]);
        if (tmpPopList != NULL) {
            while( tmpPopList != NULL) {
                if (tmpPopList->data != NULL) {
                    if (tmpPopList->data->historyOfPlaceFrequented != NULL) {
                        if (tmpPopList->data->historyOfPlaceFrequented->data != NULL) {
                            Event *tmpEvent = tmpPopList->data->historyOfPlaceFrequented->data->listOfEvent;                        
                            if ( tmpEvent != NULL) {
                                    //individu to search data
                                    #ifdef VERBOSE
                                        printf("[LOG] in first event : \n");
                                    #endif
                                    list_individu *tmpIndividu = NULL;
                                    if (tmpEvent->data->typeOfEvent == BIRTH || tmpEvent->data->typeOfEvent == DESCES) {
                                        //not a mariage => get the individu information
                                        #ifdef VERBOSE
                                            printf("[LOG] first event type -> %d \n", tmpEvent->data->typeOfEvent);
                                        #endif
                                        tmpIndividu = tmpEvent->data->desc.i;
                                    } else if (tmpEvent->data->typeOfEvent == MARIAGE) {
                                        #ifdef VERBOSE
                                            printf("[LOG] first event type -> mariage \n");
                                        #endif
                                        //the event is mariage => get the first individu
                                        tmpIndividu = tmpEvent->data->desc.m->c1->u.list_individu;
                                        //check if c1 is potential
                                        if (tmpIndividu != NULL) {
                                            #ifdef VERBOSE
                                                printf("[LOG] check c1 at %p \n", tmpIndividu);
                                            #endif
                                            //check the name
                                            if( generation == tmpIndividu->data->generation) {
                                                //wrong name => try the fiancé after
                                                #ifdef VERBOSE
                                                    printf("[LOG] wrong name -> test c2 \n");
                                                #endif
                                                tmpIndividu = tmpEvent->data->desc.m->c2->u.list_individu;
                                            } 
                                        }
                                    }
                                    // check individu potential
                                    if (tmpIndividu != NULL) {
                                        #ifdef VERBOSE
                                            printf("[LOG] check individu at %p \n", tmpIndividu);
                                        #endif
                                        //check name
                                        if( generation == tmpIndividu->data->generation) {
                                            #ifdef VERBOSE
                                                printf("[LOG] wrong name -> not found \n");
                                            #endif
                                            (*searched) = tmpPopList->data;
                                        }
                                    }
                            }
                        }
                    }
                }
                tmpPopList = tmpPopList->next;
            }
        }
    }
}

void computeModelError(Model *m)
{
    for(int i = 0; i < m->nbSets; i++) {
        float errorDataSet = 0.0f;
        if (m->sets[i] != NULL) {
            PopulationList *tmpPop = m->sets[i]->listOfPopulation;
            if (tmpPop != NULL) {
                while( tmpPop != NULL) {
                    if (tmpPop->data != NULL) {
                        errorDataSet += tmpPop->data->globalPopulationScore;
                    }
                    tmpPop = tmpPop->next;
                }
            }
        }
        errorDataSet = errorDataSet + m->sets[i]->nbPopulation;
        m->error += errorDataSet;
    }
    m->error /= m->nbSets;
}

void findPlaceMaxWeight(Place **searched, Model *m, population_type type)
{
    
}