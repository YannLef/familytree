#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "../../../include/LIST/structure.h" 
#include "../../../include/IHM/structures.h"
#include "../../../GFX/GfxLib.h"
#include "../../../include/ML/ML.h"  

#define PI 3.14159265358979323846
#define EPSILON 15
#define CIRCLE_SIZE_COEFFICIENT 10

void cercle2(float centreX, float centreY, float rayon)
{
	const int Pas = 20; // Nombre de secteurs pour tracer le cercle
	const double PasAngulaire = 2.*PI/Pas;
	int index;
	
	for (index = 0; index < Pas; ++index) // Pour chaque secteur
	{
		const double angle = 2.*PI*index/Pas; // on calcule l'angle de depart du secteur
		triangle(centreX, centreY,
				 centreX+rayon*cos(angle), centreY+rayon*sin(angle),
				 centreX+rayon*cos(angle+PasAngulaire), centreY+rayon*sin(angle+PasAngulaire));
			// On trace le secteur a l'aide d'un triangle => approximation d'un cercle
	}
	
}

float latitudeToPixel(float latitude)
{
    return 81.93*latitude-3390 - EPSILON;
}

float longitudeToPixel(float longitude)
{
    return 58.63*longitude+1005;
}

void displayPopulationOnMap(Population *p, type_event e, int minYear, int maxYear)
{
    Place *tmp = p->historyOfPlaceFrequented;
    while (tmp != NULL)
    {
        int y = (int) floor(latitudeToPixel(tmp->data->geographicalPosition->latitude));
        int x = (int) floor(longitudeToPixel(tmp->data->geographicalPosition->longitude));

        Event *tmpEvent = tmp->data->listOfEvent;
        while (tmpEvent != NULL) {
            if (minYear < maxYear) {
                switch(e) {
                    case MARIAGE:
                        if (tmpEvent->data->desc.m->data->date != NULL) {
                            if (minYear <= tmpEvent->data->desc.m->data->date->annee 
                                && tmpEvent->data->desc.m->data->date->annee <= maxYear
                            ) {
                                couleurCourante(255, 0, 0);
                                epaisseurDeTrait(10);
                                cercle2(x, y, tmp->data->scoreOfPlace->mariages_counter + CIRCLE_SIZE_COEFFICIENT);
                            }
                        }
                        break;
                    case DESCES:
                        if (tmpEvent->data->desc.i->data->deces != NULL) {
                            if (minYear <= tmpEvent->data->desc.i->data->deces->annee 
                                && tmpEvent->data->desc.m->data->date->annee <= maxYear
                            ) {
                                couleurCourante(0, 0, 255);
                                cercle2(x, y, tmp->data->scoreOfPlace->desces_counter + CIRCLE_SIZE_COEFFICIENT);
                            }
                        }
                        break;
                    case BIRTH:
                        if (tmpEvent->data->desc.i->data->naissance != NULL) {
                            if (minYear <= tmpEvent->data->desc.i->data->naissance->annee 
                                && tmpEvent->data->desc.m->data->date->annee <= maxYear
                            ) {
                                couleurCourante(0, 255, 0);
                                cercle2(x, y, tmp->data->scoreOfPlace->births_counter + CIRCLE_SIZE_COEFFICIENT);
                            }
                        }
                        break;
                }
            }

            tmpEvent = tmpEvent->next;
        }

        tmp = tmp->next;
    }
}