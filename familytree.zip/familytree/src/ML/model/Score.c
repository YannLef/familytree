#include <stdio.h>
#include <stdlib.h>

#include "../../../include/ML/tools/average.h"
#include "../../../include/ML/model/Score.h"

void newScore(Score **s)
{
    Score *sc = malloc(sizeof *sc);
    sc->desces_counter = sc->mariages_counter = sc->births_counter = 0;
    sc->numberOfAverage = 0;
    sc->arrayOfAverages = NULL;
    sc->globalStandardError = 0.0f;
    (*s) = sc;
}

void clearScore(Score **s)
{
    if ( (*s)->arrayOfAverages != NULL) {
        for(int i = 0; i < (*s)->numberOfAverage; i++) {
            clearAllDataOfAverage(&((*s)->arrayOfAverages[i]));
        }
        free((*s)->arrayOfAverages);
        (*s)->arrayOfAverages = NULL;
    }
    free(*s);
    *s = NULL;
}

void printScore(Score *s)
{
    printf("\t[SCORE] error -> %f, nb_desces -> %d, nb_birth -> %d, nb_death -> %d, nb_average -> %d \n",
        s->globalStandardError,
        s->desces_counter,
        s->births_counter,
        s->mariages_counter,
        s->numberOfAverage
    );
    if ( s->arrayOfAverages !=  NULL) {
        for(int i = 0; i < MIN_AVERAGE_IN_SCORE; i++) {
            printAverage(&(s->arrayOfAverages[i]));
        }
    }
}

void computeScoreGlobalStandardError(Score *s)
{
    s->globalStandardError = 0.0f;
    if ( s->arrayOfAverages != NULL && s->numberOfAverage != 0) {
        for(int i = 0; i < s->numberOfAverage; i++) {
            s->globalStandardError = s->globalStandardError + s->arrayOfAverages[i].standardError;            
        }
        s->globalStandardError = s->globalStandardError / s->numberOfAverage;
    }
}

void addAverageToScore(Score *s, Average *a)
{
    s->numberOfAverage++;
    if (s->numberOfAverage == 0) {
        s->arrayOfAverages = malloc(sizeof *(s->arrayOfAverages));
        if (s->arrayOfAverages == NULL) {
            printf("[ERROR] error allocation array of average of score \n");
            return;
        } 
        s->arrayOfAverages[s->numberOfAverage - 1] = *a;
    } else {
        s->arrayOfAverages = realloc(s->arrayOfAverages, (s->numberOfAverage + 1) * sizeof *(s->arrayOfAverages));
        s->arrayOfAverages[s->numberOfAverage - 1] = *a;
    }
}

void newAverageInScore(Score *s)
{
    if (s->numberOfAverage == 0) {
        s->arrayOfAverages = malloc(sizeof *(s->arrayOfAverages));
        if (s->arrayOfAverages == NULL) {
            printf("[ERROR] error allocation array of average of score \n");
            return;
        } 
    } else {
        s->arrayOfAverages = realloc(s->arrayOfAverages, (s->numberOfAverage + 1) * sizeof *(s->arrayOfAverages));
    }
    s->numberOfAverage++;
    newAverage(&(s->arrayOfAverages[s->numberOfAverage - 1]));
}
