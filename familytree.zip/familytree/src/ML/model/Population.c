#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../../include/LIST/structure.h"
#include "../../../include/ML/list/event/Event.h"
#include "../../../include/ML/tools/average.h"
#include "../../../include/ML/model/Score.h"
#include "../../../include/ML/model/Coordinate.h"
#include "../../../include/ML/list/place/Place.h"
#include "../../../include/ML/model/Population.h"

ptrFuncPopulation* initPtrFuncPopulation(void)
{
    ptrFuncPopulation *f = malloc(sizeof *f);
    if (f == NULL) {
        printf("[ERROR] malloc ptr function \n");
        return NULL;
    }
    f->tab[GENERATION] = newPopulationFromGeneration;
    f->tab[FAMILY] = newPopulationFromFamily;
    f->tab[I_ASC] = newPopulationFromIasc;
    f->tab[I_DESC] = newPopulationFromIdesc;
    
    return f;
}

void freePtrFuncPopulation(ptrFuncPopulation** f)
{
    free(*f);
    *f = NULL;
}

void callbackAddMariageToPopulation(Population **p, SUBLIST* tmpMariage)
{
    if (tmpMariage != NULL) {
        while (tmpMariage != NULL) {
            insertMariageInPopulation(*p, tmpMariage->u.sublist_M->mariage->u.list_mariage);
            tmpMariage = tmpMariage->u.sublist_M->suivant;
        }
    }
}

void newPopulationFromGeneration(Population **p, LIST *start)
{
    #ifdef VERBOSE
        printf("[LOG] Population for generation %d \n", start->u.list_individu->data->generation);
    #endif
    LIST* tmp = start;
    Population *pop = NULL;
    newPopulation(&pop, GENERATION);
    while (tmp != NULL) {
        if (tmp->u.list_individu->data->generation == start->u.list_individu->data->generation) {
            #ifdef VERBOSE
                printf("[INDIVIDU] %s %s \n", tmp->u.list_individu->data->nom, tmp->u.list_individu->data->prenom);
            #endif
            insertIndividuInPopulation(pop, tmp->u.list_individu);
            SUBLIST* tmpMariage = tmp->u.list_individu->sublistMariage;
            callbackAddMariageToPopulation(&pop, tmpMariage);
        }
        tmp = tmp->u.list_individu->suivant;
    }
    computeGlobalPopulationScore(pop);
    (*p) = pop;
}

void newPopulationFromIasc(Population **p, LIST *start)
{
    if (start->u.list_individu->c1 != NULL) {
        #ifdef VERBOSE
            printf("[LOG] Population for I_ASC %s %s \n", start->u.list_individu->data->nom, start->u.list_individu->data->prenom);
        #endif
        Population *pop = NULL;
        newPopulation(&pop, I_ASC);
        #ifdef VERBOSE
            printf("[INDIVIDU] %s %s \n", start->u.list_individu->data->nom, start->u.list_individu->data->prenom);
        #endif 
        if (pop != NULL) {
            insertIndividuInPopulation(pop, start->u.list_individu);
            callbackAddMariageToPopulation(&pop, start->u.list_individu->sublistMariage);
            LIST* tmp = start->u.list_individu->c1;
            if (tmp != NULL) {        
                while (tmp != NULL) {
                    #ifdef VERBOSE
                        printf("\t[ASC] %s %s \n", tmp->u.list_individu->data->nom, tmp->u.list_individu->data->prenom);
                    #endif
                    insertIndividuInPopulation(pop, tmp->u.list_individu);
                    SUBLIST* tmpMariage = tmp->u.list_individu->sublistMariage;
                    callbackAddMariageToPopulation(&pop, tmpMariage);
                    tmp = tmp->u.list_individu->c1;
                }
            }
        }
        computeGlobalPopulationScore(pop);
        (*p) = pop;
    }
}

/**
 * pour les individu dans liste :
 *      ajoute les evenements de type mariage dans population relié à individu
 *      obtenir la liste des enfants de individu
 *      pour les individus dans cette liste :
 *          ajouter les evenement de 
 * 
 */
void newPopulationFromIdesc(Population **p, LIST *start)
{
    Population *pop = NULL;
    newPopulation(&pop, I_DESC); //TODO va falloir le deplacer ça
    SUBLIST* tmp = start->u.list_individu->sublistIndividu;
    insertIndividuInPopulation(pop, start->u.list_individu);
    callbackAddMariageToPopulation(&pop, start->u.list_individu->sublistMariage);
    //TODO a refactor pour augmenter la rapidite
    while (tmp != NULL) {
        //printf("\t[DESC] %s %s \n", tmp->u.sublist_I->individu->u.list_individu->data->nom, tmp->u.sublist_I->individu->u.list_individu->data->prenom);
        SUBLIST* tmpMariage = tmp->u.sublist_I->individu->u.list_individu->sublistMariage;
        callbackAddMariageToPopulation(&pop, tmpMariage);
        newPopulationFromIdesc(p, tmp->u.sublist_I->individu);

        tmp = tmp->u.sublist_I->suivant;
    }
    computeGlobalPopulationScore(pop);
    (*p) = pop;
}

void callbackPopulationIdescFamily(Population **p, LIST *start)
{
    Population *pop = NULL;
    newPopulation(&pop, FAMILY);
    SUBLIST* tmp = start->u.list_individu->sublistIndividu;
    insertIndividuInPopulation(pop, start->u.list_individu);
    //printf("%s %s \n", start->u.list_individu->data->nom, start->u.list_individu->data->prenom );
    callbackAddMariageToPopulation(&pop, start->u.list_individu->sublistMariage);
    while (tmp != NULL) {
        if (strcmp(start->u.list_individu->data->nom, tmp->u.sublist_I->individu->u.list_individu->data->nom) == 0) {
            insertIndividuInPopulation(pop, tmp->u.sublist_I->individu->u.list_individu);
            SUBLIST* tmpMariage = tmp->u.sublist_I->individu->u.list_individu->sublistMariage;
            callbackAddMariageToPopulation(&pop, tmpMariage);
            callbackPopulationIdescFamily(p, tmp->u.sublist_I->individu);
        }
        
        tmp = tmp->u.sublist_I->suivant;
    } 
    computeGlobalPopulationScore(pop);
    (*p) = pop;
}

void newPopulationFromFamily(Population **p, LIST *start)
{
    if (start->u.list_individu->c1 == NULL) {  
        LIST* tmp = start;
        #ifdef VERBOSE
            printf("[LOG] Population for Family %s \n", start->u.list_individu->data->nom);
            printf("\t[DESC] %s %s \n", start->u.list_individu->data->nom, start->u.list_individu->data->prenom);
        #endif
        callbackPopulationIdescFamily(p, start);
    }
    
    start = start->u.list_individu->suivant;
}

void newPopulation(Population **p, population_type type)
{
    Population *pop = malloc(sizeof *pop);
    if (pop == NULL) {
        printf("[ERROR] malloc population");
        return;
    }
    pop->globalPopulationScore = 0.0f;
    pop->typeOfPopulation = type;
    pop->nbPlace = 0;
    pop->historyOfPlaceFrequented = NULL;
    (*p) = pop;
}

void freePopulation(Population **p)
{
    if ((*p) != NULL) {
        if ((*p)->historyOfPlaceFrequented != NULL)
            deleteListOfPlace(&((*p)->historyOfPlaceFrequented));
        #ifdef VERBOSE
            printf("[LOG] list of place free in population \n");
        #endif
        //free((*p));
        (*p) = NULL;
    }
}

void insertIndividuInPopulation(Population *p, list_individu *i)
{
    if (i != NULL) {
        if (i->data->lieuNaissance != NULL) {
            p->nbPlace += insertPlace(&(p->historyOfPlaceFrequented), i->data->lieuNaissance);
            insertBirthInPlace(p->historyOfPlaceFrequented, i);
        }
        if (i->data->lieuDeces != NULL) {
            p->nbPlace += insertPlace(&(p->historyOfPlaceFrequented), i->data->lieuDeces);
            insertDeathInPlace(p->historyOfPlaceFrequented, i);
        }
    }
}

void insertMariageInPopulation(Population *p, list_mariage *m)
{
    if (m != NULL) {
        if (m->data->lieu != NULL) {
            p->nbPlace += insertPlace(&(p->historyOfPlaceFrequented), m->data->lieu);
            insertMariageInPlace(p->historyOfPlaceFrequented, m);
        }
    }
}

void displayPopulation(Population *p)
{
    if (p != NULL) {
        printf("[POPULATION] type -> %d, nb_place -> %d, score-> %f \n", p->typeOfPopulation, p->nbPlace, p->globalPopulationScore);
        displayListOfPlace(p->historyOfPlaceFrequented);
    }
}

void computeGlobalPopulationScore(Population *p)
{
    if (p != NULL) {
        float averageError = 0.0f;
        if (p->nbPlace != 0) {
            if (p->historyOfPlaceFrequented != NULL) {
                Place *tmp = p->historyOfPlaceFrequented;
                while(tmp != NULL) {
                    averageError += tmp->data->scoreOfPlace->globalStandardError;
                    tmp = tmp->next;
                }
                
                averageError = averageError / p->nbPlace;
            }
        }
        p->globalPopulationScore = averageError;
    }
}

float findAverageValueWithMinSatandardErrorInPlaceHistoric(Population *p, average_name aname)
{
    Place *tmp = p->historyOfPlaceFrequented;
    float value = 0.0f;
    float stderror = 1000.0f;
    if (tmp != NULL) {
        while (tmp != NULL) {
            if (tmp->data != NULL) {
                if (tmp->data->scoreOfPlace != NULL) {
                    if (tmp->data->scoreOfPlace->arrayOfAverages != NULL) {
                        if (tmp->data->scoreOfPlace->arrayOfAverages[aname].standardError < stderror) {
                            value = tmp->data->scoreOfPlace->arrayOfAverages[aname].averageValue;
                            stderror = tmp->data->scoreOfPlace->arrayOfAverages[aname].standardError;
                        }
                    }
                }
            }
            tmp = tmp->next;
        }
    }
    return value;
}