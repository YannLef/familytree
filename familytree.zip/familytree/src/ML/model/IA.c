#include <stdio.h>
#include <stdlib.h>

#include "../../../include/LIST/structure.h"
#include "../../../include/IHM/structures.h"
#include "../../../include/ML/ML.h"

int estimatePlaceMariage(Place **searched, Model *m, type_event e, list_individu *c1, list_individu *c2)
{
    int error = NOT_FOUND;
    Place *listPotentialPlace = NULL;
    Coordinate *n3 = NULL;
    char* nameCityP0;

    if (c1 != NULL) {
        if (c2 != NULL) {
            //si il y a deux conjoint
            if (c1->data->generation == c2->data->generation) {
                
            }
        } else {
            error = C2_MISSING;
        }
    } else {
        error = C1_MISSING;
    }
    
    deleteListOfPlace(&listPotentialPlace);
    return error;
}

int estimateDateMariage(Model *m, type_event e, char *name, char* surname, int generation);

int estimateDateDesces(Model *m, type_event e, char *name, char* surname, int generation)
{
    Population *generationPop = NULL;
    Population *familyPop = NULL;
    Population *iascPop = NULL;

    getIndividuPopulationFromModel(&generationPop, m, GENERATION, name, surname, generation); 
    getIndividuPopulationFromModel(&familyPop, m, FAMILY, name, surname, generation); 
    getIndividuPopulationFromModel(&iascPop, m, I_ASC, name, surname, generation); 

    
}

int estimateDateBirth(Model *m, type_event e, char *name, char* surname, int generation);
