#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../include/LIST/structure.h"
#include "../../include/LIST/library/string/str_split.h"
#include "../../include/LIST/library/allocation/free.h"
#include "../../include/LIST/sublist/sublist.h"
#include "../../include/LIST/sublist/individu/individuSL.h"

#include "../../include/SEARCHENGINE/searchEngine.h"

m_date* splitDate(char *data)
{
    m_date *date = (m_date*)malloc(sizeof(m_date));

    char **dateSplit = str_splitChaine(3, data, "/");

    if( dateSplit[0] != NULL)
        date->jour = atoi(dateSplit[0]);

    if( dateSplit[1] != NULL)
        date->moi = atoi( dateSplit[1]);

    if( dateSplit[2] != NULL)
        date->annee = atoi( dateSplit[2]);

    return date;
}

int SEARCHENGINE_determineNombreParametre(char **data)
{
    int i = 0;
    int compteur = 0;
    m_date *date = NULL;

    if( (data)[0] != NULL )
        if( data[i] != 0 )
            compteur++;
    
    for( i = 1 ; i < 12 ; i++)
    {
        if( data[i] != NULL )
        {
            if( i == 4 || i == 6)
            {
                date = splitDate(data[i]);
                if( date != NULL)
                {
                    if( date->annee > 0)
                        compteur++;
                    
                    if( date->moi > 0)
                        compteur++;
                    
                    if( date->jour > 0)
                        compteur++;
                }  
            }
            else
            {
                compteur++;
            }       
        }
    }
    return compteur;
}

SUBLIST* SEARCHENGINE_searchIndividu(char ***data, LIST *ptrHead, funcSublist *func)
{
    SUBLIST *ptrHeadSl = NULL;
    SUBLIST *maillon = NULL;
    LIST *ptr = ptrHead;
    int compteur = 0;
    const int nbParametre = SEARCHENGINE_determineNombreParametre((*data));
    m_date *date = NULL;

    if( nbParametre > 0)
    {
        while( ptr != NULL )
        {
            if( (*data)[0] != NULL )
            {
                if( (*data)[0] != 0)
                {
                    if( atoi((*data)[0]) == ptr->u.list_individu->data->generation )
                    {
                        compteur++;
                    }
                }
            }

            if( (*data)[1] != NULL )
            {
                if( strcmp((*data)[1], ptr->u.list_individu->data->nom ) == 0)
                {
                    compteur++;
                }
            }

            if( (*data)[2] != NULL )
            {
                if( strcmp((*data)[2], ptr->u.list_individu->data->prenom ) == 0)
                {
                    compteur++;
                }
            }

            if( (*data)[3] != NULL )
            {
                if( strcmp((*data)[3], ptr->u.list_individu->data->genre ) == 0)
                {
                    compteur++;
                }
            }

            if( (*data)[4] != NULL )
            {
                if( ptr->u.list_individu->data->naissance != NULL)
                {
                    date = splitDate((*data)[4]);
                    if( date->annee != 0)
                    {
                        if( ptr->u.list_individu->data->naissance->annee == date->annee )
                        {
                            compteur++;
                        }
                    }

                    if( date->moi != 0)
                    {
                        if( ptr->u.list_individu->data->naissance->moi == date->moi)
                        {
                            compteur++;
                        }
                    }

                    if( date->jour != 0)
                    {
                        if( ptr->u.list_individu->data->naissance->jour == date->jour)
                        {
                            compteur++;
                        }
                    }

                    free(date);
                    date = NULL;
                }
            }

            if( (*data)[5] != NULL )
            {
                if( strcmp((*data)[5], ptr->u.list_individu->data->lieuNaissance ) == 0)
                {
                    compteur++;
                }
            }

            if( (*data)[6] != NULL )
            {
               if( ptr->u.list_individu->data->deces != NULL)
                {
                    date = splitDate((*data)[4]);
                    if( date->annee != 0)
                    {
                        if( ptr->u.list_individu->data->deces->annee == date->annee )
                        {
                            compteur++;
                        }
                    }

                    if( date->moi != 0)
                    {
                        if( ptr->u.list_individu->data->deces->moi == date->moi)
                        {
                            compteur++;
                        }
                    }

                    if( date->jour != 0)
                    {
                        if( ptr->u.list_individu->data->deces->jour == date->jour)
                        {
                            compteur++;
                        }
                    }

                    free(date);
                    date = NULL;
                }
            }

            if( (*data)[7] != NULL )
            {
                if( strcmp((*data)[7], ptr->u.list_individu->data->lieuDeces ) == 0)
                {
                    compteur++;
                }
            }

            if( (*data)[8] != NULL )
            {
                if( strcmp((*data)[8], ptr->u.list_individu->c1->u.list_individu->data->nom ) == 0)
                {
                    compteur++;
                }
            }

            if( (*data)[9] != NULL )
            {
                if( strcmp((*data)[9], ptr->u.list_individu->c1->u.list_individu->data->prenom ) == 0)
                {    
                    compteur++;
                }
            }

            if( (*data)[10] != NULL )
            {
                if( strcmp((*data)[10], ptr->u.list_individu->c2->u.list_individu->data->nom ) == 0)
                {    
                    compteur++;
                }
            }

            if( (*data)[11] != NULL )
            {
                if( strcmp((*data)[11], ptr->u.list_individu->c2->u.list_individu->data->prenom ) == 0)
                {    
                    compteur++;
                }
            }


            if( nbParametre == compteur)
            {
                SUBLIST_create(&maillon, type_sublistIndividu, func);
                SUBLIST_insertData(&maillon, ptr, func);
                SUBLISTINDIVIDU_insertMaillonSubList(&maillon, &ptrHeadSl);
                maillon = NULL;
            }
            compteur = 0;
            ptr = ptr->u.list_individu->suivant;
        }
    }
    return ptrHeadSl;
}