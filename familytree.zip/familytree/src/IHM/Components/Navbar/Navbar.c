#include <stdlib.h> 
#include <stdio.h> 
#include <math.h> 
#include <string.h>
#include "../../../../GFX/GfxLib.h" 
#include "../../../../GFX/BmpLib.h"

#include "../../../../include/IHM/structures.h"
#include "../../../../include/TREE/structure.h"
#include "../../../../include/IHM/Couleur.h"
#include "../../../../include/IHM/Keyboard.h"
#include "../../../../include/IHM/Page.h"
#include "../../../../include/LIST/listGeneration/methode/listSave.h"
#include "../../../../include/LIST/list/list.h"
#include "../../../../include/LIST/sublist/sublist.h"
#include "../../../../include/LIST/listGeneration/methode/deleteL.h"
#include "../../../../include/ML/ML.h"
#include "../../../../include/IHM/Data.h"
#include "../../../../include/IHM/Formulaire.h"
#include "../../../../include/IHM/DropDownMenuRight.h"
#include "../../../../include/IHM/Navbar.h"
#include "../../../../include/IHM/InputText.h"

 /**
  * -----------------------------------------------------------
  * -------------------- 1) INITIALISATION --------------------
  * -----------------------------------------------------------
  * */
  
/**
 * Fonction permettant d'initialiser la Navbar
 * -> c'est un tableau de 9 entiers correspondants aux 9 boutons de la Navbar
 * @author Yann LEFEVRE
 * */
void initNavbar(int nav[10]){
	for(int i=0;i<10;i++){
		nav[i] = 0;
	}
}

 /**
  * ---------------------------------------------------
  * -------------------- 2) UPDATE --------------------
  * ---------------------------------------------------
  * */
  
/**
 * Fonction transformant les clics sur la Navbar en actions concrètes
 * @author Yann LEFEVRE
 * */
void actualiseNavbar(int nbBouton, int nav[10], pages* pActuel, menuDeroulantVersDroite* menu, NoeudASC** courantASC, NoeudDESC** courantDESC, bool* modeAffichageArbre, message** messages,
int nbMessage, dataFile* fileM, LIST** head_mariage, funcList** func, funcSublist** funcSL, LIST** head_individu, dataFile* fileI, Form* formUpdateIndividu, allData* data,
 int* xEcran, int* yEcran, float* coefZoom){
	
	switch(nbBouton){ // On peut effectuer d'autres actions en fonction de quel onglet est ouvert
		case 0:
		break;
		
		case 1:
		break;
		
		case 2: // Save
			saveListInCSV(fileM, head_mariage, *func);
			saveListInCSV(fileI, head_individu, *func);

		break;
		
		case 3:
		break;
		
		case 4: // Si le bouton 4 (arbre) est cliqué, on switch entre l'arbre ascendant et descendant
			if(nav[3] != 1){
				if(*modeAffichageArbre == 0){
					*modeAffichageArbre = 1;
				}else{
					*modeAffichageArbre = 0;
				}
			}
		break;
		
		case 5:
		break;
		
		case 6: // Update
			if(*modeAffichageArbre == 0 && *courantASC != NULL){
				LISTINDIVIDU_getAllDatas(data,(*courantASC)->ptrIndividu); // On actualise les données avant d'afficher
				// On modifie les inputs pour mettre les informations dedans (placeholder)
				setString(formUpdateIndividu->tabInpuText[0],data->prenom); // Prenom
				setString(formUpdateIndividu->tabInpuText[1],data->nom); // Nom
				setString(formUpdateIndividu->tabInpuText[2],data->birthdayPlace); // Ville Naissance
				setString(formUpdateIndividu->tabInpuText[3],data->birthdayDate); // Date Naissance
				setString(formUpdateIndividu->tabInpuText[4],data->deathPlace); // Ville Mort
				setString(formUpdateIndividu->tabInpuText[5],data->deathDate); // Ville Mort
				setString(formUpdateIndividu->tabInpuText[6],data->c1prenom); // Prenom parent 1
				setString(formUpdateIndividu->tabInpuText[7],data->c1nom); // Nom parent 1
				setString(formUpdateIndividu->tabInpuText[8],data->c2prenom); // Prenom parent 2
				setString(formUpdateIndividu->tabInpuText[9],data->c2nom); // Nom parent 2
			}else if(*modeAffichageArbre == 1 && *courantDESC != NULL){
				LISTINDIVIDU_getAllDatas(data,(*courantDESC)->ptrIndividu); // On actualise les données avant d'afficher
				// On modifie les inputs pour mettre les informations dedans (placeholder)
				setString(formUpdateIndividu->tabInpuText[0],data->prenom); // Prenom
				setString(formUpdateIndividu->tabInpuText[1],data->nom); // Nom
				setString(formUpdateIndividu->tabInpuText[2],data->birthdayPlace); // Ville Naissance
				setString(formUpdateIndividu->tabInpuText[3],data->birthdayDate); // Date Naissance
				setString(formUpdateIndividu->tabInpuText[4],data->deathPlace); // Ville Mort
				setString(formUpdateIndividu->tabInpuText[5],data->deathDate); // Ville Mort
				setString(formUpdateIndividu->tabInpuText[6],data->c1prenom); // Prenom parent 1
				setString(formUpdateIndividu->tabInpuText[7],data->c1nom); // Nom parent 1
				setString(formUpdateIndividu->tabInpuText[8],data->c2prenom); // Prenom parent 2
				setString(formUpdateIndividu->tabInpuText[9],data->c2nom); // Nom parent 2
			}
		break;
		
		case 7:
		break;
		
		case 8: // Si on clique sur la croix, on revient à la page d'accueil
			pActuel->pFinal = accueil;
			
		// Libération des listes
			if(fileM != NULL && head_mariage != NULL){
				deleteList(fileM, head_mariage, *func, *funcSL);
			}
			
			if(fileI != NULL && head_individu != NULL){
				deleteList(fileI, head_individu, *func, *funcSL);
			}

			if(func != NULL){
				LIST_freePointeurFonction(func);
			}
			
			if(funcSL != NULL){
				SUBLIST_freePointeurFunction(funcSL);
			}
			
			*courantASC = NULL;
			*courantDESC = NULL;
			*xEcran = 0;
			*yEcran = 0;
			*coefZoom = 1;
			
			// On ferme les neufs onglets pour ne pas qu'ils se réouvrent par la suite à cause d'un non nettoyage de la mémoire
			for(int i=0;i<10;i++){ // On boucle pour sur les 9 onglets / boutons
				nav[i]=0; // On ferme tous les onglets avant de quitter
			}
			menu->xActuel = 0; // On ferme complétement le menu déroulant car l'animation ne fonctionne que quand on reste sur la page d'affichage de l'arbre
			return;
		break;
		
		case 9:
		break;
	}
	
	if(nbBouton == 4){ // Si l'onglet cliqué est le 4 (arbre)
		if(nav[3]==1){ // Et que l'onglet actuellement ouvert est la carte,
			initNavbar(nav); // On remet tous les onglets à 0
		}
	}else if(nbBouton == 2){
		// Rien car la sauvegarde ne demande pas d'ouvrir le menu
	}else{
		// On gère l'ouverture et la fermeture du menu déroulant
		
		if(nav[nbBouton] == 1){ // Si l'onglet cliqué était déja ouvert, on le ferme
			nav[nbBouton] = 0;
		}else{ // Sinon, on ferme tous les onglets pour ouvrir celui cliqué
			initNavbar(nav); // On remet tous les onglets à 0
			nav[nbBouton] = 1; // Puis on passe l'onglet cliqué à 1
		}
	}
}

 /**
  * ---------------------------------------------------
  * -------------------- 3) EVENTS --------------------
  * ---------------------------------------------------
  * */

/**
 * Fonction permettant de gérer les clics sur la Navbar
 * Appelle une fonction qui gère les clics en fonction du bouton cliqué dans la navbar
 * @author Yann LEFEVRE
 * */
void gereSourisNavbar(int xSouris, int ySouris, int nav[10], pages* pActuel, menuDeroulantVersDroite* menu, NoeudASC** courantASC, NoeudDESC** courantDESC, bool* modeAffichageArbre,
message** messages, int nbMessage, dataFile* fileM, LIST** head_mariage, funcList** func, funcSublist** funcSL, LIST** head_individu, dataFile* fileI, Form* formUpdateIndividu, allData* data,
int* xEcran, int* yEcran, float* coefZoom){
	if(xSouris >= 0 && xSouris <= 70){ // Si le x du clic se trouve entre 0 et 70, il est bien dans la zone de la navbar
		for(int i=0; i<8; i++){ // En partant du haut on a 7 boutons de chacun 70 px de haut, pour chacuns d'eux on vérifie si le clic à lieu dessus
			if(ySouris < hauteurFenetre() - 70*i && ySouris > hauteurFenetre() - 70*i - 70){
				actualiseNavbar(i, nav, pActuel, menu, courantASC, courantDESC, modeAffichageArbre, messages, nbMessage, fileM, head_mariage,
				func, funcSL, head_individu, fileI, formUpdateIndividu, data, xEcran, yEcran, coefZoom); // On appelle la fonction qui gère les actions en indiquant l'indice du bouton cliqué
			}
		}
		
		for(int i=0; i<2; i++){ // En partant du bas on a 2 boutons de hacun 70 px de bas, on vérifie si ils sont cliqués
			if(ySouris > 70*i && ySouris < 70*i + 70){
				actualiseNavbar(9-i, nav, pActuel, menu, courantASC, courantDESC, modeAffichageArbre, messages, nbMessage, fileM, head_mariage,
				func, funcSL, head_individu, fileI, formUpdateIndividu, data, xEcran, yEcran, coefZoom); // On appelle la fonction qui gère les actions en indiquant l'indice du bouton cliqué
			}
		}
	}
}

