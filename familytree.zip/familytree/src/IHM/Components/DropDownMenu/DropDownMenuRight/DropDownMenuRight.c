#include <stdlib.h> 
#include <stdio.h> 
#include <math.h> 
#include <string.h>
#include "../../../../../GFX/GfxLib.h" 
#include "../../../../../GFX/BmpLib.h"

#include "../../../../../include/IHM/structures.h"
#include "../../../../../include/TREE/structure.h"
#include "../../../../../include/IHM/Couleur.h"
#include "../../../../../include/IHM/Page.h"
#include "../../../../../include/ML/ML.h"
#include "../../../../../include/IHM/Rectangle.h"
#include "../../../../../include/LIST/list/individu/methode/getDataCharI.h"
#include "../../../../../include/IHM/Navbar.h"
#include "../../../../../include/IHM/InputText.h"
#include "../../../../../include/IHM/SliderVertical.h"
#include "../../../../../include/IHM/SliderHorizontal.h"
#include "../../../../../include/IHM/Checkbox.h"
#include "../../../../../include/IHM/Conversation.h"
#include "../../../../../include/IHM/ButtonSendMessage.h"
#include "../../../../../include/IHM/Formulaire.h"
#include "../../../../../include/IHM/current.h"
#include "../../../../../include/IHM/Data.h"

#include "../../../../../include/IHM/DropDownMenuRight.h"

extern couleurTab c; // Synchronise le tableau de couleurs

 /**
  * -----------------------------------------------------------
  * -------------------- 1) INITIALISATION --------------------
  * -----------------------------------------------------------
  * */
  
/**
 * Fonction permettant d'initialiser un menu déroulant se déroulant de la gauche vers la droite
 * @author Yann LEFEVRE
 * */
void initMenuDeroulantVersDroite(menuDeroulantVersDroite* menu, int yBas, int yHaut, int xGauche, int xDroite, bool etat){
	// Générales, ne changent pas
	menu->yBas = yBas;
	menu->yHaut = yHaut;
	menu->xGauche = xGauche;
	menu->xDroite = xDroite;
	menu->etat = etat;
	
	// En cours
	if(etat == 0){
		menu->xActuel = xGauche;
		menu->xFinal = xGauche;
	}else{
		menu->xActuel = xDroite;
		menu->xFinal = xDroite;
	}
}
  
 /**
  * ----------------------------------------------------
  * -------------------- 2) DISPLAY --------------------
  * ----------------------------------------------------
  * */
  
/**
 * Fonction affichant un menu déroulant se déroulant de la gauche vers la droite
 * @author Yann LEFEVRE
 * */
void afficheMenuDeroulantVersDroite(menuDeroulantVersDroite* menu, int xEcran, int yEcran, float coefZoom){
	
	for(int i=0; i<25;i++){ // For permettant d'accélérer le déplacement du menu de 18 fois (tout en passant dans les tests et donc sans débordements contrairement à une incrémentation de 18 d'un coup)
		if(menu->xActuel < menu->xFinal){ // Si la taille actuelle est plus petite que la taille finale visée on augmente celle ci
			menu->xActuel ++;
		}else if(menu->xActuel > menu->xFinal){ // Si la taille actuelle est plus grande que la taille finale visée, on diminue celle ci
			menu->xActuel --;
		}
	}
	
	// On affiche le rectangle correspondant
	rec r;
	initRectangle(&r,(menu->xActuel)/2,(menu->yHaut-menu->yBas)/2,menu->xActuel,hauteurFenetre(),0,c.couleurMenuDeroulant,c.couleurFemme);
	afficheRectangle(r,0,xEcran,yEcran,coefZoom);
	
	// On détermine l'état du menu déroulant (ouvert totalement ou non)
	if(menu->xActuel == menu->xDroite){
		menu->etat = 1;
	}else{
		menu->etat = 0;
	}

}

/**
 * Fonction permettant d'afficher le contenu d'un onglet si celui ci est selectionné et entièrement ouvert
 * @author Yann LEFEVRE
 * */
void afficheDetailMenu(int nav[10], pages p, menuDeroulantVersDroite* menuDeroulant, NoeudASC *courantASC, NoeudDESC *courantDESC, DonneesImageRGB *infos_individu_homme, 
DonneesImageRGB *infos_individu_femme, message** messages, int nbMessage, inputText inputAssistant, boutonSendMessage boutonEnvoiAssistant, DonneesImageRGB* user, DonneesImageRGB* help, 
Form formInsereIndividu, DonneesImageRGB *insertion_individu, bool modeAffichageArbre, Form formUpdateIndividu, Form formChercheIndividu, allData* data, DonneesImageRGB* infos_individu_null,
Form formCarteFrance, DonneesImageRGB *formulaire_carte, DonneesImageRGB *search_poeple, sliderVertical sliderCarteGauche, sliderVertical sliderCarteDroite, sliderHorizontal sliderCarteBas,
int valeurSliderCarteGauche, int valeurSliderCarteDroite, int valeurSliderCarteBas, Population* populationToDisplay,
DonneesImageRGB *credits, DonneesImageRGB *update_individu_null, DonneesImageRGB *update_individu_homme, DonneesImageRGB *update_individu_femme, int xEcran, int yEcran, float coefZoom){
	if (nav[0] == 1 && menuDeroulant->xActuel == menuDeroulant->xFinal && isOnPage(p,arbre)){ // Si l'onglet actuel est le numéro 0 et que le menu est entièrement ouvert
		// On affiche les données relatives à l'individu
		
		if(courantASC != NULL || courantDESC != NULL){
			
			if(modeAffichageArbre == 0){
				if(courantASC != NULL){
					LISTINDIVIDU_getAllDatas(data,courantASC->ptrIndividu);
				}
			}else{
				if(courantDESC != NULL){
					LISTINDIVIDU_getAllDatas(data,courantDESC->ptrIndividu);
				}
			}
			
			changeColor(c.noir);
			epaisseurDeTrait(3);
				
			afficheAllData(*data, infos_individu_femme, infos_individu_homme, infos_individu_null);
				
		}
	}else if (nav[7] == 1 && menuDeroulant->xActuel == menuDeroulant->xFinal && isOnPage(p,arbre)){
		// On affiche l'en tête
		changeColor(c.noir);
		epaisseurDeTrait(2);
		afficheChaine("Intelligent Assistant",25,70+(620-70)/2 - tailleChaine("Intelligent Assistant",25)/2,770);
		
		afficheConversation(messages, nbMessage, user, help); // On affiche les différents messages
		afficheInputTexte(inputAssistant, xEcran, yEcran, coefZoom); // On affiche la zone de saisie
		afficheBoutonSendMessage(boutonEnvoiAssistant, xEcran,yEcran,coefZoom); // On affiche le bouton permettant d'envoyer le message
		
	}else if (nav[5] == 1 && menuDeroulant->xActuel == menuDeroulant->xFinal && isOnPage(p,arbre)){
		if (insertion_individu != NULL){ 
			ecrisImage(70, 0, insertion_individu->largeurImage, insertion_individu->hauteurImage, insertion_individu->donneesRGB);
		}
		afficheForm(formInsereIndividu,xEcran,yEcran,coefZoom);
	}else if (nav[6] == 1 && menuDeroulant->xActuel == menuDeroulant->xFinal && isOnPage(p,arbre)) { //update d'un individu
		
		// On actualise data en fonction de la personne cliquée
		if(courantASC != NULL || courantDESC != NULL){
			
			// On actualise les données dans les deux cas : 
				// si l'arbre est en mode asc et qu'il existe un individu courant ASC
				// si l'arbre est en mode desc et qu'il existe un individu courant DESC
			if(modeAffichageArbre == 0){
				if(courantASC != NULL){
					LISTINDIVIDU_getAllDatas(data,courantASC->ptrIndividu);
					
					// Genre !IMPORTANT : à afficher en premier car sinon l'image va effacer les informations précédentes
					if(data->genre != NULL){
						if(strcmp(data->genre,"m") == 0){
							if (update_individu_homme != NULL){ ecrisImage(70, 0, update_individu_homme->largeurImage, update_individu_homme->hauteurImage, update_individu_homme->donneesRGB);}
						}else if(strcmp(data->genre,"f") == 0){
							if (update_individu_femme != NULL){ ecrisImage(70, 0, update_individu_femme->largeurImage, update_individu_femme->hauteurImage, update_individu_femme->donneesRGB);}
						}else{
							if (update_individu_null != NULL){ ecrisImage(70, 0, update_individu_null->largeurImage, update_individu_null->hauteurImage, update_individu_null->donneesRGB);}
						}
					}else{
							if (update_individu_null != NULL){ ecrisImage(70, 0, update_individu_null->largeurImage, update_individu_null->hauteurImage, update_individu_null->donneesRGB);}
						}
					afficheForm(formUpdateIndividu,xEcran,yEcran,coefZoom); // On affiche le formulaire d'update
				}
			}else{
				if(courantDESC != NULL){
					LISTINDIVIDU_getAllDatas(data,courantDESC->ptrIndividu);
					
					// Genre !IMPORTANT : à afficher en premier car sinon l'image va effacer les informations précédentes
					if(data->genre != NULL){
						if(strcmp(data->genre,"m") == 0){
							if (update_individu_homme != NULL){ ecrisImage(70, 0, update_individu_homme->largeurImage, update_individu_homme->hauteurImage, update_individu_homme->donneesRGB);}
						}else if(strcmp(data->genre,"f") == 0){
							if (update_individu_femme != NULL){ ecrisImage(70, 0, update_individu_femme->largeurImage, update_individu_femme->hauteurImage, update_individu_femme->donneesRGB);}
						}else{
							if (update_individu_null != NULL){ ecrisImage(70, 0, update_individu_null->largeurImage, update_individu_null->hauteurImage, update_individu_null->donneesRGB);}
						}
					}else{
							if (update_individu_null != NULL){ ecrisImage(70, 0, update_individu_null->largeurImage, update_individu_null->hauteurImage, update_individu_null->donneesRGB);}
						}
					afficheForm(formUpdateIndividu,xEcran,yEcran,coefZoom); // On affiche le formulaire d'update
				}
			}
				
		}
	}else if (nav[1] == 1 && menuDeroulant->xActuel == menuDeroulant->xFinal && isOnPage(p,arbre)){ //fonction de recherche

			if (search_poeple != NULL){ 
				ecrisImage(70, 0, search_poeple->largeurImage, search_poeple->hauteurImage, search_poeple->donneesRGB);
			}
			afficheForm(formChercheIndividu,xEcran,yEcran,coefZoom);
	}else if  (nav[3] == 1 && menuDeroulant->xActuel == menuDeroulant->xFinal && isOnPage(p,arbre)){ //Carte de france
			
			if (formulaire_carte != NULL){ 
				ecrisImage(70, 0, formulaire_carte->largeurImage, formulaire_carte->hauteurImage, formulaire_carte->donneesRGB);
			}
			afficheFormCarteFrance(formCarteFrance,xEcran,yEcran,coefZoom);
			
			couleurCourante(255, 0, 0);
			epaisseurDeTrait(30);
			point(110,50);
			epaisseurDeTrait(2);
			afficheChaine("Wedding", 18,140, 45);
			
			couleurCourante(0, 255, 0);
			epaisseurDeTrait(30);
			point(230,50);
			epaisseurDeTrait(2);
			afficheChaine("Death", 18,260, 45);

			couleurCourante(0, 0, 255);
			epaisseurDeTrait(30);
			point(350,50);
			epaisseurDeTrait(2);
			afficheChaine("Birth", 18,380, 45);

			afficheSliderVertical(sliderCarteGauche);
			afficheSliderVertical(sliderCarteDroite);
			epaisseurDeTrait(30);
			couleurCourante(255, 0, 0);
			point(sliderCarteBas.x - sliderCarteBas.largeur/2, sliderCarteBas.y);
			couleurCourante(0, 255, 0);
			point(sliderCarteBas.x, sliderCarteBas.y);
			couleurCourante(0, 0, 255);
			point(sliderCarteBas.x + sliderCarteBas.largeur/2, sliderCarteBas.y);
			afficheSliderHorizontal(sliderCarteBas);
			changeColor(c.vertPrincipal);
			epaisseurDeTrait(2);
			// On affiche le min
				char min[20];
				char minValue[20];
				sprintf(minValue,"%d",valeurSliderCarteGauche);
				strcpy(min,"min (year) : ");
				strcat(min,minValue);
				afficheChaine(min,20,sliderCarteGauche.x,hauteurFenetre()-30);
			// On affiche le max
				char max[20];
				char maxValue[20];
				sprintf(maxValue,"%d",valeurSliderCarteDroite);
				strcpy(max,"max (year) : ");
				strcat(max,maxValue);
				afficheChaine(max,20,sliderCarteDroite.x - tailleChaine(max,20),hauteurFenetre()-30);
			
			if (populationToDisplay != NULL) {
				//slider value to insert in the parameters for minimum data and maximum date
				//BIRTH : slider in the bottom give the type of population
				//the Population to display has been searched when cliked on ok
				displayPopulationOnMap(populationToDisplay, valeurSliderCarteBas, valeurSliderCarteGauche, valeurSliderCarteDroite);
			}
	}else if (nav[9] == 1 && menuDeroulant->xActuel == menuDeroulant->xFinal && isOnPage(p,arbre)) { //credits
		if (credits != NULL){ ecrisImage(70, 0, credits->largeurImage, credits->hauteurImage, credits->donneesRGB);}
	}
}
  
 /**
  * --------------------------------------------------
  * -------------------- 3) UPDATE --------------------
  * --------------------------------------------------
  * */

/**
 * Fonction envoyant un signal d'extension à menu déroulant se déroulant de la gauche vers la droite
 * @author Yann LEFEVRE
 * */
void agrandiMenuDeroulantVersDroite(menuDeroulantVersDroite* menu){
	menu->xFinal = menu->xDroite; // Définit l'objectif à atteindre en x à droite.
}

/**
 * Fonction envoyant un signal de repli à un menu déroulant se déroulant de la gauche vers la droite
 * @author Yann LEFEVRE
 * */
void reduiMenuDeroulantVersDroite(menuDeroulantVersDroite* menu){
	menu->xFinal = menu->xGauche; // Définit l'objectif à atteindre en x à gauche.
}

 /**
  * ---------------------------------------------------
  * -------------------- 4) EVENTS --------------------
  * ---------------------------------------------------
  * */

/**
 * Fonction permettant de réguler quand ouvrir ou fermer le menu déroulant
 * -> Cas classique : si tous les onglets sont fermés et qu'on clique sur l'un deux, le menu s'ouvre. Si on reclique sur le même, le menu se referme. 
 * En revanche si on clique sur un autre onglet, le menu reste ouvert (pour ne pas le fermer pour le réouvrir)
 * @author Yann LEFEVRE
 * */
void gereMenuDeroulantVersDroite(int nav[10], menuDeroulantVersDroite* menuDeroulant){
	int tmp=0; // variable temporaire permettant de savoir si un onglet est ouvert ou non.
	int tmp2=-1; // variable permettant de savoir quel est le numéro de l'onglet ouvert
	
	for(int i=0;i<10;i++){ // On boucle pour testser facilement les 9 onglets / boutons
		if(nav[i]==1){ // Si l'onglet est ouvert, on passe la variable temporaire à 1
			tmp=1;
			tmp2=i; // on stock le numéro de l'onglet ouvert
		}
	}
	
	if(tmp==0){ // Si la variable temporaire n'a pas été passé à 1, alors aucuns onglets n'est ouverts alors on demande la fermeture du menu (si il est déjà fermé il ne se passera rien)
		reduiMenuDeroulantVersDroite(menuDeroulant);
	}else{ // En revanche si la variable temporaire a été passé à 1, on demande l'ouverture du menu (si il est déjà ouvert rien ne se passera)
		switch(tmp2){ // En fonction de quel onglet est ouvert, on agit différemment
			case 0:
				menuDeroulant->xFinal = menuDeroulant->xDroite; // On agrandi le menu jusqu'à sa valeur par défaut
				break;
			
			case 1:
				menuDeroulant->xFinal = menuDeroulant->xDroite; // On agrandi le menu jusqu'à sa valeur par défaut
				break;
			
			case 2: // Rien car save = pas de menu qui s'ouvre
				break;
			
			case 3:
				menuDeroulant->xFinal = menuDeroulant->xDroite; // On agrandi le menu jusqu'à sa valeur par défaut
				break;
			
			case 4:
				// On n'ouvre aps le menu car ce bouton est le bouton arbre
				break;
			
			case 5:
				menuDeroulant->xFinal = menuDeroulant->xDroite; // On agrandi le menu jusqu'à sa valeur par défaut
				break;
			
			case 6:
				menuDeroulant->xFinal = menuDeroulant->xDroite; // On agrandi le menu jusqu'à sa valeur par défaut
				break;
			
			case 7:
				menuDeroulant->xFinal = menuDeroulant->xDroite; // On agrandi le menu jusqu'à sa valeur par défaut
				break;
			
			case 8:
				// On n'ouvre pas le menu car ce bouton est la croix et ne correspond à aucun onglet : il permet de revenir à la page précédente	
			break;
			
			case 9: // Si l'onglet ouvert est le 8 (paramètres), on veut que le menu s'affiche en plein écran
				menuDeroulant->xFinal = largeurFenetre(); // On agrandi le menu jusqu'au bout de la fenêtre (car onglet paramètre)
			break;
			
		}
	}	
}

/**
 * Fonction vérifiant si l'utilisateur clique sur un des individus de l'arbre ou non
 * Fonction récursive suivant le modèle de génération de l'arbre ascendant
 * @author Yann LEFEVRE
 * @param node la racine de l'arbre
 * @param courantASC noeud indiquant quel noeud est actuellement selectionné (sinon null)
 * */
void checkTreeASCNodeClic(int xSouris, int ySouris, NoeudASC* node, NoeudASC** courantASC, int xEcran, int yEcran, float coefZoom, int nav[10], menuDeroulantVersDroite menuDeroulant, bool modeAffichageArbre, Form* formUpdateIndividu, allData* data){
	if(xSouris > menuDeroulant.xFinal){
		if(node != NULL){
			if(isOnRectangleMobile(xSouris, ySouris, node->rect, xEcran, yEcran, coefZoom)){
				*courantASC = node;

				
				if(nav[6] == 1){ // Si on est sur l'onglet update individu, on agit différemment
					if(modeAffichageArbre == 0){
							LISTINDIVIDU_getAllDatas(data,node->ptrIndividu); // On actualise les données avant d'afficher
							// On modifie les inputs pour mettre les informations dedans (placeholder)
							setString(formUpdateIndividu->tabInpuText[0],data->prenom); // Prenom
							setString(formUpdateIndividu->tabInpuText[1],data->nom); // Nom
							setString(formUpdateIndividu->tabInpuText[2],data->birthdayPlace); // Ville Naissance
							setString(formUpdateIndividu->tabInpuText[3],data->birthdayDate); // Date Naissance
							setString(formUpdateIndividu->tabInpuText[4],data->deathPlace); // Ville Mort
							setString(formUpdateIndividu->tabInpuText[5],data->deathDate); // Ville Mort
							setString(formUpdateIndividu->tabInpuText[6],data->c1prenom); // Prenom parent 1
							setString(formUpdateIndividu->tabInpuText[7],data->c1nom); // Nom parent 1
							setString(formUpdateIndividu->tabInpuText[8],data->c2prenom); // Prenom parent 2
							setString(formUpdateIndividu->tabInpuText[9],data->c2nom); // Nom parent 2
					}
				}else{
					initNavbar(nav); // On ferme tous les onglets de la navbar
						nav[0] = 1; // On ouvre l'onglet 0 de la navbar pour afficher automatiquement les informations d'un individu au clic
				}
				
			}else{
				checkTreeASCNodeClic(abscisseSouris(), ordonneeSouris(), node->gauche, courantASC, xEcran, yEcran, coefZoom, nav, menuDeroulant, modeAffichageArbre, formUpdateIndividu, data);
				checkTreeASCNodeClic(abscisseSouris(), ordonneeSouris(), node->droite, courantASC, xEcran, yEcran, coefZoom, nav, menuDeroulant, modeAffichageArbre, formUpdateIndividu, data);
			}
		}
	}
}

/**
 * Fonction vérifiant si l'utilisateur clique sur un des individus de l'arbre ou non
 * Fonction récursive suivant le modèle de génération de l'arbre descendant
 * @author Yann LEFEVRE
 * @param node la racine de l'arbre
 * @param courantDESC noeud indiquant quel noeud est actuellement selectionné (sinon null)
 * */
void checkTreeDESCNodeClic(int xSouris, int ySouris, NoeudDESC* node, NoeudDESC** courantDESC, int xEcran, int yEcran, float coefZoom, int nav[10], menuDeroulantVersDroite menuDeroulant,
bool modeAffichageArbre, Form* formUpdateIndividu, allData* data){
	if(xSouris > menuDeroulant.xFinal){
		if(node != NULL){
			if(isOnRectangleMobile(xSouris, ySouris, node->rect, xEcran, yEcran, coefZoom)){
				*courantDESC = node;

				if(nav[6] == 1){ // Si on est sur l'onglet update individu, on agit différemment
					// TO DO : On met à jour les placeholder du form update individu
					
					
					if(modeAffichageArbre == 1){
							LISTINDIVIDU_getAllDatas(data,node->ptrIndividu); // On actualise les données avant d'afficher
							// On modifie les inputs pour mettre les informations dedans (placeholder)
						setString(formUpdateIndividu->tabInpuText[0],data->prenom); // Prenom
						setString(formUpdateIndividu->tabInpuText[1],data->nom); // Nom
						setString(formUpdateIndividu->tabInpuText[2],data->birthdayPlace); // Ville Naissance
						setString(formUpdateIndividu->tabInpuText[3],data->birthdayDate); // Date Naissance
						setString(formUpdateIndividu->tabInpuText[4],data->deathPlace); // Ville Mort
						setString(formUpdateIndividu->tabInpuText[5],data->deathDate); // Ville Mort
						setString(formUpdateIndividu->tabInpuText[6],data->c1prenom); // Prenom parent 1
						setString(formUpdateIndividu->tabInpuText[7],data->c1nom); // Nom parent 1
						setString(formUpdateIndividu->tabInpuText[8],data->c2prenom); // Prenom parent 2
						setString(formUpdateIndividu->tabInpuText[9],data->c2nom); // Nom parent 2
					}
					
				}else{
					initNavbar(nav); // On ferme tous les onglets de la navbar
						nav[0] = 1; // On ouvre l'onglet 0 de la navbar pour afficher automatiquement les informations d'un individu au clic
					}

			}else{
				NoeudHeadDESC* fils = node->nextNode;
				if(fils != NULL){
					NoeudDESC *liste = fils->ptrListNoeudDESC;
					while(liste!=NULL){
						checkTreeDESCNodeClic(xSouris, ySouris, liste, courantDESC, xEcran, yEcran, coefZoom, nav, menuDeroulant, modeAffichageArbre, formUpdateIndividu, data);
						liste = liste->nextMaillon;
					}
				}
			}
		}
	}
}
