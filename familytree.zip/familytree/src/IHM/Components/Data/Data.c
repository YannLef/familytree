#include <stdlib.h> 
#include <stdio.h> 
#include <math.h> 
#include <string.h>
#include <unistd.h>
#include "../../../../GFX/GfxLib.h" 
#include "../../../../GFX/BmpLib.h"

#include "../../../../include/IHM/structures.h"
#include "../../../../include/TREE/structure.h"
#include "../../../../include/IHM/Couleur.h"
#include "../../../../include/IHM/Keyboard.h"
#include "../../../../include/IHM/Mouse.h"
#include "../../../../include/LIST/list/individu/methode/getDataCharI.h"
#include "../../../../include/IHM/Data.h"

/**
 * @brief Fonction permettant d'initialiser une structure allData (met tous les char* à NULL)
 * @author Yann LEFEVRE
 * */
void LISTINDIVIDU_initAllDatas(allData* data){
		data->genre = NULL;
		data->prenom = NULL;
		data->nom = NULL;
		data->birthdayPlace = NULL;
		data->birthdayDate = NULL;
		data->deathPlace = NULL;
		data->deathDate = NULL;
		data->c1prenom = NULL;
		data->c1nom = NULL;
		data->c2prenom = NULL;
		data->c2nom = NULL;
}

/**
 * @brief Fonction récupérant toutes les données d'un individu de la liste chainée et stocke le tout dans une structure data faite sur mesure
 * @param data La structure permettant d'accueillir les informations récupérées
 * @param ptrMaillon Le maillon de la chaine pour lequel on veut récupérer les informations
 * @author Yann LEFEVRE
 * */
void LISTINDIVIDU_getAllDatas(allData* data, LIST *ptrMaillon){
	if(data->genre != NULL){
		free(data->genre);
		data->genre = NULL;
	}
	data->genre = LISTINDIVIDU_getDataCharGenre(ptrMaillon);

	if(data->prenom != NULL){
		free(data->prenom);
		data->prenom = NULL;
	}
	data->prenom = LISTINDIVIDU_getDataCharPrenom(ptrMaillon);
	
	if(data->nom != NULL){
		free(data->nom);
		data->nom = NULL;
	}
	data->nom = LISTINDIVIDU_getDataCharNom(ptrMaillon);
	
	if(data->birthdayPlace != NULL){
		free(data->birthdayPlace);
		data->birthdayPlace = NULL;
	}
	data->birthdayPlace = LISTINDIVIDU_getDataCharLieuNaissance(ptrMaillon);
	
	if(data->birthdayDate != NULL){
		free(data->birthdayDate);
		data->birthdayDate = NULL;
	}
	data->birthdayDate = LISTINDIVIDU_getDataCharDateNaissance(ptrMaillon);
	
	if(data->deathPlace != NULL){
		free(data->deathPlace);
		data->deathPlace = NULL;
	}
	data->deathPlace = LISTINDIVIDU_getDataCharLieuDeces(ptrMaillon);
	
	if(data->deathDate != NULL){
		free(data->deathDate);
		data->deathDate = NULL;
	}
	data->deathDate = LISTINDIVIDU_getDataCharDateDeces(ptrMaillon);
	
	if(data->c1prenom != NULL){
		free(data->c1prenom);
		data->c1prenom = NULL;
	}
	data->c1prenom = LISTINDIVIDU_getDataCharC1Prenom(ptrMaillon);
	
	if(data->c1nom != NULL){
		free(data->c1nom);
		data->c1nom = NULL;
	}
	data->c1nom = LISTINDIVIDU_getDataCharC1Nom(ptrMaillon);
	
	if(data->c2prenom != NULL){
		free(data->c2prenom);
		data->c2prenom = NULL;
	}
	data->c2prenom = LISTINDIVIDU_getDataCharC2Prenom(ptrMaillon);
	
	if(data->c2nom != NULL){
		free(data->c2nom);
		data->c2nom = NULL;
	}
	data->c2nom = LISTINDIVIDU_getDataCharC2Nom(ptrMaillon);
}

/**
 * @brief Fonction permettant d'afficher la totalité des informations concernant une personne dans le menu déroulant
 * @param data La structure contenant les informations 
 * @param infos_individu_femme L'image de fond dans le cas ou l'individu est une femme
 * @param infos_individu_homme L'image de fond dans le cas ou l'individu est un homme
 * @author Yannn LEFEVRE
 * */
void afficheAllData(allData data, DonneesImageRGB *infos_individu_femme, DonneesImageRGB *infos_individu_homme, DonneesImageRGB *infos_individu_null){
				// Genre !IMPORTANT : à afficher en premier car sinon l'image va effacer les informations précédentes
				if(data.genre != NULL){
					if(strcmp(data.genre,"m") == 0){
						if (infos_individu_homme != NULL){ ecrisImage(70, 0, infos_individu_homme->largeurImage, infos_individu_homme->hauteurImage, infos_individu_homme->donneesRGB);}
					}else if(strcmp(data.genre,"f") == 0){
						if (infos_individu_femme != NULL){ ecrisImage(70, 0, infos_individu_femme->largeurImage, infos_individu_femme->hauteurImage, infos_individu_femme->donneesRGB);}
					}else{
						if (infos_individu_null != NULL){ ecrisImage(70, 0, infos_individu_null->largeurImage, infos_individu_null->hauteurImage, infos_individu_null->donneesRGB);}
					}
				}else{
						if (infos_individu_null != NULL){ ecrisImage(70, 0, infos_individu_null->largeurImage, infos_individu_null->hauteurImage, infos_individu_null->donneesRGB);}
					}
				
				// Prénom
				if(data.prenom != NULL){
					afficheChaine(data.prenom,30,70 + (620-70)/2 - tailleChaine(data.prenom,30)/2,hauteurFenetre()-40);
				}
				
				// Nom
				if(data.nom != NULL){
					afficheChaine(data.nom,30,70 + (620-70)/2 - tailleChaine(data.nom,30)/2,hauteurFenetre()-80);
				}
				
				// Lieu de Naissance
				if(data.birthdayPlace != NULL){
					afficheChaine(data.birthdayPlace,30,70 + (620-70)/2 - tailleChaine(data.birthdayPlace,30)/2,hauteurFenetre()-260);
				}
				
				// Date de Naissance
				if(data.birthdayDate != NULL){
					afficheChaine(data.birthdayDate,30,70 + (620-70)/2 - tailleChaine(data.birthdayDate,30)/2,hauteurFenetre()-310);
				}
				
				// Lieu de Décès
				if(data.deathPlace != NULL){
					afficheChaine(data.deathPlace,30,70 + (620-70)/2 - tailleChaine(data.deathPlace,30)/2,hauteurFenetre()-430);
				}
				
				// Date de Mort
				if(data.deathDate != NULL){
					afficheChaine(data.deathDate,30,70 + (620-70)/2 - tailleChaine(data.deathDate,30)/2,hauteurFenetre()-470);
				}
				
				// Prenom c1
				if(data.c1prenom != NULL){
					afficheChaine(data.c1prenom,25,70 + (620-70)/4 - tailleChaine(data.c1prenom,25)/2,hauteurFenetre()-590);
				}
				
				// Nom c1
				if(data.c1nom != NULL){
					afficheChaine(data.c1nom,25,70 + (620-70)/4 - tailleChaine(data.c1nom,25)/2,hauteurFenetre()-630);
				}
				
				// Prenom c2
				if(data.c2prenom != NULL){
					afficheChaine(data.c2prenom,25,70 + 3*(620-70)/4 - tailleChaine(data.c2prenom,25)/2,hauteurFenetre()-590);
				}
				
				// Nom c2
				if(data.c2nom != NULL){
					afficheChaine(data.c2nom,25,70 + 3*(620-70)/4 - tailleChaine(data.c2nom,25)/2,hauteurFenetre()-630);
				}
}
