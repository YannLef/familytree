#include <stdlib.h> 
#include <stdio.h> 
#include <math.h> 
#include <string.h>
#include "../../../../GFX/GfxLib.h" 
#include "../../../../GFX/BmpLib.h"

#include "../../../../include/IHM/structures.h"
#include "../../../../include/IHM/Couleur.h"
#include "../../../../include/IHM/Page.h"
#include "../../../../include/IHM/Keyboard.h"
#include "../../../../include/IHM/Rectangle.h"
#include "../../../../include/TREE/structure.h"
#include "../../../../include/TREE/generationTree/treeDESC/treeDESC.h"
#include "../../../../include/IHM/GenealogicalTree.h"

extern keyboard keys; // Synchronise le clavier avec les autres fichiers

 /**
  * ---------------------------------------------------
  * -------------------- 1) UPDATE --------------------
  * ---------------------------------------------------
  * */
  
/**
 * Vérifie si les touches liées à l'affichage de l'arbre sont appuyés ou non
 * Modifie les variables de position de l'écran (xEcran, yEcran) et le zoom (coefZoom) si besoin
 * @author Yann LEFEVRE
 * */
void updateTreeDisplay(page p, int* xEcran, int* yEcran, float* coefZoom){
	
	if(p==arbre){ // Le déplacement dans l'arbre ne peut s'effetuer que si on est sur la page affichant l'arbre)
		// Déplacement via les flèches directionnelles
		// Au plus on dézoom, au plus les éléments se déplacent vite
		// Et vise versa, mais il y a une limite (basse) de déplacement afin que ça ne soit pas trop long à l'utilisation
		
		if(keyIsDown(keys.key_up)){  // si flèche du haut est appuyé -> on déplace l'affichage vers le bas
			 if(6/(*coefZoom) > 6){
				 *yEcran -= 6/(*coefZoom);
			 }else{
				 *yEcran -= 8;
			 }
		}
		
		if(keyIsDown(keys.key_down)){ // si flèche du bas est appuyé -> on déplace l'affichage vers le haut
			 if(6/(*coefZoom) > 6){
				 *yEcran += 6/(*coefZoom);
			 }else{
				*yEcran +=8;
			 }
		}
		
		if(keyIsDown(keys.key_left)){ // si flèche de gauche est appuyé -> on déplace l'affichage vers la droite
			if(6/(*coefZoom) > 6){
				*xEcran += 6/(*coefZoom);
			}else{
				*xEcran += 8;
			}
		}
		
		if(keyIsDown(keys.key_right)){ // si flèche de droite est appuyé -> on déplace l'affichage vers la gauche
			if(6/(*coefZoom) > 6){
				*xEcran -= 6/(*coefZoom);
			}else{
				*xEcran -= 8;
			}
		}
		
		if(keyIsDown(keys.key_page_up)){ // si flèche haut de page est appuyé -> on zoom // Le yEcran est modifié pour contrer les déplacements des arbres en cas de zoom/dézoom
			if(*coefZoom<4.3){
				*coefZoom += 0.1;
			}
		}
		
		if(keyIsDown(keys.key_page_down)){ // si flèche bas de page est appuyé -> on dézoom // Le yEcran est modifié pour contrer les déplacements des arbres en cas de zoom/dézoom
			if(*coefZoom>0.2){
				*coefZoom -= 0.1;
			}
		}
	
	}else{ // Si on quitte la page de l'arbre, on remet à zéro la position de ce dernier
		*coefZoom = 1;
		*xEcran = 0;
		*yEcran = 0;
	}
}

 /**
  * ----------------------------------------------------
  * -------------------- 2) DISPLAY --------------------
  * ----------------------------------------------------
  * */
  
/**
 * Fonction permettant d'afficher de manière récursive un arbre descandant. Fonctionne en décomposant l'arbre en plein d'autres arbres (chaque rectangle ayant des enfants devient une racine locale et sert à générer la suite de l'arbre)
 * @param n le nombre sur lequel s'effectue la récursivité, correspond à la génération (appel initial, n=0, ce dernier s'incrémente avec les appels récursifs et permet de naviguer dans toutes les générations)
 * @param noeud le pointeur vers le noeud actuel de l'arbre (racine locale)
 * @param l la longueur d'un rectangle
 * @param x,y, la position du centre du rectangle
 * @param xEcran, yEcran, coefZoom pour permettre l'évolution de l'affichage en fonction des déplacements et zoom de l'utilisateur
 * @param nbGen le nombre de générations totales
 * @param maxEnfants le tableau d'entiers (commencant à indice =0 pour la génération 0) référencant le nombre maximum d'enfants possible pour une personne d'une génération
 * @author Yann LEFEVRE
 * */
void afficheNoeudsDESC(int n, NoeudDESC* noeud, int l, int x, int y, int xEcran, int yEcran, float coefZoom, int nbGen, int* maxEnfants){
	if(noeud != NULL){
		float tailleMaxEnfants = l*coefZoom; // De base on met la longueur d'un rectangle (affecté par le zoom)
		
		for (int i=n; i<nbGen; i++){ // On boucle pour savoir la taille que prennent toutes les générations en dessous de la notre au maximum (on ne garde que les cas extrèmes)
				// on multiplie à chaque fois par le nombre max d'enfants + le nombre max -1 pour les espaces vides
			if(i==nbGen-1){ // La dernière génération est particulière : c'est la seule pour laquelle il faut prendre en compte les espaces entre les rectangles.
				tailleMaxEnfants = tailleMaxEnfants * 2; // On multiplie par le nombre max de rectangle de la dernière génération + ce nombre - 1 (correspondant au nombre d'espaces à laisser)
				//tailleMaxEnfants = tailleMaxEnfants * (2*maxEnfants[i-1] - 2); // On multiplie par le nombre max de rectangle de la dernière génération + ce nombre - 1 (correspondant au nombre d'espaces à laisser)
			}else{ // Toutes les autres générations sont interprétés identiquement
				tailleMaxEnfants = tailleMaxEnfants * maxEnfants[i]; // On multiplie simplement par le nombre d'enfants -> plus il y a d'enfants plus ils prendront de place
			}
		}
				
		float nouveauX = 0; // Variable permettant de faire varier l'abscisse des personnes de la meme génération ( l'ordonnée étant commune)
		
		noeud->rect.x = x; // On met à jour les coordonnées du rectangle avant de l'afficher
		noeud->rect.y = y;

		afficheRectangle(noeud->rect,1,xEcran,yEcran,coefZoom); // affiche le rectangle avec la fonction prévue pour, qui permet de tracer automatiquement en fonction de la position et du zoom
		
		if(coefZoom>0.5){
			epaisseurDeTrait(2);
			couleurCourante(0,0,0);
			int size = 14;
			afficheChaine(noeud->ptrIndividu->u.list_individu->data->nom,size*coefZoom,x-tailleChaine(noeud->ptrIndividu->u.list_individu->data->nom,size*coefZoom)/2 + xEcran*coefZoom,y + yEcran*coefZoom + size*coefZoom);
			afficheChaine(noeud->ptrIndividu->u.list_individu->data->prenom,size*coefZoom,x-tailleChaine(noeud->ptrIndividu->u.list_individu->data->prenom,size*coefZoom)/2 + xEcran*coefZoom,y + yEcran*coefZoom - size*coefZoom);
		}
				
		NoeudHeadDESC* fils = noeud->nextNode;
		if(fils != NULL){
			NoeudDESC *liste = fils->ptrListNoeudDESC;
			int k=0;
			
			while(liste!=NULL){
				nouveauX = x - tailleMaxEnfants/2 + tailleMaxEnfants/(2*maxEnfants[n]) + 2*k*tailleMaxEnfants/(2*maxEnfants[n]); // On part de la gauche + 1 demi rectangle car les coordonnées pour les tracer sont celles du centre et non du coin bas gauche et on va vers la droite en rajoutant 2* la taille d'un rectangle affecté par le zoom à chaque fois (un premier pour passer le retangle actuel, un deuxième pour laisser un rectangle d'espace entre 2 rectangles)
				afficheNoeudsDESC(n+1, liste, l, nouveauX,y-2*l*coefZoom, xEcran, yEcran, coefZoom, nbGen, maxEnfants); // appel récursif en passant aux noeuds d'en dessous
				traceLienParente(noeud->rect, liste->rect, 1, xEcran, yEcran, coefZoom);
				k++;
				liste = liste->nextMaillon;
			}
		}
	}
}

/**
 * Fonction permettant d'afficher de manière récursive un arbre ascendant (à partir d'un arbre binaire)
 * @param
 * n le nombre sur lequel s'effectue la récursivité (appel initial : n = nb génération -2)
 * signe (=1 ou =-1) permet de déterminer la position de l'élément (droite ou gauche par rapport à l'ancien)
 * noeud le pointeur vers le noeud actuel de l'arbre
 * l la longueur d'un rectangle
 * x,y la position du centre du rectangle
 * xEcran, yEcran, coefZoom pour permettre l'évolution de l'affichage en fonction des déplacements et zoom de l'utilisateur
 * @author Yann LEFEVRE
 * */
void afficheNoeudsASC(int n, int signe, NoeudASC* noeud, int l, int x, int y, int xEcran, int yEcran, float coefZoom){
	
	if(noeud!=NULL){
		int ecart = pow(2,n)*l*signe*coefZoom;
		afficheNoeudsASC(n-1,-1,noeud->gauche,l,x-ecart,y+l*coefZoom, xEcran, yEcran, coefZoom); // appelle la fonction pour tracer le noeud de gauche
		afficheNoeudsASC(n-1,1,noeud->droite,l,x+ecart,y+l*coefZoom, xEcran, yEcran, coefZoom); // appelle la fonction pour tracer le noeud de droite
		
		// on modifie les coordonnées du rectangle selon sa position dans l'arbre : on met x et y car ils ont été modifié avant l'appel de la fonction
		noeud->rect.x = x;
		noeud->rect.y = y;
		afficheRectangle(noeud->rect,1,xEcran,yEcran,coefZoom); // affiche le rectangle avec la fonction prévue pour, qui permet de tracer automatiquement en fonction de la position et du zoom
		
		if(coefZoom>0.5){
			epaisseurDeTrait(2);
			couleurCourante(0,0,0);
			int size = 14;
			afficheChaine(noeud->ptrIndividu->u.list_individu->data->nom,size*coefZoom,x-tailleChaine(noeud->ptrIndividu->u.list_individu->data->nom,size*coefZoom)/2 + xEcran*coefZoom,y + yEcran*coefZoom + size*coefZoom);
			afficheChaine(noeud->ptrIndividu->u.list_individu->data->prenom,size*coefZoom,x-tailleChaine(noeud->ptrIndividu->u.list_individu->data->prenom,size*coefZoom)/2 + xEcran*coefZoom,y + yEcran*coefZoom - size*coefZoom);
		}
	
		if(noeud->droite != NULL)
			traceLienParente(noeud->rect, noeud->droite->rect, 1, xEcran, yEcran, coefZoom);
		if(noeud->gauche != NULL)
			traceLienParente(noeud->rect, noeud->gauche->rect, 1, xEcran, yEcran, coefZoom);
	}
}

/**
 * Trace un lien de parenté entre deux rectangles, gère automatiquement les différents cas
 * @author Yann LEFEVRE
 * */
void traceLienParente(rec rect1, rec rect2, bool mobile, int xEcran, int yEcran, float coefZoom){
	
	int x1,y1,x2,y2;
	
	// Configure le lien
	epaisseurDeTrait(5);
	couleurCourante(0,0,0);
	
	// Cas 1 : rect1 est plus haut que rect2
	// => le lien partira du bas de rect1 et du haut de rect2
	if(rect1.y > rect2.y){
		x1 = rect1.x; // le lien part du milieu (abscisse) de rect1
		y1 = rect1.y - (rect1.hauteur*coefZoom)/2; // le lien part du bas (ordonnee) de rect1
		x2 = rect2.x; // le lien part du milieu (abscisse) de rect2
		y2 = rect2.y + (rect2.hauteur*coefZoom)/2; // le lien part du haut (ordonnee) de rect2
	
	if(mobile){
		x1 += xEcran*coefZoom;
		y1 += yEcran*coefZoom;
		x2 += xEcran*coefZoom;
		y2 += yEcran*coefZoom;
	}
		
		ligne(x1,y1,x2,y2);
	}else
	
	// Cas 2 : rect1 est plus bas que rect2
	// => le lien partira du haut de rect1 et du bas de rect2
	if(rect1.y < rect2.y){
		x1 = rect1.x; // le lien part du milieu (abscisse) de rect1
		y1 = rect1.y + (rect1.hauteur*coefZoom)/2; // le lien part du bas (ordonnee) de rect1
		x2 = rect2.x; // le lien part du milieu (abscisse) de rect2
		y2 = rect2.y - (rect2.hauteur*coefZoom)/2; // le lien part du haut (ordonnee) de rect2
		
	if(mobile){
		x1 += xEcran*coefZoom;
		y1 += yEcran*coefZoom;
		x2 += xEcran*coefZoom;
		y2 += yEcran*coefZoom;
	}
		
		ligne(x1,y1,x2,y2);
	}else
	
	// Sinon : rect1 est aussi haut que rect2
	
	// Cas 3 : rect1 est à gauche de rect2
	// => le lien partira de la droite de rect1 et de la gauche de rect2
	if(rect1.x < rect2.x){
		x1 = rect1.x + (rect1.largeur*coefZoom)/2; // le lien part de la droite (abscisse) de rect1
		y1 = rect1.y; // le lien part du milieu (ordonnee) de rect1
		x2 = rect2.x - (rect2.largeur*coefZoom)/2; // le lien part de la gauche (abscisse) de rect2
		y2 = rect2.y; // le lien part du milieu (ordonnee) de rect2
		
	if(mobile){
		x1 += xEcran*coefZoom;
		y1 += yEcran*coefZoom;
		x2 += xEcran*coefZoom;
		y2 += yEcran*coefZoom;
	}
		
		ligne(x1,y1,x2,y2);
	}else
	
	// Cas 4 : rect1 est à droite de rect2
	// => le lien partira de la gauche de rect1 et de la droite de rect2
	if(rect1.x > rect2.x){
		x1 = rect1.x - (rect1.largeur*coefZoom)/2; // le lien part de la gauche (abscisse) de rect1
		y1 = rect1.y; // le lien part du milieu (ordonnee) de rect1
		x2 = rect2.x + (rect2.largeur*coefZoom)/2; // le lien part de la droite (abscisse) de rect2
		y2 = rect2.y; // le lien part du milieu (ordonnee) de rect2
		
	if(mobile){
		x1 += xEcran*coefZoom;
		y1 += yEcran*coefZoom;
		x2 += xEcran*coefZoom;
		y2 += yEcran*coefZoom;
	}
		
		ligne(x1,y1,x2,y2);
	}
}
