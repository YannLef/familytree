#include <stdlib.h>
#include <stdio.h> 
#include <math.h> 
#include <string.h>
#include <unistd.h>
#include "../../GFX/GfxLib.h" 
#include "../../GFX/BmpLib.h"

#include "../../include/IHM/structures.h"
#include "../../include/TREE/structure.h"
#include "../../include/IHM/Couleur.h"
#include "../../include/IHM/Keyboard.h"
#include "../../include/IHM/Mouse.h"
#include "../../include/IHM/Rectangle.h"
#include "../../include/IHM/ButtonChangePage.h"
#include "../../include/IHM/ButtonChangeFile.h"
#include "../../include/IHM/Page.h"
#include "../../include/IHM/Navbar.h"
#include "../../include/IHM/InputText.h"
#include "../../include/IHM/GenealogicalTree.h"
#include "../../include/IHM/SliderVertical.h"
#include "../../include/IHM/SliderHorizontal.h"
#include "../../include/IHM/Carre.h"
#include "../../include/IHM/Checkbox.h"

#include "../../include/LIST/structure.h"
#include "../../include/LIST/list/list.h"
#include "../../include/LIST/sublist/sublist.h"

#include "../../include/LIST/dataTree/dataTree.h"
#include "../../include/IHM/Data.h"
#include "../../include/LIST/listGeneration/individu/generateI.h"
#include "../../include/LIST/listGeneration/mariage/generateM.h"
#include "../../include/LIST/listGeneration/methode/listSave.h"
#include "../../include/LIST/list/individu/methode/toolI.h"
#include "../../include/LIST/list/mariage/methode/toolM.h"
#include "../../include/LIST/list/individu/methode/displayTerminalI.h"
#include "../../include/LIST/list/mariage/methode/displayTerminalM.h"
#include "../../include/LIST/list/individu/methode/getDataCharI.h"
#include "../../include/ML/ML.h"
#include "../../include/IHM/DropDownMenuRight.h"
#include "../../include/IHM/Formulaire.h"
#include "../../include/IHM/FileExplorer.h"
#include "../../include/TREE/generationTree/treeASC/treeASC.h"
#include "../../include/TREE/generationTree/treeDESC/treeDESC.h"

#include "../../include/LIST/listGeneration/methode/deleteL.h"
#include "../../include/IHM/RadioButton.h"
#include "../../include/TREE/generationTree/noeudData.h"

#include "../../include/LIST/addMaillonList/individu/addIndividu.h"
#include "../../include/LIST/updateMaillonList/individu/updateIndividu.h"

#include "../../include/SEARCHENGINE/searchEngine.h"

#include "../../include/IHM/current.h"

extern keyboard keys; // Synchronise le clavier avec les autres fichiers
extern couleurTab c; // Synchronise le clavier avec les autres fichiers

/**
 * Fonction permettant d'afficher un viseur pointant au centre de la fenêtre
 * Permet notamment de tester la précision du zoom
 * @author Yann LEFEVRE
 * */
void afficheViseurCentre(void){
	couleurCourante(0,255,0); // Définit la couleur sur du vert
	epaisseurDeTrait(3); // Définit l'épaisseur du trait à 3 px
	
	// Trace le viseur
	ligne(largeurFenetre()/2,0,largeurFenetre()/2,hauteurFenetre());
	ligne(0,hauteurFenetre()/2,largeurFenetre(),hauteurFenetre()/2);
}

/**
 * Fonction regroupant l'affichage de la page accueil du programme
 * Permet notamment de faciliter la lecture du main
 * @author Yann LEFEVRE
 * */
void afficheAccueil(DonneesImageRGB* fondaccueil, boutonChangePage newTree, boutonChangePage openTree, int xEcran, int yEcran, float coefZoom){
	if (fondaccueil != NULL){ ecrisImage(0, 0, fondaccueil->largeurImage, fondaccueil->hauteurImage, fondaccueil->donneesRGB);} // Si l'image de la barre de navigation a pu être lue, on l'affiche à gauche de l'écran
	//~ afficheBoutonChangePage(newTree, xEcran, yEcran, coefZoom);
	afficheBoutonChangePage(openTree, xEcran, yEcran, coefZoom);
}

/**
 * Fonction regroupant l'affichage de la page arbre du programme
 * Permet de faciliter la lecture du main
 * @author Yann LEFEVRE
 * */
void afficheArbre(int nav[10], bool modeAffichageArbre, NoeudData *treeASC, NoeudData *treeDESC, NoeudASC *rootASC, NoeudDESC *rootDESC, DonneesImageRGB *map, DonneesImageRGB *infos_individu_homme, 
DonneesImageRGB *infos_individu_femme, DonneesImageRGB* infos_individu_null, DonneesImageRGB *navbarre, pages p, NoeudASC *courantASC, NoeudDESC *courantDESC, menuDeroulantVersDroite* menuDeroulant,
message** messages, int nbMessage, inputText inputAssistant, boutonSendMessage boutonEnvoiAssistant, DonneesImageRGB* user, DonneesImageRGB* help, Form formInsereIndividu,
DonneesImageRGB *insertion_individu, Form formUpdateIndividu, Form formChercheIndividu, Form formCarteFrance, DonneesImageRGB *formulaire_carte, DonneesImageRGB *search_poeple,
allData* data, sliderVertical sliderCarteGauche, sliderVertical sliderCarteDroite, sliderHorizontal sliderCarteBas, int valeurSliderCarteGauche, int valeurSliderCarteDroite,
int valeurSliderCarteBas, Population* populationToDisplay, DonneesImageRGB *credits, DonneesImageRGB *update_individu_null, DonneesImageRGB *update_individu_homme, DonneesImageRGB *update_individu_femme,
int xEcran, int yEcran, float coefZoom){

	if(nav[3] != 1){ // Quand la carte est ouverte, on n'affiche plus les arbres
		if(modeAffichageArbre == 0){
			// On affiche l'arbre ASC
			afficheNoeudsASC(treeASC->nombreGeneration - 2, 1, rootASC, 200, largeurFenetre()/2, hauteurFenetre()/2, xEcran, yEcran, coefZoom);
		}else{
			// On affiche l'arbre DESC
			afficheNoeudsDESC(0, rootDESC, 200, largeurFenetre()/2, hauteurFenetre()/2, xEcran, yEcran, coefZoom, treeDESC->nombreGeneration, treeDESC->nombreEnfantMaxGeneration);
		}
	}else{
		if(map != NULL){ // Si la carte a pu être chargée, on l'affiche
			couleurCourante(255,255,255);
			rectangle(0,0,largeurFenetre(),hauteurFenetre());
			ecrisImage(620, 0, map->largeurImage, map->hauteurImage, map->donneesRGB);
		}
	}
					
	afficheMenuDeroulantVersDroite(menuDeroulant, xEcran, yEcran, coefZoom); // Affiche le menu déroulant (fond animé)
	if (navbarre != NULL){ ecrisImage(0, (hauteurFenetre()-navbarre->hauteurImage)/2, navbarre->largeurImage, navbarre->hauteurImage, navbarre->donneesRGB);} // Si l'image de la barre de navigation a pu être lue, on l'affiche à gauche de l'écran
	afficheDetailMenu(nav, p, menuDeroulant, courantASC, courantDESC, infos_individu_homme, infos_individu_femme, messages, nbMessage, inputAssistant, boutonEnvoiAssistant, user, help, 
	formInsereIndividu, insertion_individu, modeAffichageArbre, formUpdateIndividu, formChercheIndividu, data, infos_individu_null, formCarteFrance, formulaire_carte,
	search_poeple, sliderCarteGauche, sliderCarteDroite, sliderCarteBas, valeurSliderCarteGauche, valeurSliderCarteDroite, valeurSliderCarteBas, populationToDisplay,
	credits, update_individu_null, update_individu_homme, update_individu_femme, xEcran, yEcran, coefZoom); // Affiche les détails du menu déroulant (varie selon l'onglet actuel de la navbar)				

}

void initFormInsereIndividu(Form* formInsereIndividu){
	static inputText inputText1,inputText2,inputText3,inputText4,inputText5,inputText6,inputText7,inputText8,inputText9,inputText10,inputText11;
    static radiobutton radiobutton1;
    
    initForm(formInsereIndividu);
    
	// FORMULAIRE INSERT
	initInputText(&inputText1,1,380,660,150,25,1,c.blanc,c.noir); //nom
	addInputTextToForm(formInsereIndividu,&inputText1);
	initInputText(&inputText2,0,380,625,150,25,1,c.blanc,c.noir); //prenom
	addInputTextToForm(formInsereIndividu,&inputText2);
	initInputText(&inputText3,0,380,590,150,25,1,c.blanc,c.noir); //generation
	addInputTextToForm(formInsereIndividu,&inputText3);
	
	initInputText(&inputText4,0,380,447,150,25,1,c.blanc,c.noir); //lieu de naissance
	addInputTextToForm(formInsereIndividu,&inputText4);
	initInputText(&inputText5,0,380,408,150,25,1,c.blanc,c.noir); //date de naissance JOUR/MOIS/ANNEE
	addInputTextToForm(formInsereIndividu,&inputText5);

	initInputText(&inputText6,0,380,365,150,25,1,c.blanc,c.noir); //lieu de deces
	addInputTextToForm(formInsereIndividu,&inputText6);
	initInputText(&inputText7,0,380,324,150,25,1,c.blanc,c.noir); //date de deces JOUR/MOIS/ANNEE
	addInputTextToForm(formInsereIndividu,&inputText7);

	initInputText(&inputText8,0,470,207,150,25,1,c.blanc,c.noir); //nom du pere 
	addInputTextToForm(formInsereIndividu,&inputText8);
	initInputText(&inputText9,0,470,166,150,25,1,c.blanc,c.noir); //prenom du pere 
	addInputTextToForm(formInsereIndividu,&inputText9);
	initInputText(&inputText10,0,470,120,150,25,1,c.blanc,c.noir); //nom de la mere 
	addInputTextToForm(formInsereIndividu,&inputText10);
	initInputText(&inputText11,0,470,79,150,25,1,c.blanc,c.noir); //prenom de la mere 
	addInputTextToForm(formInsereIndividu,&inputText11);

	initRadioButton(&radiobutton1,"",350,550,30,1,c.blanc,c.noir,2,0); //RB homme/femme
	addRadioButtonToForm(formInsereIndividu,&radiobutton1);
}

void initFormUpdateIndividu(Form* formUpdateIndividu){
	static inputText inputText15,inputText16,inputText17,inputText18,inputText19,inputText20,inputText21,inputText22,inputText23,inputText24;

    initForm(formUpdateIndividu);
	
	// FORMULAIRE UPDATE
	initInputText(&inputText15,1,350,780,170,30,1,c.blanc,c.noir); //nom
	addInputTextToForm(formUpdateIndividu,&inputText15);
	initInputText(&inputText16,0,350,740,170,30,1,c.blanc,c.noir); //prenom
	addInputTextToForm(formUpdateIndividu,&inputText16);

	//genre non modifiable
	//generation non modifiable
	
	initInputText(&inputText17,0,350,545,170,30,1,c.blanc,c.noir); //lieu de naissance
	addInputTextToForm(formUpdateIndividu,&inputText17);
	initInputText(&inputText18,0,350,505,170,30,1,c.blanc,c.noir); //date de naissance JOUR/MOIS/ANNEE
	addInputTextToForm(formUpdateIndividu,&inputText18);

	initInputText(&inputText19,0,350,370,170,30,1,c.blanc,c.noir); //lieu de deces 
	addInputTextToForm(formUpdateIndividu,&inputText19);
	initInputText(&inputText20,0,350,330,170,30,1,c.blanc,c.noir); //date de deces JOUR
	addInputTextToForm(formUpdateIndividu,&inputText20);

	initInputText(&inputText21,0,215,207,150,30,1,c.blanc,c.noir); //nom du pere 
	addInputTextToForm(formUpdateIndividu,&inputText21);
	initInputText(&inputText22,0,215,166,150,30,1,c.blanc,c.noir); //prenom du pere
	addInputTextToForm(formUpdateIndividu,&inputText22); 
	initInputText(&inputText23,0,480,207,150,30,1,c.blanc,c.noir); //nom de la mere 
	addInputTextToForm(formUpdateIndividu,&inputText23);
	initInputText(&inputText24,0,480,166,150,30,1,c.blanc,c.noir); //prenom de la mere
	addInputTextToForm(formUpdateIndividu,&inputText24);
}

void initFormChercheIndividu(Form* formChercheIndividu){
	static inputText inputText25,inputText26,inputText27,inputText28,inputText29,inputText30,inputText31,inputText32,inputText33,inputText34,inputText35;
    static radiobutton radiobutton2;
    
    initForm(formChercheIndividu);
    
	// FORMULAIRE CHERCHE
	initInputText(&inputText25,1,380,660,150,25,1,c.blanc,c.noir); //nom
	addInputTextToForm(formChercheIndividu,&inputText25);
	initInputText(&inputText26,0,380,625,150,25,1,c.blanc,c.noir); //prenom
	addInputTextToForm(formChercheIndividu,&inputText26);
	initInputText(&inputText27,0,380,590,150,25,1,c.blanc,c.noir); //generation
	addInputTextToForm(formChercheIndividu,&inputText27);
	
	initInputText(&inputText28,0,380,447,150,25,1,c.blanc,c.noir); //lieu de naissance
	addInputTextToForm(formChercheIndividu,&inputText28);
	initInputText(&inputText29,0,380,408,150,25,1,c.blanc,c.noir); //date de naissance JOUR/MOIS/ANNEE
	addInputTextToForm(formChercheIndividu,&inputText29);

	initInputText(&inputText30,0,380,365,150,25,1,c.blanc,c.noir); //lieu de deces
	addInputTextToForm(formChercheIndividu,&inputText30);
	initInputText(&inputText31,0,380,324,150,25,1,c.blanc,c.noir); //date de deces JOUR/MOIS/ANNEE
	addInputTextToForm(formChercheIndividu,&inputText31);

	initInputText(&inputText32,0,470,207,150,25,1,c.blanc,c.noir); //nom du pere 
	addInputTextToForm(formChercheIndividu,&inputText32);
	initInputText(&inputText33,0,470,166,150,25,1,c.blanc,c.noir); //prenom du pere 
	addInputTextToForm(formChercheIndividu,&inputText33);
	initInputText(&inputText34,0,470,120,150,25,1,c.blanc,c.noir); //nom de la mere 
	addInputTextToForm(formChercheIndividu,&inputText34);
	initInputText(&inputText35,0,470,79,150,25,1,c.blanc,c.noir); //prenom de la mere 
	addInputTextToForm(formChercheIndividu,&inputText35);

	initRadioButton(&radiobutton2,"",350,550,30,1,c.blanc,c.noir,2,1); //RB homme/femme
	addRadioButtonToForm(formChercheIndividu,&radiobutton2);
}

void gereCLicFormCarteFrance(Form formCarteFrance, int xSouris, int ySouris){
	switch(formCarteFrance.tabRadioButton[0]->on) {
		case -1:
			break;

		case 3:
			formCarteFrance.tabInpuText[3]->etat = 0;
			formCarteFrance.tabInpuText[4]->etat = 0;
			formCarteFrance.tabInpuText[5]->etat = 0;
			formCarteFrance.tabInpuText[6]->etat = 0;
			formCarteFrance.tabInpuText[7]->etat = 0;
			gereSourisInputText(formCarteFrance.tabInpuText[0],xSouris,ySouris);
			gereSourisInputText(formCarteFrance.tabInpuText[1],xSouris,ySouris);
			gereSourisInputText(formCarteFrance.tabInpuText[2],xSouris,ySouris);

			break;

		case 2:
			formCarteFrance.tabInpuText[0]->etat = 0;
			formCarteFrance.tabInpuText[1]->etat = 0;
			formCarteFrance.tabInpuText[2]->etat = 0;
			formCarteFrance.tabInpuText[6]->etat = 0;
			formCarteFrance.tabInpuText[7]->etat = 0;
			gereSourisInputText(formCarteFrance.tabInpuText[3],xSouris,ySouris);
			gereSourisInputText(formCarteFrance.tabInpuText[4],xSouris,ySouris);
			gereSourisInputText(formCarteFrance.tabInpuText[5],xSouris,ySouris);

			break;

		case 1:
			formCarteFrance.tabInpuText[0]->etat = 0;
			formCarteFrance.tabInpuText[1]->etat = 0;
			formCarteFrance.tabInpuText[2]->etat = 0;
			formCarteFrance.tabInpuText[3]->etat = 0;
			formCarteFrance.tabInpuText[4]->etat = 0;
			formCarteFrance.tabInpuText[5]->etat = 0;
			formCarteFrance.tabInpuText[7]->etat = 0;
			gereSourisInputText(formCarteFrance.tabInpuText[6],xSouris,ySouris);
			break;

		case 0:
			formCarteFrance.tabInpuText[0]->etat = 0;
			formCarteFrance.tabInpuText[1]->etat = 0;
			formCarteFrance.tabInpuText[2]->etat = 0;
			formCarteFrance.tabInpuText[3]->etat = 0;
			formCarteFrance.tabInpuText[4]->etat = 0;
			formCarteFrance.tabInpuText[5]->etat = 0;
			formCarteFrance.tabInpuText[6]->etat = 0;
			gereSourisInputText(formCarteFrance.tabInpuText[7],xSouris,ySouris);
			break;
	}

	// On gère les clis des checkbox
	for(int i=0;i<formCarteFrance.nbCheckbox;i++){
		gereClicCheckbox(formCarteFrance.tabCheckbox[i],xSouris,ySouris);
	}
	
	// On gère les clics des radioButtons
	for(int i=0;i<formCarteFrance.nbRadioButton;i++){
		gereClicRadioButton(formCarteFrance.tabRadioButton[i],xSouris,ySouris);
	}
}

void afficheFormCarteFrance(Form formCarteFrance, int xEcran, int yEcran, float coefZoom){
	changeColor(c.noir);
	afficheChaine("Ascendant Individual",35,200,580);
	afficheChaine("Descendant Individual",35,200,490);
	afficheChaine("Family",40,200,400);
	afficheChaine("Generation",40,200,310);

	switch(formCarteFrance.tabRadioButton[0]->on) {
			case -1:
				changeColor(c.gris125);
				afficheChaine("Select a RadioButton",30,120,170);
				break;

			case 3:

				changeColor(c.noir);
				afficheChaine("Last Name :",20,100,230);
				afficheInputTexte(*(formCarteFrance.tabInpuText[0]), xEcran, yEcran, coefZoom);

				changeColor(c.noir);
				afficheChaine("First Name :",20,100,160);
				afficheInputTexte(*(formCarteFrance.tabInpuText[1]), xEcran, yEcran, coefZoom);

				changeColor(c.noir);
				afficheChaine("Generation :",20,100,90);
				afficheInputTexte(*(formCarteFrance.tabInpuText[2]), xEcran, yEcran, coefZoom);

				break;

			case 2:
				changeColor(c.noir);
				afficheChaine("Last Name :",20,100,230);
				afficheInputTexte(*(formCarteFrance.tabInpuText[3]), xEcran, yEcran, coefZoom);

				changeColor(c.noir);
				afficheChaine("First Name :",20,100,160);
				afficheInputTexte(*(formCarteFrance.tabInpuText[4]), xEcran, yEcran, coefZoom);

				changeColor(c.noir);
				afficheChaine("Generation :",20,100,90);
				afficheInputTexte(*(formCarteFrance.tabInpuText[5]), xEcran, yEcran, coefZoom);

				break;

			case 1:
				changeColor(c.noir);
				afficheChaine("Last Name :",20,100,220);
				afficheInputTexte(*(formCarteFrance.tabInpuText[6]), xEcran, yEcran, coefZoom);
				break;

			case 0:
				changeColor(c.noir);
				afficheChaine("Generation :",20,100,220);
				afficheInputTexte(*(formCarteFrance.tabInpuText[7]), xEcran, yEcran, coefZoom);
				break;
	}

	afficheRadioButton(*(formCarteFrance).tabRadioButton[0]);
}

void initFormCarteFrance(Form *formCarteFrance){

	static inputText inputText36,inputText37,inputText38,inputText39,inputText40,inputText41,inputText42,inputText43;
	static radiobutton radiobutton3;
    
    initForm(formCarteFrance);

	initInputText(&inputText36,1,450,230,150,35,1,c.blanc,c.noir); //nom
	addInputTextToForm(formCarteFrance,&inputText36);

	initInputText(&inputText37,1,450,160,150,35,1,c.blanc,c.noir); //prénom
	addInputTextToForm(formCarteFrance,&inputText37);

	initInputText(&inputText38,1,400,90,50,35,1,c.blanc,c.noir); //génération
	addInputTextToForm(formCarteFrance,&inputText38);

	initInputText(&inputText39,1,450,230,150,35,1,c.blanc,c.noir); //nom
	addInputTextToForm(formCarteFrance,&inputText39);
	
	initInputText(&inputText40,1,450,160,150,35,1,c.blanc,c.noir); //prenom
	addInputTextToForm(formCarteFrance,&inputText40);

	initInputText(&inputText41,1,400,90,50,35,1,c.blanc,c.noir); //génération
	addInputTextToForm(formCarteFrance,&inputText41);

	initInputText(&inputText42,1,450,230,150,35,1,c.blanc,c.noir); //nom
	addInputTextToForm(formCarteFrance,&inputText42);

	initInputText(&inputText43,1,450,230,150,35,1,c.blanc,c.noir); //nom
	addInputTextToForm(formCarteFrance,&inputText43);


	initRadioButton(&radiobutton3,"vertical",150,460,45,1,c.blanc,c.noir,4,-1); // radio button Individu ASC / DESC / famille / génération
	addRadioButtonToForm(formCarteFrance,&radiobutton3);
}

void saveDonneesFormCarte(Form *formulaire, Population** populationToDisplay, Model* modelIA){
	DataFormulaire dataForm;
	dataForm.typeCheckBox = formulaire->tabRadioButton[0]->on;

		switch(formulaire->tabRadioButton[0]->on){
			case 3:
				dataForm.nb = 3;
				dataForm.tab=malloc(sizeof(char*)*3);
				for (int i=0;i<3;i++){

					if (formulaire->tabInpuText[i]->string != NULL){
						dataForm.tab[i]=malloc(sizeof(char)*strlen(formulaire->tabInpuText[i]->string));
						strcpy(dataForm.tab[i],formulaire->tabInpuText[i]->string);
					}	
					else {
						dataForm.tab[i]=NULL;
					}
					//~ printf("%p\n",dataForm->tab[i]);
				}		
			
				break;
			case 2:
				dataForm.nb = 3;
				dataForm.tab=malloc(sizeof(char*)*3);
				int k=0; // compteur pour le tableau de la structure
				for (int i=3;i<6;i++){
					if (formulaire->tabInpuText[i]->string != NULL){
						dataForm.tab[k]=malloc(sizeof(char)*strlen(formulaire->tabInpuText[i]->string));
						strcpy(dataForm.tab[k],formulaire->tabInpuText[i]->string);
					}else{
						dataForm.tab[k]=NULL;
					}
					k++;
					//~ printf("%p\n",dataForm->tab[i]);
				}
			
				break;
			case 1:
				dataForm.nb = 1;
				dataForm.tab=malloc(sizeof(char*)*1);
				int w=0; // compteur pour le tableau de la structure
				for (int i=6;i<7;i++){

					if (formulaire->tabInpuText[i]->string != NULL){
						dataForm.tab[w]=malloc(sizeof(char)*strlen(formulaire->tabInpuText[i]->string));
						strcpy(dataForm.tab[w],formulaire->tabInpuText[i]->string);
					}else{
						dataForm.tab[w]=NULL;
					}
					w++;
					//~ printf("%p\n",dataForm->tab[i]);
				}
				break;
			case 0:
				dataForm.nb = 1;
				dataForm.tab=malloc(sizeof(char*)*1);
				int v=0; // compteur pour le tableau de la structure
				for (int i=7;i<8;i++){

					if (formulaire->tabInpuText[i]->string != NULL){
					dataForm.tab[v]=malloc(sizeof(char)*strlen(formulaire->tabInpuText[i]->string));
					strcpy(dataForm.tab[v],formulaire->tabInpuText[i]->string);
					}	
					else {
					dataForm.tab[v]=NULL;
					}
					v++;
					//~ printf("%p\n",dataForm->tab[i]);
				}
				break;
		}
		
		afficheDataForm(dataForm);
		
		// Si le formulaire est validé : (appel fonction david)
		getPopulationFromModel(populationToDisplay, modelIA, dataForm.tab, dataForm.typeCheckBox, dataForm.nb);
}		

void saveDonneesFormUpdate(Form *formulaire, LIST **ptrHead, LIST *maillon, funcSublist *funcSL){
	const int nbImpoutTxt = formulaire->nbInpuText;
	const int nbImputBottum = formulaire->nbRadioButton;

	char **tab = NULL;
	int i = 0;
	int compteurTxt = 0;

	tab = (char**)malloc(sizeof(char*) * 12);
    

	while( i < 12 )
	{
		if( i == 0 || i == 3)
		{
			tab[i] = NULL;
			i++;
		}
		else 
		{
			if( formulaire->tabInpuText[compteurTxt]->string != NULL)
			{
				tab[i] = (char*)malloc(sizeof(char) * (strlen(formulaire->tabInpuText[compteurTxt]->string) + 1));
				strcpy(tab[i], formulaire->tabInpuText[compteurTxt]->string);
				i++;
				compteurTxt++;
			}
			else
			{
				tab[i] = NULL;
				i++;
			}
		}					
	}
	
	// Sale mais permet de remettre dans l'ordre les inputs
	char** tab2 = (char**)malloc(sizeof(char*) * 12);
	tab2[0] = NULL;
	tab2[1] = tab[2];
	tab2[2] = tab[1];
	tab2[3] = NULL;
	tab2[4] = tab[5];
	tab2[5] = tab[4];
	tab2[6] = tab[7];
	tab2[7] = tab[6];
	tab2[8] = tab[9];
	tab2[9] = tab[8];
	tab2[10] = tab[11];
	tab2[11] = tab[10];
	
	free(tab);
	
	LISTINDIVIDU_updateMaillon(ptrHead, maillon, funcSL, &tab2);
}

void saveDonneesFormSearch(Form *formulaire, LIST *ptrHead, funcSublist *funcSl){

	SUBLIST *searchSL = NULL;

	const int nbImpoutTxt = formulaire->nbInpuText;
	const int nbImputBottum = formulaire->nbRadioButton;

	char **tab = NULL;
	int i = 1;
	int compteurTxt = 0;

	tab = (char**)malloc(sizeof(char*) * (nbImpoutTxt + nbImputBottum));
    
	if(formulaire->tabInpuText[2]->string != NULL )
	{
		tab[0] = (char*)malloc(sizeof(char) * (strlen(formulaire->tabInpuText[2]->string) +1));
		strcpy(tab[0], formulaire->tabInpuText[2]->string);
	}
	else
	{
		tab[0] = NULL;
	}

	while( i < (nbImpoutTxt + nbImputBottum) )
	{
		if( i == 3)
		{
			switch( formulaire->tabRadioButton[0]->on)
			{
				case 0:
					tab[i] = (char*)malloc(sizeof(char) * (strlen("m") + 1));
					strcpy(tab[i], "m");
					break;
				case 1:
					tab[i] = (char*)malloc(sizeof(char) * (strlen("f") + 1));
					strcpy(tab[i], "f");
					break;
				default:
					tab[i] = NULL;
			}
			i++;
		}
		else
		{	
			if( compteurTxt == 2)
			{
			}
			else if( formulaire->tabInpuText[compteurTxt]->string != NULL)
			{
				tab[i] = (char*)malloc(sizeof(char) * (strlen(formulaire->tabInpuText[compteurTxt]->string) + 1));
				strcpy(tab[i], formulaire->tabInpuText[compteurTxt]->string);
				i++;
			}
			else
			{
				tab[i] = NULL;
				i++;
			}	
			compteurTxt++;				
		}		
	}

	/* 
		Recupere une subList de resultat de recherche
		Elle peut etre NULL s'il y a rien
	 */
	searchSL = SEARCHENGINE_searchIndividu(&tab, ptrHead, funcSl);
}	

void saveDonneesFormAdd(Form *formulaire, LIST **ptrHead, funcList *func)
{
	const int nbImpoutTxt = formulaire->nbInpuText;
	const int nbImputBottum = formulaire->nbRadioButton;

	char **tab = NULL;
	int i = 1;
	int compteurTxt = 0;

	tab = (char**)malloc(sizeof(char*) * (nbImpoutTxt + nbImputBottum));
    
	if(formulaire->tabInpuText[2]->string != NULL )
	{
		tab[0] = (char*)malloc(sizeof(char) * (strlen(formulaire->tabInpuText[2]->string) +1));
		strcpy(tab[0], formulaire->tabInpuText[2]->string);
	}
	else
	{
		tab[0] = NULL;
	}
	
	while( i < (nbImpoutTxt + nbImputBottum) )
	{
		if( i == 3)
		{
			switch( formulaire->tabRadioButton[0]->on)
			{
				case 0:
					tab[i] = (char*)malloc(sizeof(char) * (strlen("m") + 1));
					strcpy(tab[i], "m");
					break;
				case 1:
					tab[i] = (char*)malloc(sizeof(char) * (strlen("f") + 1));
					strcpy(tab[i], "f");
					break;
				default:
					tab[i] = NULL;
			}
			i++;
		}
		else
		{	
			if( compteurTxt == 2)
			{
			}
			else if( formulaire->tabInpuText[compteurTxt]->string != NULL)
			{
				tab[i] = (char*)malloc(sizeof(char) * (strlen(formulaire->tabInpuText[compteurTxt]->string) + 1));
				strcpy(tab[i], formulaire->tabInpuText[compteurTxt]->string);
				i++;
			}
			else
			{
				tab[i] = NULL;
				i++;
			}	
			compteurTxt++;				
		}		
	}
	addIndividuListIndividu(&tab, ptrHead, func);
}	

void gereSourisBoutonValideCarte(Form *formulaire, Population** populationToDisplay, Model* modelIA, int xSouris, int ySouris){
		if(xSouris > 500 && xSouris < 600 && ySouris > 0 && ySouris < 100){

			saveDonneesFormCarte(formulaire, populationToDisplay, modelIA); 
			//refree
		}
}

void gereSourisBoutonValideUpdate(Form *formulaire, int xSouris, int ySouris, LIST **ptrHead, NoeudASC *courantASC, NoeudDESC *courantDESC, funcSublist *funcsL,
NoeudASC** rootASC, NoeudData** treeASC, NoeudDESC** rootDESC, NoeudData** treeDESC)
{
		if(xSouris > 500 && xSouris < 600 && ySouris > 0 && ySouris < 100){
			if (courantASC != NULL)
			{
				LIST *maillon = courantASC->ptrIndividu;
				saveDonneesFormUpdate(formulaire, ptrHead, maillon, funcsL); 
			}
			if (courantDESC != NULL)
			{
				LIST *maillon = courantDESC->ptrIndividu;
				saveDonneesFormUpdate(formulaire, ptrHead, maillon, funcsL);
			}
				// On regenere l'arbre ASC
					NOEUDDATA_createStructure(treeASC, *ptrHead);
					    
					*rootASC = TREEASC_createTree(*ptrHead, treeASC);
					
				// On regenere l'arbre DESC
					LIST *tmp = *ptrHead;
					LIST *verif = NULL;
					while(tmp != NULL)
					{
						verif =tmp;
						tmp = tmp->u.list_individu->suivant;
					}
					/*
						l'initialisation de la structure NoeudData se fait en fonction de l'individu à
						partir duqeul on a choisi
					*/
					NOEUDDATA_createStructure(treeDESC, verif);
					
					*rootDESC = TREEDESC_initialize(verif, treeDESC);
					TREEDESC_initializeNoeudData(verif, treeDESC, *rootDESC);
				
		}
}

void gereSourisBoutonValideSearch(Form *formulaire, int xSouris, int ySouris, LIST *ptrHead, funcSublist *funcSL){
		if(xSouris > 500 && xSouris < 600 && ySouris > 0 && ySouris < 100){
				saveDonneesFormSearch(formulaire, ptrHead, funcSL); 
		}
}

void gereSourisBoutonValideAdd(Form *formulaire, LIST **ptrHead, funcList *func, int xSouris, int ySouris,
NoeudASC** rootASC, NoeudData** treeASC, NoeudDESC** rootDESC, NoeudData** treeDESC){
		if(xSouris > 500 && xSouris < 600 && ySouris > 0 && ySouris < 100){
				saveDonneesFormAdd(formulaire, ptrHead, func); 
				
				// On regenere l'arbre ASC
					NOEUDDATA_createStructure(treeASC, *ptrHead);
					    
					*rootASC = TREEASC_createTree(*ptrHead, treeASC);
					
				// On regenere l'arbre DESC
					LIST *tmp = *ptrHead;
					LIST *verif = NULL;
					while(tmp != NULL)
					{
						verif =tmp;
						tmp = tmp->u.list_individu->suivant;
					}
					/*
						l'initialisation de la structure NoeudData se fait en fonction de l'individu à
						partir duqeul on a choisi
					*/
					NOEUDDATA_createStructure(treeDESC, verif);
					
					*rootDESC = TREEDESC_initialize(verif, treeDESC);
					TREEDESC_initializeNoeudData(verif, treeDESC, *rootDESC);
		}
}

void afficheDataForm(DataFormulaire dataForm){
	printf("Nombre d'inputs : '%d'\n", dataForm.nb);
	printf("Valeur checkbox : '%d'\n", dataForm.typeCheckBox);
	
	if(dataForm.nb != 0){
		printf("Tableau : \n");
		for(int i=0;i<dataForm.nb;i++){
			printf("%d : '%s'\n",i, dataForm.tab[i]);
		}
	}
}

void freeDataForm(DataFormulaire* dataForm){
	dataForm->nb = -1;
	dataForm->typeCheckBox = -1;
	
	if(dataForm->tab != NULL){
		free(dataForm->tab);
		dataForm->tab = NULL;
	}
}

/**
 * Fonction ayant pour but de quitter propremment le programme : libère toutes les images et termine la boucle evenements
 * @author Yann LEFEVRE
 * */
void exitProgram(DonneesImageRGB** navbarre, DonneesImageRGB** fondaccueil, DonneesImageRGB** enteteFondExplorateur, DonneesImageRGB** fondExplorateur, DonneesImageRGB** map, 
DonneesImageRGB** infos_individu_homme, DonneesImageRGB** infos_individu_femme, DonneesImageRGB** infos_individu_null, DonneesImageRGB** user, DonneesImageRGB** help,
DonneesImageRGB** insertion_individu, message** messages, int nbMessage, dataFile* fileM, LIST** head_mariage, funcList** func, funcSublist** funcSL, LIST** head_individu, dataFile* fileI,
NoeudASC **courantASC, NoeudDESC **courantDESC, Form* formInsereIndividu, Form* formUpdateIndividu, Form* formChercheIndividu){
	if(!keys.key_esc){// si echape est appué -> on ferme le programme en libérant la navbarre
		
// Libération de l'IHM
	// Images
		libereDonneesImageRGB(navbarre);
		libereDonneesImageRGB(fondaccueil);
		libereDonneesImageRGB(enteteFondExplorateur);
		libereDonneesImageRGB(fondExplorateur); 
		libereDonneesImageRGB(map);
		libereDonneesImageRGB(infos_individu_homme);
		libereDonneesImageRGB(infos_individu_femme);
		libereDonneesImageRGB(infos_individu_null);
		libereDonneesImageRGB(user);
		libereDonneesImageRGB(help);
		libereDonneesImageRGB(insertion_individu);
		
	// Messages assistant
		if(messages != NULL){
			for(int i=0;i<nbMessage;i++){
				if(messages[i] != NULL){
					free(messages[i]);
					messages[i] = NULL;
				}
			}
			free(messages);
			messages = NULL;
		}
		
	// Inputs non vidés
		freeForm(formInsereIndividu);
		freeForm(formUpdateIndividu);
		freeForm(formChercheIndividu);
		
	
		
// Libération des listes

	if(*head_individu != NULL && *head_mariage != NULL){
		if(fileM != NULL && head_mariage != NULL){
			deleteList(fileM, head_mariage, *func, *funcSL);
		}
		
		if(fileI != NULL && head_individu != NULL){
			deleteList(fileI, head_individu, *func, *funcSL);
		}

		if(func != NULL){
			LIST_freePointeurFonction(func);
		}
		
		if(funcSL != NULL){
			SUBLIST_freePointeurFunction(funcSL);
		}
		
		*courantASC = NULL;
		*courantDESC = NULL;
	}
		
		termineBoucleEvenements();
		}
}
