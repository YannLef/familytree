#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "../../include/LIST/structure.h"
#include "../../include/LIST/list/list.h"
#include "../../include/LIST/sublist/sublist.h"

#include "../../include/IHM/structures.h"
#include "../../include/TREE/structure.h"

#include "../../include/LIST/dataTree/dataTree.h"

#include "../../include/LIST/listGeneration/individu/generateI.h"
#include "../../include/LIST/listGeneration/mariage/generateM.h"
#include "../../include/LIST/listGeneration/methode/listSave.h"
#include "../../include/LIST/list/individu/methode/toolI.h"
#include "../../include/LIST/list/mariage/methode/toolM.h"
#include "../../include/LIST/list/individu/methode/displayTerminalI.h"
#include "../../include/LIST/list/mariage/methode/displayTerminalM.h"

#include "../../include/TREE/generationTree/treeASC/treeASC.h"
#include "../../include/TREE/generationTree/treeDESC/treeDESC.h"

#include "../../include/LIST/listGeneration/methode/deleteL.h"

int main(void)
{
    int a;
    LIST *head_individu = NULL;
    LIST *head_mariage = NULL;
    char *fileNameI = "../../../assets/csv/family#1/individu.csv";
    char *fileNameM = "../../../assets/csv/family#1/mariage.csv";
    funcList *func = NULL;
    funcSublist *funcSL = NULL;
   
    dataFile *fileI = NULL;
    dataFile *fileM = NULL;
    
    fileI = DATAFILE_create();
    fileM = DATAFILE_create();
    fileI->fileName = fileNameI;
    fileM->fileName = fileNameM;

    LIST_pointeurFunction(&func);

    SUBLIST_pointeurFunction(&funcSL);

    //printf("[GENERATION LIST INDIVIDU]\n");
    LISTINDIVIDU_generationListe(&head_individu, &fileI, type_listIndividu, func);
    //printf("[GENERATION LIST MARIAGE]\n");
    LISTMARIAGE_generationListe(&fileM, &head_mariage, &head_individu, type_listMariage, func);

    fileI->nb_row = LISTINDIVIDU_compteNbMaillon(head_individu);
    fileM->nb_row = LISTMARIAGE_compteNbMaillon(head_mariage);

    displayListIndividu(head_individu);
    displayListMariage(head_mariage);
    
    NoeudASC *rootASC = NULL;

    rootASC = TREEASC_createTree(head_individu);

    printf("GENERATION TREE\n");
    TREEASC_display(rootASC);
    printf("DELETE TREE\n");
    TREEASC_deletetree(rootASC);

    printf("GENERATION TREE\n");
    NoeudDESC *rootDESC = NULL;

    LIST *tmp = head_individu;
    LIST *verif = NULL;
    while(tmp != NULL)
    {
        verif =tmp;
        tmp = tmp->u.list_individu->suivant;
    }
    
    rootDESC = TREEDESC_initialize(verif);

    displayTreeDESCNode(rootDESC);

    saveListInCSV(fileM, &head_mariage, func);
    saveListInCSV(fileI, &head_individu, func);

    //printf("[FREE LIST MARIAGE]\n");
    deleteList(fileM, &head_mariage, func, funcSL);
    //printf("[FREE LIST INDIVIDU]\n");
    deleteList(fileI, &head_individu, func, funcSL);

    printf("HEAD INDIVIDU -> %p\n", head_individu);
    printf("HEAD Mariage -> %p\n", head_mariage);

    return 0;
}