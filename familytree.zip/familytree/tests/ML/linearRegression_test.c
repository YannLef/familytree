#include <stdio.h>
#include <stdlib.h>

#include "../minunit/minunit.h"
#include "../../include/LIST/structure.h"
#include "../../include/ML/tools/linearRegression.h"

#define NB_POINTS 4
#define POLYNOME_DEGRE 2

/* DEFINE YOUR STATIC VARIABLE HERE */

static PointsCloud pc, pc2;
static LinearRegression lr;
static Polynome p;

/* END OF DECLARATION FOR THE STATIC VARIABLES */

void pointsCloud_setup(void)
{
    newPointsCloud(&pc, NB_POINTS);

    pc.x[0] = 4.13;
    pc.x[1] = 5.12;
    pc.x[2] = 12.3;
    pc.x[3] = 16.245;

    pc.y[0] = 2.19;
    pc.y[1] = 3.78;
    pc.y[2] = 1.34;
    pc.y[3] = 6.7;
}

void pointsCloud_teardown(void)
{
    clearPointsCloud(&pc);
    system("rm -f log.txt");
}

void polynome_setup(void)
{
    newPolynome(&p, POLYNOME_DEGRE);
}

void polynome_teardown(void)
{
    clearPolynome(&p);
    system("rm -f log.txt");
}

void linearRegression_setup(void)
{
    newPointsCloud(&pc, NB_POINTS);

    pc.x[0] = 4.13;
    pc.x[1] = 5.12;
    pc.x[2] = 12.3;
    pc.x[3] = 16.245;

    pc.y[0] = 2.19;
    pc.y[1] = 3.78;
    pc.y[2] = 1.34;
    pc.y[3] = 6.7;
    
    newLinearRegression(&lr, &pc);
}

void linearRegression_teardown(void)
{
    clearLinearRegression(&lr);
    clearPointsCloud(&pc);
    system("rm -f log.txt");
}

MU_TEST(shouldCreateANewPointsOfCloud)
{
    mu_check(pc.x != NULL);
    mu_check(pc.y != NULL);
}

MU_TEST(shouldClearAPointsOfCloud)
{
    clearPointsCloud(&pc);
    mu_check(pc.x == NULL);
    mu_check(pc.y == NULL);
}

MU_TEST(shouldSaveAPointsOfCloud)
{
    int nb; 
    double x,y;
    
    savePointsCloud(&pc,"log.txt");

    FILE *f = fopen("log.txt", "r");
    if (f == NULL)
    {
        printf("error : file could not be open !");
        return;
    }
    fscanf(f, "%d\n", &nb);
    mu_assert_int_eq(nb, pc.nb);
    for(int i = 0; i < pc.nb ; i++ ){
        fscanf(f, "{x: %lf, y: %lf }\n", &x, &y);
        mu_assert_double_eq(x, pc.x[i]);
        mu_assert_double_eq(y, pc.y[i]);
    }
    fclose(f);

}

MU_TEST(shouldReadAPointsOfCloud)
{   
    savePointsCloud(&pc,"log.txt");
    readPointsCloud(&pc2,"log.txt");
    
    mu_assert_int_eq(pc.nb, pc2.nb);
    if( pc.nb == pc2.nb ){
        for(int i = 0; i < pc.nb ; i++ ){
            mu_assert_double_eq(pc.x[i], pc2.x[i]);
            mu_assert_double_eq(pc.y[i], pc2.y[i]);
        }
    }
    else
    {
        mu_fail("saved value differend from readed value for nb");
    }
}

MU_TEST(shouldCopyAPointsOfCloudAtoB)
{
    copyPointsCloudAtoB(&pc, &pc2);
    mu_assert_int_eq(pc.nb,pc2.nb);
    if (pc.nb == pc2.nb)
    {
        for (int i = 0; i < pc.nb; i++)
        {
            mu_assert_double_eq(pc.x[i], pc2.x[i]);
            mu_assert_double_eq(pc.y[i], pc2.y[i]);
        }
    }
    else
    {
        mu_fail("number of points different");
    }
}

MU_TEST(shouldAValueToAPointsOfCloud)
{
    double lastNb = pc.nb;
    
    addValueToPointsCloud(&pc, 3.14, 2.32);

    mu_assert_int_eq(lastNb+1, pc.nb);
    mu_assert_int_eq(3.14, pc.x[pc.nb-1]);
    mu_assert_int_eq(2.32, pc.y[pc.nb-1]);
}

MU_TEST_SUITE(PointsCloudTestSuite)
{
    MU_SUITE_CONFIGURE(&pointsCloud_setup, &pointsCloud_teardown);

    MU_RUN_TEST(shouldCreateANewPointsOfCloud);
    MU_RUN_TEST(shouldClearAPointsOfCloud);
    MU_RUN_TEST(shouldSaveAPointsOfCloud);
    MU_RUN_TEST(shouldReadAPointsOfCloud);
    MU_RUN_TEST(shouldCopyAPointsOfCloudAtoB);
    MU_RUN_TEST(shouldAValueToAPointsOfCloud);
}

MU_TEST(shouldCreateANewPolynome)
{
    mu_assert_int_eq(POLYNOME_DEGRE, p.degre);
    mu_check(p.tabCoeff != NULL);
}


MU_TEST(shouldClearAPolynome)
{
    clearPolynome(&p);
    mu_check(p.tabCoeff == NULL);
}

MU_TEST(shouldAddACoefficientToAPolynome)
{
    addCoeff(&p, 2.567);
    mu_assert_double_eq(POLYNOME_DEGRE+1, p.degre);
    mu_assert_double_eq(2.567, p.tabCoeff[POLYNOME_DEGRE]);
}

MU_TEST_SUITE(PolynomeTestSuite)
{
    MU_SUITE_CONFIGURE(&polynome_setup, &polynome_teardown);

    MU_RUN_TEST(shouldCreateANewPolynome);
    MU_RUN_TEST(shouldClearAPolynome);
    MU_RUN_TEST(shouldAddACoefficientToAPolynome);
}

MU_TEST(shouldComputeANewLinearRegression)
{
    mu_assert_int_eq(POLYNOME_DEGRE, lr.ideal.degre);
    mu_check(lr.ideal.tabCoeff != NULL);

    mu_assert_double_eq(0.210613647048, lr.ideal.tabCoeff[0]);
    mu_assert_double_eq(1.512464302455, lr.ideal.tabCoeff[1]);

    mu_assert_double_eq(0.269190967083, lr.r);
}

MU_TEST(shouldClearALinearRegression)
{
    clearLinearRegression(&lr);
    //mu_check(lr.ideal == NULL);
    mu_check(lr.r == 0);
}

MU_TEST(shouldComputeASumOfDouble)
{
    double sum = 0;
    computeSumOfDouble(&sum, &(pc.x), &(pc.nb));
    mu_assert_double_eq(37.795, sum);
}

MU_TEST(shouldComputeASumOfDoubleOfTwoTableMultiplied)
{
    double sum = 0;
    computeSumOfDoubleOfXY(&sum, &(pc.x), &(pc.y), &(pc.nb));
    mu_assert_double_eq(153.7218, sum);
}

MU_TEST(shouldCreateAcomputeIdealPolynome)
{
    computeIdealPolynome(&lr, &pc);
    
    mu_check(lr.ideal.tabCoeff != NULL);
    mu_assert_double_eq(0.210613647048, lr.ideal.tabCoeff[0]);
    mu_assert_double_eq(1.512464302455, lr.ideal.tabCoeff[1]);
}

MU_TEST_SUITE(LinearRegressionTestSuite)
{
    MU_SUITE_CONFIGURE(&linearRegression_setup, &linearRegression_teardown);
    
    MU_RUN_TEST(shouldClearALinearRegression);
    MU_RUN_TEST(shouldComputeASumOfDouble);
    MU_RUN_TEST(shouldComputeASumOfDoubleOfTwoTableMultiplied);

    MU_RUN_TEST(shouldCreateAcomputeIdealPolynome);
    MU_RUN_TEST(shouldComputeANewLinearRegression);
}

int main(void)
{
    MU_RUN_SUITE(PointsCloudTestSuite);
    MU_RUN_SUITE(PolynomeTestSuite);
    MU_RUN_SUITE(LinearRegressionTestSuite);

    MU_REPORT();

    return 0;
}
