#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../../include/LIST/structure.h"
#include "../../../include/ML/tools/strsplit.h"
#include "../../../include/ML/ML.h"

int main(int argc, char* argv[]) {
    searchRequestData* data = NULL;
    data = malloc(sizeof *data);
    displayBotMessageFromQueryInTerminal("!search", &data);
    free(data);
    return 0;
}