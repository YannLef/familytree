#include <stdlib.h> 
#include <stdio.h> 
#include <math.h> 
#include <string.h>
#include "../../../GFX/GfxLib.h" 
#include "../../../GFX/BmpLib.h"

#include <unistd.h>

#include "../../../include/LIST/structure.h"
#include "../../../include/LIST/list/list.h"
#include "../../../include/LIST/sublist/sublist.h"

#include "../../../include/IHM/structures.h"

#include "../../../include/LIST/dataTree/dataTree.h"

#include "../../../include/LIST/listGeneration/individu/generateI.h"
#include "../../../include/LIST/listGeneration/mariage/generateM.h"
#include "../../../include/LIST/listGeneration/methode/listSave.h"
#include "../../../include/LIST/list/individu/methode/toolI.h"
#include "../../../include/LIST/list/mariage/methode/toolM.h"
#include "../../../include/LIST/list/individu/methode/displayTerminalI.h"
#include "../../../include/LIST/list/mariage/methode/displayTerminalM.h"

#include "../../../include/LIST/listGeneration/methode/deleteL.h"

//ML
#include "../../../include/LIST/structure.h"
#include "../../../include/ML/ML.h"

// Largeur et hauteur par defaut d'une image correspondant a nos criteres
#define LargeurFenetre 1600
#define HauteurFenetre 800

/* La fonction de gestion des evenements, appelee automatiquement par le systeme
des qu'une evenement survient */
void gestionEvenement(EvenementGfx evenement);

int main(int argc, char **argv)
{
	initialiseGfx(argc, argv);
	
	prepareFenetreGraphique("FAMILY TREE", LargeurFenetre, HauteurFenetre);
	
	/* Lance la boucle qui aiguille les evenements sur la fonction gestionEvenement ci-apres,
		qui elle-meme utilise fonctionAffichage ci-dessous */
	lanceBoucleEvenements();
	
	return 0;
}

/* La fonction de gestion des evenements, appelee automatiquement par le systeme
des qu'une evenement survient */
void gestionEvenement(EvenementGfx evenement)
{
	static bool pleinEcran = false; // Pour savoir si on est en mode plein ecran ou pas
	static int tempo = 20;
	static DonneesImageRGB *map = NULL; // L'image pour la catégorie naissance de la description d'un individu -> la carte de david fait 800*800 et est affichée au milieu de l'image de 980*800

	static LIST *head_individu = NULL;
    static LIST *head_mariage = NULL;
    static char *fileNameI = "../../../../assets/csv/family#3/individu.csv";
    static char *fileNameM = "../../../../assets/csv/family#3/mariage.csv";
    static funcList *func = NULL;
    static funcSublist *funcSL = NULL;
   
    static dataFile *fileI = NULL;
    static dataFile *fileM = NULL;

	static Model *m = NULL;
	static char* form[3] = {"lambert"};
	static Population *populationToDisplay = NULL;

	switch (evenement)
	{
		case Initialisation:

			map = lisBMPRGB("../../../../assets/map/france.bmp");

			fileI = DATAFILE_create();
			fileM = DATAFILE_create();
			fileI->fileName = fileNameI;
			fileM->fileName = fileNameM;

			LIST_pointeurFunction(&func);

			SUBLIST_pointeurFunction(&funcSL);

			//printf("[GENERATION LIST INDIVIDU]\n");
			LISTINDIVIDU_generationListe(&head_individu, &fileI, type_listIndividu, func);
			//printf("[GENERATION LIST MARIAGE]\n");
			LISTMARIAGE_generationListe(&fileM, &head_mariage, &head_individu, type_listMariage, func);

			fileI->nb_row = LISTINDIVIDU_compteNbMaillon(head_individu);
			fileM->nb_row = LISTMARIAGE_compteNbMaillon(head_mariage);

			// Avant : Model *m = NULL;
			m = NULL; //apres
			initModel(&m, NB_PTR_FUNC_POPULATION_FROM);
			createModel(m, head_individu);
			//printf("%d \n", atoi(form[2]));
			//displayModel(m);
			demandeTemporisation(tempo);
			break;
		
		case Temporisation:
			
			rafraichisFenetre();
			break;
			
		case Affichage:	
			effaceFenetre(200, 255, 255);
			ecrisImage(620, 0, map->largeurImage, map->hauteurImage, map->donneesRGB);
			couleurCourante(0, 0, 0);
			ligne(620 + (map->largeurImage - map->hauteurImage)/2, 0, 620 + (map->largeurImage - map->hauteurImage)/2, map->hauteurImage);
			ligne(620 + (map->largeurImage - map->hauteurImage)/2 + map->hauteurImage, 0, 620 + (map->largeurImage - map->hauteurImage)/2 + map->hauteurImage, map->hauteurImage);
			if (populationToDisplay != NULL) {
				//slider value to insert in the parameters for minimum data and maximum date
				//BIRTH : slider in the bottom give the type of population
				//the Population to display has been searched when cliked on ok
				displayPopulationOnMap(populationToDisplay, BIRTH, 1400, 2000);
			}
			epaisseurDeTrait(1);
			couleurCourante(255,0,0);
			point(1362, 148);
			break;
			
		case Clavier:
			printf("%c : ASCII %d\n", caractereClavier(), caractereClavier());

			switch (caractereClavier())
			{
				case 'Q': 
				case 'q':
					freeModel(&m);
					deleteList(fileM, &head_mariage, func, funcSL);
					//printf("[FREE LIST INDIVIDU]\n");
					deleteList(fileI, &head_individu, func, funcSL);

					LIST_freePointeurFonction(&func);
					SUBLIST_freePointeurFunction(&funcSL);

					libereDonneesImageRGB(&map);

					termineBoucleEvenements();
					break;

				case 'F':
				case 'f':
					pleinEcran = !pleinEcran; 
					if (pleinEcran)
						modePleinEcran();
					else
						redimensionneFenetre(LargeurFenetre, HauteurFenetre);
					break;

				case 'L':
				case 'l':
					//TODO refactor the 3 pramters in this function with the according structure
					//form => DataForm.tab, GENERATION => DataForm.type, 1 => DataForm.nb
					getPopulationFromModel(&populationToDisplay, m, form, FAMILY, 1);
					displayPopulation(populationToDisplay);
					break;

				case 'S':
				case 's':
					// Configure le systeme pour ne plus generer de message Temporisation
					demandeTemporisation(-1);
					break;
				case 'r': 
					break;
				case 't':
					break;
				
			}
			break;
			
		case ClavierSpecial:
			printf("ASCII %d\n", toucheClavier());
			break;

		case BoutonSouris:
			if (etatBoutonSouris() == GaucheRelache)
			{
				printf("Bouton gauche relache en : (%d, %d)\n", abscisseSouris(), ordonneeSouris());
				
			}
			break;
		
		case Souris: // Si la souris est deplacee
			
			break;
		
		case Inactivite: // Quand aucun message n'est disponible
			break;
		
		case Redimensionnement: // La taille de la fenetre a ete modifie ou on est passe en plein ecran
			// Donc le systeme nous en informe
			break;
	}
}
