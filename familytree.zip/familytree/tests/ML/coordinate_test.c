#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../include/ML/model/Coordinate.h"

int main(void) {
    Coordinate *c1, *c2;
    newCoordinate(&c1, 23.345, 345.27);
    printCoordinate(c1);
    newCoordinateFromCityName(&c2,"MarseillE", "../../../assets/db/villes.db");
    printCoordinate(c2);
    freeCoordinate(&c1);
    freeCoordinate(&c2);
    return 0;
}