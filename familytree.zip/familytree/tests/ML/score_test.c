#include <stdio.h>
#include <stdlib.h>

#include "../../include/ML/tools/average.h"
#include "../../include/ML/model/Score.h"

int main(void) {
    Score *s = NULL;

    newScore(&s);

    Average a;
    newAverage(&a);
    addDataToAverage(&a, 12);
    addDataToAverage(&a, 14);
    computeAverage(&a);
    computeStandardErrorOfAverage(&a);

    addAverageToScore(s, &a);
    addAverageToScore(s, &a);

    newAverageInScore(s);
    computeScoreGlobalStandardError(s);

    printScore(s);
    clearScore(&s);
    return 0;
}