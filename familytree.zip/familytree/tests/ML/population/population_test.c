#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "../../../include/LIST/structure.h"
#include "../../../include/LIST/list/list.h"
#include "../../../include/LIST/sublist/sublist.h"

#include "../../../include/IHM/structures.h"

#include "../../../include/LIST/dataTree/dataTree.h"

#include "../../../include/LIST/listGeneration/individu/generateI.h"
#include "../../../include/LIST/listGeneration/mariage/generateM.h"
#include "../../../include/LIST/listGeneration/methode/listSave.h"
#include "../../../include/LIST/list/individu/methode/toolI.h"
#include "../../../include/LIST/list/mariage/methode/toolM.h"
#include "../../../include/LIST/list/individu/methode/displayTerminalI.h"
#include "../../../include/LIST/list/mariage/methode/displayTerminalM.h"

#include "../../../include/LIST/listGeneration/methode/deleteL.h"

//ML
#include "../../../include/LIST/structure.h"
#include "../../../include/ML/list/event/Event.h"
#include "../../../include/ML/tools/average.h"
#include "../../../include/ML/model/Score.h"
#include "../../../include/ML/model/Coordinate.h"
#include "../../../include/ML/list/place/Place.h"
#include "../../../include/ML/model/Population.h"

int main(void)
{
    LIST *head_individu = NULL;
    LIST *head_mariage = NULL;
    char *fileNameI = "../../../../assets/csv/family#1/individu.csv";
    char *fileNameM = "../../../../assets/csv/family#1/mariage.csv";
    funcList *func = NULL;
    funcSublist *funcSL = NULL;
   
    dataFile *fileI = NULL;
    dataFile *fileM = NULL;
 
    fileI = DATAFILE_create();
    fileM = DATAFILE_create();
    fileI->fileName = fileNameI;
    fileM->fileName = fileNameM;

    LIST_pointeurFunction(&func);

    SUBLIST_pointeurFunction(&funcSL);

    //printf("[GENERATION LIST INDIVIDU]\n");
    LISTINDIVIDU_generationListe(&head_individu, &fileI, type_listIndividu, func);
    //printf("[GENERATION LIST MARIAGE]\n");
    LISTMARIAGE_generationListe(&fileM, &head_mariage, &head_individu, type_listMariage, func);

    fileI->nb_row = LISTINDIVIDU_compteNbMaillon(head_individu);
    fileM->nb_row = LISTMARIAGE_compteNbMaillon(head_mariage);

    //displayListIndividu(head_individu);
    LIST *tmp = head_individu;
    int i = 0;
    while(tmp != NULL) {
        Population *p = NULL;
        //newPopulationFromGeneration(&p, tmp);
        newPopulationFromFamily(&p, tmp);
        //newPopulationFromIasc(&p, tmp);
        //newPopulationFromIdesc(&p, tmp);
        computeGlobalPopulationScore(p);
        displayPopulation(p);
        freePopulation(&p);
        i++;
        tmp = tmp->u.list_individu->suivant;
    }
    printf("%d \n", i);
    //newPopulationFromListNode(&p, I_ASC, head_individu);
    //newPopulationFromListNode(&p, FAMILY, head_individu);
    //newPopulationFromListNode(&p, GENERATION, head_individu);
    //displayListMariage(head_mariage);
    //printf("[FREE LIST MARIAGE]\n");
    deleteList(fileM, &head_mariage, func, funcSL);
    //printf("[FREE LIST INDIVIDU]\n");
    deleteList(fileI, &head_individu, func, funcSL);

    LIST_freePointeurFonction(&func);
    SUBLIST_freePointeurFunction(&funcSL);


    return 0;
}