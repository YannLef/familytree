#include <stdio.h>
#include <stdlib.h>

#include "../minunit/minunit.h"
#include "../../include/LIST/structure.h"
#include "../../include/ML/tools/average.h"

#define N 3
#define NUMBER_OF_DATA 6

/* DEFINE YOUR STATIC VARIABLE HERE */

//an average to test
static Average *a1;
static float dataSet[NUMBER_OF_DATA];

/* END OF DECLARATION FOR THE STATIC VARIABLES */

void test_setup(void)
{
    a1 = malloc(sizeof *a1);
    if (a1 != NULL)
    {
        dataSet[0] = 23.34;
        dataSet[1] = 35.67;
        dataSet[2] = 12.897;
        dataSet[3] = 123.456;
        dataSet[4] = 345.45;
        dataSet[5] = 7.2;
    }
    else
    {
        mu_fail("error allcoation in setup");
    }
}

void test_teardown(void)
{
    free(a1);
    a1 = NULL;
}

MU_TEST(shouldInitializeAnAverageTo0)
{
    newAverage(a1);
    mu_check(a1->arrayOfData == NULL);
    mu_assert_double_eq(a1->averageValue, 0.0);
    mu_assert_int_eq(a1->numberOfData, 0);
    mu_assert_double_eq(0.0, a1->standardError);
}

MU_TEST(shouldAddADataToTheAverageDataArray)
{
    float data = 34.234;
    newAverage(a1);
    addDataToAverage(a1, data);
    mu_check(a1->arrayOfData != NULL);
    mu_assert_double_eq(a1->averageValue, 0.0);
    mu_assert_int_eq(a1->numberOfData, 1);
    mu_assert_double_eq(a1->standardError, 0.0);
    mu_assert_double_eq(data, (a1->arrayOfData[0]));
}

MU_TEST(shouldComputeAnAverage)
{
    newAverage(a1);
    addDataToAverage(a1, (dataSet[0]));
    addDataToAverage(a1, (dataSet[1]));
    addDataToAverage(a1, (dataSet[2]));
    addDataToAverage(a1, (dataSet[3]));
    addDataToAverage(a1, (dataSet[4]));
    addDataToAverage(a1, (dataSet[5]));
    computeAverage(a1);
    mu_assert_double_eq(91.33550262451f, a1->averageValue);
}

MU_TEST(shouldComputeStandardErrorOfAnAverage)
{
    newAverage(a1);
    addDataToAverage(a1, (dataSet[0]));
    addDataToAverage(a1, (dataSet[1]));
    addDataToAverage(a1, (dataSet[2]));
    addDataToAverage(a1, (dataSet[3]));
    addDataToAverage(a1, (dataSet[4]));
    addDataToAverage(a1, (dataSet[5]));
    computeAverage(a1);
    computeStandardErrorOfAverage(a1);
    /**
     * More info :
     * 
     * https://bit.ly/30jMX0D
     * 
     * exact value : 120.11058944677
     * 
     */
    mu_assert_double_eq(120.11058944677f, a1->standardError);
}

MU_TEST(shouldClearAllDataOfAverage)
{
    clearAllDataOfAverage(a1);
    mu_check(a1->arrayOfData == NULL);
    mu_assert_double_eq(0.0, a1->averageValue);
    mu_assert_int_eq(a1->numberOfData, 0);
    mu_assert_double_eq(0.0, a1->standardError);
}

MU_TEST(shouldSaveTheAverageToALogTextFile)
{
    newAverage(a1);
    addDataToAverage(a1, (dataSet[0]));
    addDataToAverage(a1, (dataSet[1]));
    addDataToAverage(a1, (dataSet[2]));
    addDataToAverage(a1, (dataSet[3]));
    addDataToAverage(a1, (dataSet[4]));
    addDataToAverage(a1, (dataSet[5]));
    computeAverage(a1);
    computeStandardErrorOfAverage(a1);
    saveAverageToTextFile(a1, "log.txt");
}

MU_TEST(shouldReadAnAverageFromALogTextFile)
{
    
    Average *a2 = malloc(sizeof *a2);
    
    if (a2 != NULL)
    {
        newAverage(a2);
        readAverageFromTextFile(a2, "log.txt");
        mu_assert_int_eq(NUMBER_OF_DATA, a2->numberOfData);
        mu_assert_double_eq(91.3355f, a2->averageValue);
        mu_assert_double_eq(120.11058944677f, a2->standardError);
        clearAllDataOfAverage(a2);
    }
    else
    {
        mu_fail("error allocation a2");
    }
    
    free(a2);
    a2 = NULL;

    system("rm -f *.txt");
    
}

MU_TEST_SUITE(averageTestSuite)
{
    MU_SUITE_CONFIGURE(&test_setup, &test_teardown);

    MU_RUN_TEST(shouldInitializeAnAverageTo0);
    MU_RUN_TEST(shouldAddADataToTheAverageDataArray);
    MU_RUN_TEST(shouldComputeAnAverage);
    MU_RUN_TEST(shouldComputeStandardErrorOfAnAverage);
    MU_RUN_TEST(shouldClearAllDataOfAverage);
    MU_RUN_TEST(shouldSaveTheAverageToALogTextFile);
    MU_RUN_TEST(shouldReadAnAverageFromALogTextFile);

    //system("rm -f *.txt");
}

int main(void)
{
    MU_RUN_SUITE(averageTestSuite);
    MU_REPORT();

    return 0;
}
