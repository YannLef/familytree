#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../include/LIST/structure.h"
#include "../../include/ML/list/event/Event.h"
#include "../../include/ML/tools/average.h"
#include "../../include/ML/model/Score.h"
#include "../../include/ML/model/Coordinate.h"
#include "../../include/ML/list/place/Place.h"

int main(void) {
    Place *list = NULL;
    insertPlace(&list, "Toulon");
    insertPlace(&list, "Toulon");
    insertPlace(&list, "mArseIlLe");
    insertPlace(&list, "SAINT-MITRE-LES-REMPARTs");
    //displayListOfPlace(list);
    
    //Place *r = NULL;
    //searchPlace(list, &r, "TouloN");
    //displayPlace(r);
    
    list_individu i;
    i.sublistMariage = NULL;
    i.sublistIndividu = NULL;
    i.c1 = NULL;
    i.c2 = NULL;
    i.suivant = NULL;
    list_descriptionIndividu desci;
    m_date d1 = {1, 2, 1999};
    desci.deces = &d1;
    m_date d2 = {6, 4, 1980};
    desci.naissance = &d2;
    desci.generation = 2;
    desci.genre = "";
    desci.lieuDeces = "Marseille";
    desci.lieuNaissance = "Toulon";
    desci.nom = "john";
    desci.prenom = "doe";
    i.data = &desci;

    insertBirthInPlace(list, &i);
    insertDeathInPlace(list, &i);

    list_individu i2;
    i2.sublistMariage = NULL;
    i2.sublistIndividu = NULL;
    i2.c1 = NULL;
    i2.c2 = NULL;
    i2.suivant = NULL;
    list_descriptionIndividu desci2;
    m_date d3 = {1, 2, 1399};
    desci2.deces = &d3;
    m_date d4 = {6, 4, 1380};
    desci2.naissance = &d4;
    desci2.generation = 2;
    desci2.genre = "";
    desci2.lieuDeces = "Marseille";
    desci2.lieuNaissance = "Toulon";
    desci2.nom = "john";
    desci2.prenom = "doe";
    i2.data = &desci2;
     
    insertBirthInPlace(list, &i2);
    insertDeathInPlace(list, &i2);

    LIST c1;
    c1.type = type_listIndividu;
    c1.u.list_individu = &i;
    LIST c2;
    c2.type = type_listIndividu;
    c2.u.list_individu = &i2;

    list_mariage mar;
    mar.suivant = NULL;
    mar.c1 = &c1;
    mar.c2 = &c2;
    m_date d9 = {12, 10, 1340};
    mar.data = malloc(sizeof(m_date));
    mar.data->date = &d9;
    mar.data->lieu = "SAINT-MITRE-LES-REMPARTS";
    
    insertMariageInPlace(list, &mar);

    //findPlaceWithMaxEvent(list, &r);
    //displayPlace(r);
    
    displayListOfPlace(list);
    
    deleteListOfPlace(&list);



    //fetchDataBaseOfCityInFile("../../../assets/db/villes.db", "../../../assets/map/villes2.txt");

    return 0;
}
