#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../include/LIST/structure.h"
#include "../../include/ML/list/event/Event.h"

int main(void) {
    Event *list = NULL;
    ptrFunc *f = initPtrFunc();
    
    list_individu i;
    i.sublistMariage = NULL;
    i.sublistIndividu = NULL;
    i.c1 = NULL;
    i.c2 = NULL;
    i.suivant = NULL;
    list_descriptionIndividu desci;
    m_date d1 = {1, 2, 1999};
    desci.deces = &d1;
    m_date d2 = {6, 4, 1980};
    desci.naissance = &d2;
    desci.generation = 2;
    desci.genre = "";
    desci.lieuDeces = "Mar";
    desci.lieuNaissance = "Tln";
    desci.nom = "john";
    desci.prenom = "doe";
    i.data = &desci;

    list_individu i2;
    i2.sublistMariage = NULL;
    i2.sublistIndividu = NULL;
    i2.c1 = NULL;
    i2.c2 = NULL;
    i2.suivant = NULL;
    list_descriptionIndividu desci2;
    m_date d3 = {1, 6, 1499};
    desci2.deces = &d3;
    m_date d4 = {6, 6, 1280};
    desci2.naissance = &d4;
    desci2.generation = 2;
    desci2.genre = "";
    desci2.lieuDeces = "NYC";
    desci2.lieuNaissance = "Tln";
    desci2.nom = "johnette";
    desci2.prenom = "doef";
    i2.data = &desci2;
    
    list_mariage mar;
    mar.suivant = NULL;
    LIST c1, c2;
    c1.u.list_individu = &i;
    c2.u.list_individu = &i2;
    mar.c1 = &c1;
    mar.c2 = &c2;
    m_date d6 = {12, 10, 1345};
    mar.data = malloc(sizeof(m_date));
    mar.data->date = NULL;
    mar.data->lieu = "test";

    list_mariage mar2;
    mar2.suivant = NULL;
    mar2.c1 = &c1;
    mar2.c2 = &c2;
    m_date d9 = {12, 10, 1340};
    mar2.data = malloc(sizeof(m_date));
    mar2.data->date = &d9;
    mar2.data->lieu = "test";
    
    
    insertBirth(&list, f, &i);

    insertDeath(&list, f, &i);
    insertBirth(&list, f, &i2);
    insertDeath(&list, f, &i2);
    //insertBirth(&list, f, &i);
    insertMariage(&list, f, &mar2);
    

    insertMariage(&list, f, &mar);

    //insertBirth(&list, f, &i2);
    //insertBirth(&list, f, &i);
    //insertDeath(&list, f, &i2);
    displayListEvent(list, f);

    deleteListOfEvent(&list);
    freePtrFunc(&f);
    free(mar.data);
    return 0;
}