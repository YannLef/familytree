#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <unistd.h>
#include "GFX/GfxLib.h"
#include "GFX/BmpLib.h"

#include "include/IHM/structures.h"
#include "include/TREE/structure.h"
#include "include/IHM/Couleur.h"
#include "include/IHM/Keyboard.h"
#include "include/IHM/Mouse.h"
#include "include/IHM/Rectangle.h"
#include "include/IHM/ButtonChangePage.h"
#include "include/IHM/ButtonChangeFile.h"
#include "include/IHM/Page.h"
#include "include/IHM/Navbar.h"
#include "include/IHM/InputText.h"
#include "include/IHM/GenealogicalTree.h"
#include "include/IHM/SliderVertical.h"
#include "include/IHM/SliderHorizontal.h"
#include "include/IHM/Carre.h"
#include "include/IHM/Checkbox.h"

#include "include/LIST/structure.h"
#include "include/LIST/list/list.h"
#include "include/LIST/sublist/sublist.h"

#include "include/LIST/dataTree/dataTree.h"
#include "include/IHM/Data.h"
#include "include/LIST/listGeneration/individu/generateI.h"
#include "include/LIST/listGeneration/mariage/generateM.h"
#include "include/LIST/listGeneration/methode/listSave.h"
#include "include/LIST/list/individu/methode/toolI.h"
#include "include/LIST/list/mariage/methode/toolM.h"
#include "include/LIST/list/individu/methode/displayTerminalI.h"
#include "include/LIST/list/mariage/methode/displayTerminalM.h"
#include "include/LIST/list/individu/methode/getDataCharI.h"
#include "include/ML/ML.h"
#include "include/IHM/DropDownMenuRight.h"
#include "include/IHM/Formulaire.h"
#include "include/IHM/FileExplorer.h"
#include "include/TREE/generationTree/treeASC/treeASC.h"
#include "include/TREE/generationTree/treeDESC/treeDESC.h"

#include "include/LIST/listGeneration/methode/deleteL.h"
#include "include/IHM/RadioButton.h"
#include "include/TREE/generationTree/noeudData.h"
#include "include/IHM/BoundedRectangle.h"
#include "include/IHM/Conversation.h"
#include "include/IHM/ButtonSendMessage.h"
#include "include/IHM/current.h"




// Largeur et hauteur par defaut d'une image correspondant a nos criteres
#define LargeurFenetre 1600
#define HauteurFenetre 800

couleurTab c; // Définit le tableau de couleurs
keyboard keys; // Définit le clavier -> à synchroniser avec les autres fichiers si nécessaire ("extern")
mouse souris; // Définit le clavier -> à synchroniser avec les autres fichiers si nécessaire ("extern")

/* La fonction de gestion des evenements, appelee automatiquement par le systeme
des qu'une evenement survient */
void gestionEvenement(EvenementGfx evenement);

int main(int argc, char **argv)
{
    initialiseGfx(argc, argv);

    prepareFenetreGraphique("FAMILY TREE", LargeurFenetre, HauteurFenetre);

    /* Lance la boucle qui aiguille les evenements sur la fonction gestionEvenement ci-apres,
        qui elle-meme utilise fonctionAffichage ci-dessous */
    lanceBoucleEvenements();

    return 0;
}

/* La fonction de gestion des evenements, appelee automatiquement par le systeme
des qu'une evenement survient */
void gestionEvenement(EvenementGfx evenement)
{
    static int tempo = 20; // Temporisation de la boucle evenements

    static pages p; // énumération permettant de diviser le programme en différentes pages / différents affichages

    // Les entiers suivants définissent le centre de l'écran.
    static int xEcran=0;
    static int yEcran=0;
    static float coefZoom=1; // Définit si l'arbe est affiché plus grand (coefZoom > 1) ou plus petit (coefZoom<1) que normal (coefZoom=1)

    static int nav[10]; // Tableau d'entier décrivants l'état des onglets de la barre de navigation ( actifs=1 ou non=0)
    static menuDeroulantVersDroite menuDeroulant; // définit le menu déroulant allant de pair avec la barre de navigation
    static boutonChangePage newTree;
    static boutonChangePage openTree;
    static boutonChangePage exitOpenTree;

    // Les deux boutons permettants de naviguer dans l'explorateur de fichiers
    static boutonChangeFichiers nextFichiers;
    static boutonChangeFichiers previousFichiers;

    static DonneesImageRGB *navbarre = NULL; // L'image de la barre de navigation
    static DonneesImageRGB *fondaccueil = NULL; // L'image de fond de la page d'accueil
    static DonneesImageRGB *fondExplorateur = NULL; // L'image de fond de l'explorateur de fichiers
    static DonneesImageRGB *enteteFondExplorateur = NULL; // L'image de fond de l'entête de l'explorateur de fichiers
    static DonneesImageRGB *infos_individu_homme = NULL; // L'image pour la description d'un individu homme
    static DonneesImageRGB *infos_individu_femme = NULL; // L'image pour la description d'un individu femme
    static DonneesImageRGB *infos_individu_null = NULL; // L'image pour la description d'un individu sans genre
    static DonneesImageRGB *map = NULL; // L'image pour la catégorie naissance de la description d'un individu -> la carte de david fait 800*800 et est affichée au milieu de l'image de 980*800
    static DonneesImageRGB *user = NULL; // L'image pour les messages de l'utilisateur dans l'assistant
    static DonneesImageRGB *help = NULL; // L'image pour les messages de l'aide dans l'assistant
    static DonneesImageRGB *insertion_individu = NULL; // L'image pour la catégorie de l'insertion d'un individu
    static DonneesImageRGB *search_poeple = NULL; //image pour le formulaire de l'update
    static DonneesImageRGB *formulaire_carte = NULL; //image pour le formulaire de la carte de france
    static DonneesImageRGB *credits = NULL; //image pour crédits
    static DonneesImageRGB *update_individu_null = NULL; //image pour update sans genre
    static DonneesImageRGB *update_individu_homme = NULL; //image pour update homme
    static DonneesImageRGB *update_individu_femme = NULL; //image pour update femme

    // Variables utilisés par l'explorateur de fichiers
    static fichier* listeFichiers = NULL; // tableau stockant les informations des différents fichiers
    static int nombreFichiers = 0; // Le nombre de fichiers dans le dossier courant
    static int debutAffichageExplorateur = 0; // Le numéro du premier fichier devant apparaître dans l'affichage de lexplorateur de fichier (gestion des pages)
    static fichier fichierCharge;

    // Pour les listes
    static LIST *head_individu = NULL;
    static LIST *head_mariage = NULL;
    static char *fileNameI = NULL;
    static char *fileNameM = NULL;
    static funcList *func = NULL;
    static funcSublist *funcSL = NULL;
    static dataFile *fileI = NULL;
    static dataFile *fileM = NULL;

    // Les racines des arbres générés pour l'affichage
    static NoeudASC *rootASC = NULL;
    static NoeudDESC *rootDESC = NULL;

    // Pour connaitre quel individu est selectionné (et l'afficher dans le menu)
    static NoeudASC *courantASC = NULL;
    static NoeudDESC *courantDESC = NULL;

    // Les informations relatives aux arbres permettant l'affichage
    static NoeudData *treeASC = NULL;
    static NoeudData *treeDESC = NULL;

    static bool modeAffichageArbre=0; // Permet de switcher entre affichage ascendant et descnandant

    static message** messages; // Tableau permettant de stocker les adresses des différents messages
    static int nbMessageMax = 4; // Le nombre maximum de message que l'on stocke / affiche
    static int nbMessage = 0; // Le nombre actuel de messages
    //static message m1,m2,m3,m4,m5;


    static inputText inputAssistant;
    static boutonSendMessage boutonEnvoiAssistant;

    // FORMULAIRE INSERT INDIVIDU
    static Form formInsereIndividu;

    // FORMULAIRE UPDATE INDIVIDU
    static Form formUpdateIndividu;

    // FORMULAIRE CHERCHE INDIVIDU
    static Form formChercheIndividu;

    // FORMULAIRE DE LA CARTE DE FRANCE
    static Form formCarteFrance;

    static allData data;

    static sliderVertical sliderCarteGauche;
    static int valeurSliderCarteGauche = 1000;
    static sliderVertical sliderCarteDroite;
    static int valeurSliderCarteDroite = 2100;
    static sliderHorizontal sliderCarteBas;
    static int valeurSliderCarteBas = 1;

    static Model* modelIA = NULL;
    static Population* populationToDisplay = NULL;
    
    switch (evenement)
    {
        case Initialisation:

            initCouleurTab(&c); // Initialise le tableau de couleurs
            initKeyboard(); // Initialise le clavier
            initNavbar(nav); // Initialise la barre de navigation
            initMenuDeroulantVersDroite(&menuDeroulant, 0, hauteurFenetre(), 70, 620, 0); // Initialise le menu déroulant, allant de pair avec la barre de navigation
            navbarre = lisBMPRGB("../assets/IHM/NavBarre.bmp"); // lit l'image de la barre de navigation
            fondaccueil = lisBMPRGB("../assets/IHM/FondAccueil.bmp"); // lit l'image d'arrière plan de la page d'accueil
            fondExplorateur = lisBMPRGB("../assets/IHM/FondExplorateurFichier.bmp"); // lit l'image d'arrière plan de l'explorateur de fichier
            enteteFondExplorateur = lisBMPRGB("../assets/IHM/EnteteFondExplorateurFichier.bmp"); // lit l'image d'arrière plan de l'entête de l'explorateur de fichier
            infos_individu_homme = lisBMPRGB("../assets/IHM/infos_individu_homme.bmp"); // lit l'image de la description d'un individu homme
            infos_individu_femme = lisBMPRGB("../assets/IHM/infos_individu_femme.bmp"); // lit l'image de la description d'un individu femme
            infos_individu_null = lisBMPRGB("../assets/IHM/infos_individu_null.bmp"); // lit l'image de la description d'un individu femme
            map = lisBMPRGB("../assets/map/france.bmp"); // lit l'image de la catégorie naissance de la description d'un individu
            user = lisBMPRGB("../assets/IHM/user.bmp"); // lit l'image de la catégorie naissance de la description d'un individu
            help = lisBMPRGB("../assets/IHM/help.bmp"); // lit l'image de la catégorie naissance de la description d'un individu
            insertion_individu = lisBMPRGB("../assets/IHM/insert.bmp"); // lit l'image de la catégorie d'insertion d'un individu
            search_poeple = lisBMPRGB("../assets/IHM/SEARCH_PEOPLE.bmp"); // lit l'image de la categorie search qlq
            formulaire_carte = lisBMPRGB("../assets/IHM/PLACES_EVENTS.bmp"); // lit l'image du formulaire carte de france
            credits = lisBMPRGB("../assets/IHM/credits.bmp"); // lit l'image pour les crédits
            update_individu_null = lisBMPRGB("../assets/IHM/update_individu_null.bmp"); // lit l'image pour update un individu null
            update_individu_homme = lisBMPRGB("../assets/IHM/update_individu_homme.bmp"); // lit l'image pour update un individu homme
            update_individu_femme = lisBMPRGB("../assets/IHM/update_individu_femme.bmp"); // lit l'image pour update un individu femme
            initPage(&p,accueil); // Page initiale = page d'accueil
            initBoutonChangePage(&newTree, "New Tree", 800, 500, 500, 200, 7, c.fondPrincipal, c.vertPrincipal, c.bleuEcriture, 5, newArbre); // Bouton "new tree" sur l'accueil
            initBoutonChangePage(&openTree, "Open Tree", 800, 400, 500, 200, 7, c.fondPrincipal, c.vertPrincipal, c.bleuEcriture, 5, openArbre); // Bouton "open tree" sur l'accueil
            initBoutonChangePage(&exitOpenTree, "Back", 800, 760, 1600, 80, 2, c.vertPrincipal, c.vertPrincipal, c.blanc, 3, accueil); // Bouton retour dans "open tree"

            // Bouton pour faire défiler les propositions de fichiers
            initBoutonChangeFichiers(&nextFichiers, ">", 1200, 40, 800, 80, 2, c.vertPrincipal, c.vertPrincipal, c.blanc, 3, 6);
            initBoutonChangeFichiers(&previousFichiers, "<", 400, 40, 800, 80, 2, c.vertPrincipal, c.vertPrincipal, c.blanc, 3, -6);

            initInputText(&inputAssistant, 0, 70 + (620-70)/2 - 70, 100, 350, 100, 5, c.blanc, c.vertPrincipal);
            initBoutonSendMessage(&boutonEnvoiAssistant,540,100,100,100,5,c.blanc,c.vertPrincipal,c.noir,3);

            LISTINDIVIDU_initAllDatas(&data);

            //~ // TESTS
            //~ initMessage(&m1, 1,"Salut");
            //~ initMessage(&m2, 0,"je");
            //~ initMessage(&m3, 0,"suis");
            //~ initMessage(&m4, 1,"Yann");
            //~ initMessage(&m5, 0, "LEFEVRE, j'habite a arcachon et je travaille dans l'immobilier");
            //~ ajouteMessage(&messages, &m1, nbMessageMax, &nbMessage);
            //~ ajouteMessage(&messages, &m2, nbMessageMax, &nbMessage);
            //~ ajouteMessage(&messages, &m3, nbMessageMax, &nbMessage);
            //~ ajouteMessage(&messages, &m4, nbMessageMax, &nbMessage);
            //~ ajouteMessage(&messages, &m5, nbMessageMax, &nbMessage);
            //~ printf("%s\n",messages[0]->string);
            //~ printf("%s\n",messages[1]->string);
            //~ printf("%s\n",messages[2]->string);
            //~ printf("%s\n",messages[3]->string);

            initFormInsereIndividu(&formInsereIndividu);
            initFormUpdateIndividu(&formUpdateIndividu);
            initFormChercheIndividu(&formChercheIndividu);
            initFormCarteFrance(&formCarteFrance);

            initSliderVertical(&sliderCarteGauche, 620 + 50, hauteurFenetre()/2, hauteurFenetre() - 100, 5, 30, c.gris180, c.vertPrincipal, 1000, 2100, &valeurSliderCarteGauche);
            initSliderVertical(&sliderCarteDroite, largeurFenetre() - 50, hauteurFenetre()/2, hauteurFenetre() - 100, 5, 30, c.gris180, c.vertPrincipal, 1000, 2100, &valeurSliderCarteDroite);
            initSliderHorizontal(&sliderCarteBas, 620 + 980/2, 25, (1600-620) - 400, 5, 30, c.gris180, c.vertPrincipal, 0, 2, &valeurSliderCarteBas);

            recupereInfosFichiersDansDossier("../assets/csv", &listeFichiers, &nombreFichiers); // On récupère les informations concernant les fichiers prêts à être ouverts
            demandeTemporisation(tempo);
            break;

        case Temporisation:
            updatePage(&p); // Permet de changer de page si l'ordre à été donné dans une autre fonction (ex : lors d'un clic sur un bouton)
            if(nav[7] == 1){
                updateInputText(&inputAssistant);
            }

            exitProgram(&navbarre, &fondaccueil, &enteteFondExplorateur, &fondExplorateur, &map, &infos_individu_homme, &infos_individu_femme, &infos_individu_null, &user, &help,
                        &insertion_individu, messages, nbMessage, fileM, &head_mariage, &func, &funcSL, &head_individu, fileI, &courantASC, &courantDESC, &formInsereIndividu, &formUpdateIndividu,
                        &formChercheIndividu); // Permet de fermer le programme proprement quand la touche esc est appuyée

            switch(p.pActuel){
                case newArbre:
                    break;
                case arbre:
                    gereMenuDeroulantVersDroite(nav, &menuDeroulant); // Gère l'ouverture et la fermeture du menu déroulant en fonction de l'onglet actif de la navbar

                    if(nav[3] != 1){ // Quand la carte est ouverte, on ne peux plus déplacer l'arbre
                        updateTreeDisplay(p.pActuel, &xEcran, &yEcran, &coefZoom); // Actualise l'affichage de l'arbre en fonction du déplacement (xEcran, yEcran) et du zoom (coefZoom)
                    }

                    if(nav[3] == 1){
                        gereClicSliderVertical(&sliderCarteGauche, abscisseSouris(), ordonneeSouris());
                        gereClicSliderVertical(&sliderCarteDroite, abscisseSouris(), ordonneeSouris());
                        gereClicSliderHorizontal(&sliderCarteBas, abscisseSouris(), ordonneeSouris());

                        // Pour que les valeurs des sliders forment une plage

                        if(*(sliderCarteDroite.var) <= *(sliderCarteGauche.var) && abscisseSouris() < 620 + 980/2){ // On gère le fait qu'il ne peut pas y avoir min > max
                            *(sliderCarteDroite.var) = *(sliderCarteGauche.var) + 1;
                        }

                        if(*(sliderCarteGauche.var) >= *(sliderCarteDroite.var) && abscisseSouris() > 620 + 980/2){ // On gère le fait qu'il ne peut pas y avoir min > max
                            *(sliderCarteGauche.var) = *(sliderCarteDroite.var) - 1;
                        }
                    }

                    if(nav[5] == 1){
                        updateForm(formInsereIndividu);
                    }

                    if(nav[6] == 1){
                        updateForm(formUpdateIndividu);
                    }

                    if(nav[1] == 1){
                        updateForm(formChercheIndividu);
                    }

                    if(nav[3] == 1){
                        updateForm(formCarteFrance);

                    }

                    break;
                case openArbre:
                    break;
                case accueil:
                    break;
            }
            rafraichisFenetre();
            break;

        case Affichage:
            effaceFenetre (255, 255, 255);
            switch(p.pActuel){
                case accueil:
                    afficheAccueil(fondaccueil, newTree, openTree, xEcran, yEcran, coefZoom); // Affiche la page d'accueil et tout ses composants
                    break;
                case arbre:
                    afficheArbre(nav,modeAffichageArbre, treeASC, treeDESC, rootASC, rootDESC, map, infos_individu_homme, infos_individu_femme, infos_individu_null, navbarre, p, courantASC,
                                 courantDESC, &menuDeroulant, messages, nbMessage, inputAssistant, boutonEnvoiAssistant, user, help, formInsereIndividu, insertion_individu, formUpdateIndividu,
                                 formChercheIndividu, formCarteFrance, formulaire_carte, search_poeple, &data, sliderCarteGauche, sliderCarteDroite, sliderCarteBas, valeurSliderCarteGauche,
                                 valeurSliderCarteDroite, valeurSliderCarteBas, populationToDisplay, credits, update_individu_null, update_individu_homme, update_individu_femme, xEcran, yEcran, coefZoom);



                    break;
                case openArbre:
                    afficheExplorateurDeFichiers(enteteFondExplorateur, fondExplorateur, listeFichiers, exitOpenTree, nextFichiers, previousFichiers, xEcran, yEcran, coefZoom, debutAffichageExplorateur, nombreFichiers); // Affiche l'explorateur de fichiers
                    break;
                case newArbre:
                    break;
            }

            break;

        case Clavier: // Rendu inutilisable car modification des callbacks de glut par le nouveau système de gestion du clavier (demander à Yann)
            break;

        case ClavierSpecial: // Rendu inutilisable car modification des callbacks de glut par le nouveau système de gestion du clavier (demander à Yann)
            break;

        case BoutonSouris:
            if (etatBoutonSouris() == GaucheAppuye)
            {
                mouseLeftDown();
                //~ printf("Bouton gauche appuye en : (%d, %d)\n", abscisseSouris(), ordonneeSouris());
                switch(p.pActuel){
                    case accueil:
                        gereSourisBoutonChangePage(openTree, &p, abscisseSouris(), ordonneeSouris()); // Gère les clics sur le bouton "open tree" de accueil
                        //~ gereSourisBoutonChangePage(newTree, &p, abscisseSouris(), ordonneeSouris()); // Gère les clics sur le bouton "ne tree" de accueil
                        break;

                    case arbre:
                        gereSourisNavbar(abscisseSouris(), ordonneeSouris(), nav, &p, &menuDeroulant, &courantASC, &courantDESC, &modeAffichageArbre, messages, nbMessage, fileM, &head_mariage,
                                         &func, &funcSL, &head_individu, fileI, &formUpdateIndividu, &data, &xEcran, &yEcran, &coefZoom); // Gère la navigations entre les onglets de la barre de navigation en fonction des clics
                        if(nav[3] != 1){ // Quand la carte est ouverte, on ne peux plus cliquer sur les individus
                            if(modeAffichageArbre == 0){
                                if(rootASC != NULL){ // On vérifie que l'arbre ASC a été initialisé
                                    // On vérifie si un des individus de cet arbre a été cliqué
                                    checkTreeASCNodeClic(abscisseSouris(), ordonneeSouris(), rootASC, &courantASC, xEcran, yEcran, coefZoom, nav,menuDeroulant, modeAffichageArbre, &formUpdateIndividu, &data); // Si l'utilisateur clique sur un individu de l'arbre, celui ci devient l'individu courant (affichage de ses infos)
                                }
                            }else{
                                if(rootDESC != NULL){ // On vérifie que l'arbre DESC a été initialisé
                                    // On vérifie si un des individus de cet arbre a été cliqué
                                    checkTreeDESCNodeClic(abscisseSouris(), ordonneeSouris(), rootDESC, &courantDESC, xEcran, yEcran, coefZoom, nav,menuDeroulant, modeAffichageArbre, &formUpdateIndividu, &data); // Si l'utilisateur clique sur un individu de l'arbre, celui ci devient l'individu courant (affichage de ses infos)
                                }
                            }

                            if(nav[7] == 1){ // Onglet 7
                                gereSourisInputText(&inputAssistant, abscisseSouris(), ordonneeSouris());
                                gereSourisBoutonSendMessage(boutonEnvoiAssistant, &inputAssistant, &messages, nbMessageMax, &nbMessage, abscisseSouris(), ordonneeSouris());
                            }

                            if(nav[5] == 1){ // Onglet 5 : insérer un individu
                                gereClicForm(formInsereIndividu, abscisseSouris(), ordonneeSouris());
                                gereSourisBoutonValideAdd(&formInsereIndividu, &head_individu, func, abscisseSouris(),ordonneeSouris(),
                                &rootASC, &treeASC, &rootDESC, &treeDESC);
                            }

                            if(nav[6] == 1){ // Onglet 5 : insérer un individu
                                gereClicForm(formUpdateIndividu, abscisseSouris(), ordonneeSouris());
                                //maillon
                                gereSourisBoutonValideUpdate(&formUpdateIndividu, abscisseSouris(), ordonneeSouris(), &head_individu, courantASC, courantDESC, funcSL,
                                &rootASC, &treeASC, &rootDESC, &treeDESC);

                            }

                            if(nav[1] == 1){ // Onglet 5 : insérer un individu
                                gereClicForm(formChercheIndividu, abscisseSouris(), ordonneeSouris());
                                gereSourisBoutonValideSearch(&formChercheIndividu, abscisseSouris(), ordonneeSouris(), head_individu, funcSL);
                            }


                        }if(nav[3] == 1){ // Onglet 4 : carte de france
                    gereCLicFormCarteFrance(formCarteFrance, abscisseSouris(), ordonneeSouris());
                    gereSourisBoutonValideCarte(&formCarteFrance, &populationToDisplay, modelIA, abscisseSouris(),ordonneeSouris());
                }
                        break;

                    case openArbre:
                        gereSourisBoutonChangeFichiers(nextFichiers, &debutAffichageExplorateur, nombreFichiers, abscisseSouris(), ordonneeSouris());
                        gereSourisBoutonChangeFichiers(previousFichiers, &debutAffichageExplorateur, nombreFichiers, abscisseSouris(), ordonneeSouris());
                        gereSourisBoutonChangePage(exitOpenTree, &p, abscisseSouris(), ordonneeSouris());
                        gereSourisSelectionneFichier(abscisseSouris(), ordonneeSouris(), &debutAffichageExplorateur, nombreFichiers, &p, listeFichiers, &fichierCharge, &fileNameI, &fileNameM, &fileI,
                                                     &fileM, &func, &funcSL, &head_individu, &head_mariage, &rootASC, &treeASC, &rootDESC, &treeDESC, &modelIA);

                        break;
                    case newArbre:
                        break;
                }

            }
            else if (etatBoutonSouris() == GaucheRelache)
            {
                mouseLeftUp();
                printf("Bouton gauche relache en : (%d, %d)\n", abscisseSouris(), ordonneeSouris());

            }
            break;

        case Souris: // Si la souris est deplacee
            break;

        case Inactivite: // Quand aucun message n'est disponible
            break;

        case Redimensionnement: // La taille de la fenetre a ete modifie ou on est passe en plein ecran
            // Donc le systeme nous en informe
            printf("Largeur : %d\t", largeurFenetre());
            printf("Hauteur : %d\n", hauteurFenetre());
            break;
    }
}
