/**
 * @brief 
 *      Dans la structure NoeudData il faut utiliser que Le nombre de génération max, 
 *      le reste est initialisé mais ne sert pas pour cette arbre
 *  
 * @param ptrIndividu 
 * @param noeudData 
 * @return NoeudASC* 
 */
NoeudASC* TREEASC_createTree(LIST *ptrIndividu, NoeudData **noeudData);

/**
 * @brief 
 * 
 * @param root 
 */
void TREEASC_deletetree(NoeudASC **root);

/**
 * @brief 
 * 
 * @param root 
 */
void TREEASC_display(NoeudASC *root);