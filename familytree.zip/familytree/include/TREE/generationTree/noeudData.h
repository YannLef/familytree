/**
 * @brief 
 * 
 * @param noeudData 
 * @param ptrIndividu 
 */
void NOEUDDATA_createStructure(NoeudData **noeudData, LIST *ptrIndividu);

/**
 * @brief 
 * 
 * @param noeudData 
 */
void NOEUDDATA_deleteStructure(NoeudData **noeudData);

/**
 * @brief 
 * 
 * @param noeudData    
 */
void NOEUDDATA_displayStructure(NoeudData *noeudData);