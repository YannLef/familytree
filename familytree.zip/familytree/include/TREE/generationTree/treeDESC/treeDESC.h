
/**
 * @brief 
 * 
 * @param sublistEnfant 
 * @return NoeudHeadDESC* 
 */
NoeudHeadDESC* TREEDESC_createHeadNode(SUBLIST *sublistEnfant, NoeudData **noeudData);

/**
 * @brief 
 * 
 * @param individu 
 * @return NoeudDESC* 
 */
NoeudDESC *TREEDESC_initialize(LIST *individu, NoeudData **noeudData);

/**
 * @brief 
 * 
 * @param node 
 */
void displayTreeDESCNode(NoeudDESC *node);

/**
 * @brief 
 * 
 * @param node 
 */
void displayTreeDESCNodeHead(NoeudHeadDESC *node);

/**
 * @brief 
 * 
 * @param node 
 */
void TREEDESC_freeNoeudDESC(NoeudDESC **node);

/**
 * @brief 
 * 
 * @param node 
 */
void TREEDESC_freeNoeudHeadDESC(NoeudHeadDESC **node);

/**
 * @brief 
 * 
 * @param individu 
 * @param noeudData 
 * @param node 
 */
void TREEDESC_initializeNoeudData(LIST *individu, NoeudData **noeudData, NoeudDESC *node);

/**
 * @brief 
 * 
 * @param node 
 * @param noeudData 
 * @param compteur 
 */
void NOEUDDATA_noeudDESC(NoeudDESC *node, NoeudData **noeudData, int compteur);

/**
 * @brief 
 * 
 * @param node 
 * @param noeudData 
 * @param compteur 
 */
void NOEUDDATA_noeudHeadDESC(NoeudHeadDESC *node, NoeudData **noeudData, int compteur);