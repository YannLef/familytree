/**
 * @brief 
 * 
 * @param ptrNode 
 */
void NODEASC_createNode(NoeudASC **ptrNode);

/**
 * @brief 
 * 
 * @param ptrNode 
 * @param ptrIndvidu 
 * @param ptrDroite 
 * @param ptrGauche 
 */
void NODEASC_insertData(NoeudASC **ptrNode, LIST *ptrIndvidu, NoeudASC *ptrDroite, NoeudASC *ptrGauche);

/**
 * @brief 
 * 
 * @param ptrNode 
 */
void NODEASC_deleteData(NoeudASC **ptrNode);

/**
 * @brief 
 * 
 * @param ptrNode 
 */
void NODEASC_deleteNode(NoeudASC **ptrNode);