/**
 * @brief 
 * 
 * @param ptrNode 
 */
void NODEHEADDESC_create(NoeudHeadDESC **ptrNode);

/**
 * @brief 
 * 
 * @param nbEnfant 
 * @param node 
 */
void NODEHEADDESC_insertDataEnfant(int nbEnfant, NoeudHeadDESC **node);

/**
 * @brief 
 * 
 * @param list 
 * @param node 
 */
void NODEHEADDESC_insertDataList(NoeudDESC *list, NoeudHeadDESC **node);

/**
 * @brief 
 * 
 * @param node 
 */
void NODEHEADDESC_deleteData(NoeudHeadDESC **node);

/**
 * @brief 
 * 
 * @param node 
 */
void NODEHEADDESC_deleteNode(NoeudHeadDESC **node);