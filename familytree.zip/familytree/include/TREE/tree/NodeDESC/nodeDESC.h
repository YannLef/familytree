
/**
 * @brief 
 * 
 * @param ptrNode 
 */
void NODEDESC_create(NoeudDESC **ptrNode);

/**
 * @brief 
 * 
 * @param ptrIndividu 
 * @param node 
 */
void NODEDESC_insertIndividu(LIST *ptrIndividu, NoeudDESC **node);

/**
 * @brief 
 * 
 * @param nextMaillon 
 * @param node 
 */
void NODEDESC_insertDatatNextMaillon(NoeudDESC *nextMaillon, NoeudDESC **node);

/**
 * @brief 
 * 
 * @param nextNode 
 * @param node 
 */
void NODEDESC_insertDataNextNode(NoeudHeadDESC *nextNode, NoeudDESC **node);

/**
 * @brief 
 * 
 * @param ptrHead 
 * @param ptrMaillon 
 */
void NODEDESC_insertMaillonHeadList(NoeudDESC **ptrHead, NoeudDESC **ptrMaillon);

/**
 * @brief 
 * 
 * @param node 
 */
void NODEDESC_deleteData(NoeudDESC **node);

/**
 * @brief 
 * 
 * @param node 
 */
void NODEDESC_deleteNode(NoeudDESC **node);