typedef struct NoeudASC NoeudASC;
typedef struct NoeudDESC NoeudDESC;
typedef struct NoeudHeadDESC NoeudHeadDESC;
typedef struct NoeudData NoeudData;

struct NoeudASC{
	rec rect;
	NoeudASC *droite; 
	NoeudASC *gauche; 
	LIST *ptrIndividu;
};

struct NoeudHeadDESC{
	int nbEnfants; 
    NoeudDESC *ptrListNoeudDESC;
};

struct NoeudDESC{
	rec rect;
    LIST *ptrIndividu;
	NoeudDESC *nextMaillon;
    NoeudHeadDESC *nextNode;
};

struct NoeudData{
	int nombreGeneration;
	int *nombreEnfantMaxGeneration;
	int nombreEnfantMax;	
};