void LISTINDIVIDU_initAllDatas(allData* data);
void LISTINDIVIDU_getAllDatas(allData* data, LIST *ptrMaillon);
void afficheAllData(allData data, DonneesImageRGB *infos_individu_femme, DonneesImageRGB *infos_individu_homme, DonneesImageRGB *infos_individu_null);
