void cercle(float centreX, float centreY, float rayon);

void initBoundedRectangle(BoundedRectangle *b, int x, int y, int largeur, int hauteur, int epaisseurBordure, couleur cInterieur, couleur cBordure);

void afficheBoundedRectangle(BoundedRectangle b);
