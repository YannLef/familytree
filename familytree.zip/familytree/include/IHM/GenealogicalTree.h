#ifndef GENEALOGICAL_TREE_H
#define GENEALOGICAL_TREE_H

 /**
  * -------------------------------------------------
  * -------------------- SUMMARY --------------------
  * -------------------------------------------------
  * 0) INTRODUCTION    - line ...
  * 1) UPDATE          - line ...
  * 3) DISPLAY         - line ...
  * 
  * 
*/

 /**
  * ---------------------------------------------------
  * -------------------- 1) UPDATE --------------------
  * ---------------------------------------------------
  * */
  
void updateTreeDisplay(page p, int* xEcran, int* yEcran, float* coefZoom);

 /**
  * ----------------------------------------------------
  * -------------------- 2) DISPLAY --------------------
  * ----------------------------------------------------
  * */
  
void afficheNoeudsDESC(int n, NoeudDESC* noeud, int l, int x, int y, int xEcran, int yEcran, float coefZoom, int nbGen, int* maxEnfants);
void afficheNoeudsASC(int n, int signe, NoeudASC* noeud, int l, int x, int y, int xEcran, int yEcran, float coefZoom);
void traceLienParente(rec rect1, rec rect2, bool mobile, int xEcran, int yEcran, float coefZoom);

#endif
