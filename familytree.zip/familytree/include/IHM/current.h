#ifndef CURRENT_H
#define CURRENT_H

/**
        SUMMARY

       INTRODUCTION    - line ...

    1) INITIALISATION  - line ...
*/

void afficheViseurCentre(void);
void afficheAccueil(DonneesImageRGB* fondaccueil, boutonChangePage newTree, boutonChangePage openTree, int xEcran, int yEcran, float coefZoom);
void afficheArbre(int nav[10], bool modeAffichageArbre, NoeudData *treeASC, NoeudData *treeDESC, NoeudASC *rootASC, NoeudDESC *rootDESC, DonneesImageRGB *map, DonneesImageRGB *infos_individu_homme, 
DonneesImageRGB *infos_individu_femme, DonneesImageRGB *infos_individu_null, DonneesImageRGB *navbarre, pages p, NoeudASC *courantASC, NoeudDESC *courantDESC, menuDeroulantVersDroite* menuDeroulant,
message** messages, int nbMessage, inputText inputAssistant, boutonSendMessage boutonEnvoiAssistant, DonneesImageRGB* user, DonneesImageRGB* help, Form formInsereIndividu,
DonneesImageRGB *insertion_individu, Form formUpdateIndividu, Form formChercheIndividu, Form formCarteFrance, DonneesImageRGB *formulaire_carte, DonneesImageRGB *search_poeple,
allData* data, sliderVertical sliderCarteGauche, sliderVertical sliderCarteDroite, sliderHorizontal sliderCarteBas,
int valeurSliderCarteGauche, int valeurSliderCarteDroite, int valeurSliderCarteBas, Population* populationToDisplay, DonneesImageRGB *credits, DonneesImageRGB *update_individu_null,
DonneesImageRGB *update_individu_homme, DonneesImageRGB *update_individu_femme, int xEcran, int yEcran, float coefZoom);

void initFormInsereIndividu(Form* formInsereIndividu);
void initFormUpdateIndividu(Form* formInsereIndividu);
void initFormChercheIndividu(Form* formChercheIndividu);
void gereCLicFormCarteFrance(Form formCarteFrance, int xSouris, int ySouris);
void afficheFormCarteFrance(Form formCarteFrance, int xEcran, int yEcran, float coefZoom);
void initFormCarteFrance(Form *formCarteFrance);

void saveDonneesFormCarte(Form *formulaire, Population** populationToDisplay, Model* modelIA);
void saveDonneesFormUpdate(Form *formulaire, LIST **ptrHead, LIST *maillon, funcSublist *funcSL);
void saveDonneesFormSearch(Form *formulaire, LIST *ptrHead, funcSublist *funcSl);
void saveDonneesFormAdd(Form *formulaire, LIST **ptrHead, funcList *func);

void gereSourisBoutonValideCarte(Form *formulaire,Population** populationToDisplay, Model* modelIA, int xSouris, int ySouris);
void gereSourisBoutonValideUpdate(Form *formulaire, int xSouris, int ySouris, LIST **ptrHead, NoeudASC *courantASC, NoeudDESC *courantDESC, funcSublist *funcsL,
NoeudASC** rootASC, NoeudData** treeASC, NoeudDESC** rootDESC, NoeudData** treeDESC);
void gereSourisBoutonValideSearch(Form *formulaire, int xSouris, int ySouris, LIST *ptrHead, funcSublist *funcSL);
void gereSourisBoutonValideAdd(Form *formulaire, LIST **ptrHead, funcList *func, int xSouris, int ySouris,
NoeudASC** rootASC, NoeudData** treeASC, NoeudDESC** rootDESC, NoeudData** treeDESC);
void afficheDataForm(DataFormulaire dataForm);
void freeDataForm(DataFormulaire* dataForm);

void exitProgram(DonneesImageRGB** navbarre, DonneesImageRGB** fondaccueil, DonneesImageRGB** enteteFondExplorateur, DonneesImageRGB** fondExplorateur, DonneesImageRGB** map, 
DonneesImageRGB** infos_individu_homme, DonneesImageRGB** infos_individu_femme, DonneesImageRGB** infos_individu_null, DonneesImageRGB** user, DonneesImageRGB** help,
DonneesImageRGB** insertion_individu, message** messages, int nbMessage, dataFile* fileM, LIST** head_mariage, funcList** func, funcSublist** funcSL, LIST** head_individu, dataFile* fileI,
NoeudASC **courantASC, NoeudDESC **courantDESC, Form* formInsereIndividu, Form* formUpdateIndividu, Form* formChercheIndividu);

#endif
