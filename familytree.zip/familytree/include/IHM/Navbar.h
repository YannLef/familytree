#ifndef NAVBAR_H
#define NAVBAR_H

 /**
  * -------------------------------------------------
  * -------------------- SUMMARY --------------------
  * -------------------------------------------------
  * 0) INTRODUCTION    - line ...
  * 1) INITIALISATION  - line ...
  * 2) UPDATE          - line ...
  * 3) EVENTS          - line ...
  * 
  * 
*/

 /**
  * -----------------------------------------------------------
  * -------------------- 1) INITIALISATION --------------------
  * -----------------------------------------------------------
  * */
  
void initNavbar(int nav[10]);

 /**
  * ---------------------------------------------------
  * -------------------- 2) UPDATE --------------------
  * ---------------------------------------------------
  * */
  
void actualiseNavbar(int nbBouton, int nav[10], pages* pActuel, menuDeroulantVersDroite* menu, NoeudASC** courantASC, NoeudDESC** courantDESC, bool* modeAffichageArbre, message** messages,
int nbMessage, dataFile* fileM, LIST** head_mariage, funcList** func, funcSublist** funcSL, LIST** head_individu, dataFile* fileI, Form* formUpdateIndividu, allData* data,
int* xEcran, int* yEcran, float* coefZoom);
  
 /**
  * ---------------------------------------------------
  * -------------------- 3) EVENTS --------------------
  * ---------------------------------------------------
  * */
  
void gereSourisNavbar(int xSouris, int ySouris, int nav[10], pages* pActuel, menuDeroulantVersDroite* menu, NoeudASC** courantASC, NoeudDESC** courantDESC, bool* modeAffichageArbre,
message** messages, int nbMessage, dataFile* fileM, LIST** head_mariage, funcList** func, funcSublist** funcSL, LIST** head_individu, dataFile* fileI, Form* formUpdateIndividu, allData* data,
int* xEcran, int* yEcran, float* coefZoom);

#endif

