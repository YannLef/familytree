#ifndef DROPDOWN_MENU_RIGHT_H
#define DROPDOWN_MENU_RIGHT_H

 /**
  * -------------------------------------------------
  * -------------------- SUMMARY --------------------
  * -------------------------------------------------
  * 0) INTRODUCTION    - line ...
  * 1) INITIALISATION  - line ...
  * 2) DISPLAY         - line ...
  * 3) UPDATE          - line ...
  * 4) EVENTS          - line ...
  * 
  * 
*/

 /**
  * -----------------------------------------------------------
  * -------------------- 1) INITIALISATION --------------------
  * -----------------------------------------------------------
  * */
  
void initMenuDeroulantVersDroite(menuDeroulantVersDroite* menu, int yBas, int yHaut, int xGauche, int xDroite, bool etat);

 /**
  * ----------------------------------------------------
  * -------------------- 2) DISPLAY --------------------
  * ----------------------------------------------------
  * */
  
void afficheMenuDeroulantVersDroite(menuDeroulantVersDroite* menu, int xEcran, int yEcran, float coefZoom);
void afficheDetailMenu(int nav[10], pages p, menuDeroulantVersDroite* menuDeroulant, NoeudASC *courantASC, NoeudDESC *courantDESC, DonneesImageRGB *infos_individu_homme, 
DonneesImageRGB *infos_individu_femme, message** messages, int nbMessage, inputText inputAssistant, boutonSendMessage boutonEnvoiAssistant, DonneesImageRGB* user, DonneesImageRGB* help, 
Form formInsereIndividu, DonneesImageRGB *insertion_individu, bool modeAffichageArbre, Form formUpdateIndividu, Form formChercheIndividu, allData* data, DonneesImageRGB* infos_individu_null,
Form formCarteFrance, DonneesImageRGB *formulaire_carte, DonneesImageRGB *search_poeple, sliderVertical sliderCarteGauche, sliderVertical sliderCarteDroite, sliderHorizontal sliderCarteBas,
int valeurSliderCarteGauche, int valeurSliderCarteDroite, int valeurSliderCarteBas, Population* populationToDisplay,
DonneesImageRGB *credits, DonneesImageRGB *update_individu_null, DonneesImageRGB *update_individu_homme, DonneesImageRGB *update_individu_femme, int xEcran, int yEcran, float coefZoom);

 /**
  * ---------------------------------------------------
  * -------------------- 3) UPDATE --------------------
  * ---------------------------------------------------
  * */
  
void agrandiMenuDeroulantVersDroite(menuDeroulantVersDroite* menu);
void reduiMenuDeroulantVersDroite(menuDeroulantVersDroite* menu);

 /**
  * ---------------------------------------------------
  * -------------------- 4) EVENTS --------------------
  * ---------------------------------------------------
  * */
  
void gereMenuDeroulantVersDroite(int nav[10], menuDeroulantVersDroite* menuDeroulant);
void checkTreeASCNodeClic(int xSouris, int ySouris, NoeudASC* node, NoeudASC** courantASC, int xEcran, int yEcran, float coefZoom, int nav[10], menuDeroulantVersDroite menuDeroulant, bool modeAffichageArbre, Form* formUpdateIndividu, allData* data);
void checkTreeDESCNodeClic(int xSouris, int ySouris, NoeudDESC* node, NoeudDESC** courantDESC, int xEcran, int yEcran, float coefZoom, int nav[10], menuDeroulantVersDroite menuDeroulant, bool modeAffichageArbre, Form* formUpdateIndividu, allData* data);

#endif
