#ifndef STR_SPLIT_H
#define STR_SPLIT_H

typedef char* token;
typedef char** tokenner;

unsigned int split(token mainStr,char* sep,tokenner *tkn);

#endif //STR_SPLIT_H