#ifndef LINEAR_REGRESSION_H
#define LINEAR_REGRESSION_H

//[BEGIN_POINTS_CLOUD]

/**
 * @brief contains a cloud of nb points
 * 
 * e.g : life expectancy (X axis) by year (Y axis) 
 * nb in this example is the number of the year
 */
typedef struct PointsCloud
{
	int nb;	//number of points
	double *x; //values on X axis
	double *y; //values on Y axis
} PointsCloud;

/**
 * @brief create a new PointsCloud of nb points
 * 
 * @param pc Object
 * @param nb number of points
 */
void newPointsCloud(PointsCloud *pc, int nb);

/**
 * @brief clear a PointsCloud
 * 
 * @param pc 
 */
void clearPointsCloud(PointsCloud *pc);

/**
 * @brief print in the terminal, the values inside a cloud
 * of point
 * 
 * @param pc 
 */
void printPointsCloud(PointsCloud *pc);

/**
 * @brief save in filename (.txt) a cloud of points
 * 
 * @param pc 
 * @param filename 
 */
void savePointsCloud(PointsCloud *pc, char *filename);

/**
 * @brief read from a .txt file a cloud of points
 * 
 * @param pc 
 * @param filename 
 */
void readPointsCloud(PointsCloud *pc, char *filename);

/**
 * @brief copy from A to B a cloud of points
 * 
 * @param a 
 * @param b 
 */
void copyPointsCloudAtoB(PointsCloud *a, PointsCloud *b);

/**
 * @brief add a value to a cloud of points
 * 
 * 1) increment nb
 * 2) reallocate pc->x and pc->y
 * 3) add x and y to pc->x[pc->nb-1] and pc->y[pc->nb-1]
 * 
 * @param pc 
 * @param x 
 * @param y 
 */
void addValueToPointsCloud(PointsCloud *pc, double x, double y);

//[END_POINTS_CLOUD]

//[BEGIN_POLYNOME]

typedef struct Polynome
{
	int degre;
	double *tabCoeff; //coefficient array
} Polynome;

/**
 * @brief allocate p->tabCoeff of degre cells at 0
 * 
 * @param p 
 * @param degre 
 */
void newPolynome(Polynome *p, int degre);

/**
 * @brief add a coefficient to tabCoeff in p
 * 
 * @param p 
 * @param coeff 
 */
void addCoeff(Polynome *p, double coeff);

/**
 * @brief 
 * 
 * @param p 
 */
void clearPolynome(Polynome *p);

//[END_POLYNOME]

//[BEGIN_EASY_AVERAGE]

/**
 * @brief ccompute a quick average instead of including Average.h
 * 
 * @param average 
 * @param pc 
 */
void computeQuickAverage(double* average,double *data, int n);

//[END_EASY_AVERAGE]

//[BEGIN_QUICK_SUM]

/**
 * @brief compute the sum of a table of real number
 * 
 * This function is used to compute the equation of the linear regresssion
 * 
 * @param sum store the result
 * @param data pointer to the table of data
 * @param n pointer to the number of data
 */
void computeSumOfDouble(double* sum,double** data, int* n);

/**
 * @brief compute the sum of x*y for each value in the two table
 * 
 * e.g : Used to compute sumXY,sumXX,sumYY in linearRegression
 * 
 * @param sum store the result
 * @param x pointer to the first table
 * @param y pointer to the second table 
 * @param n number of value
 */
void computeSumOfDoubleOfXY(double* sum,double** x,double** y, int* n);

//[END_QUICK_SUM]

//[BEGIN_LINEAR_REGRESSION]

typedef struct LinearRegression
{
	float r; //Regression coefficient between 0 [bad] and 1 [perfect]
	Polynome ideal;
	double sumX,sumY,sumXY,sumYY,sumXX;
} LinearRegression;

/**
 * @brief compute a linear regression from a cloud of points
 * 
 * cf. https://en.wikipedia.org/wiki/Linear_regression
 * 
 * @param lr Object 
 * @param pc cloud of points
 */
void newLinearRegression(LinearRegression *lr, PointsCloud *pc);

/**
 * @brief clear the ideal polynome of LinearRegression
 * 
 * @param lr Object
 */
void clearLinearRegression(LinearRegression *lr);

/**
 * @brief compute the coefficient of the linear regression's coefficient
 * 
 * ŷ = a*x+b
 * 
 * Formula for a and b : https://bit.ly/2WyLnFU
 * 
 * @param lr pointer to the structure that contains the polynome
 * @param pc pointer to cloud of points
 */
void computeIdealPolynome(LinearRegression *lr, PointsCloud *pc);

//[END_LINEAR_REGRESSION]

#endif /* LINEAR_REGRESSION_H */