#ifndef STRUPR_H
#define STRUPR_H

char* strupr(char *src);

#endif //STRUPR_H