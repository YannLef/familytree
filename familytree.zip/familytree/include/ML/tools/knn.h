#ifndef KNN_H
#define KNN_H

/**
 * k-nearest neighbors algorithm :
 * 
 * Source :
 * - https://en.wikipedia.org/wiki/K-nearest_neighbors_algorithm
 * Code inspiration :
 * - https://codepen.io/gangtao/pen/PPoqMW
 * 
 * Pseudo code inspirated by the link above :
 * 
 * Calculus :
 * 
 * 1) create an array of distance.
 * 2) compute all distances between the current point and the other.
 *  2.1) save the maximum distance.
 * 3) sort the table.
 * 4) get only the k-first distances in the array.
 * 5) find the label with the most number of points in this table.
 * 
 * Display :
 * 
 * 1) display all the points.
 * 2) draw lines between the current point and the k nearest point.
 * 3) draw a circle from the current point to the maximum distance.
 * 4) display the founded point at the mouse coordinates with the right color
 * acccording to the label founded.
 * 
 */

//TODO use the structure Point from IHM instead
//TODO move getEuclidianDistance() in an appropriate file
typedef struct Point
{
    int x, y;
} Point;

/**
 * @brief Get the Euclidian Distance between p1 and p2
 * 
 * @param distance 
 * @param p1 first Point
 * @param p2 second Point
 */
void getEuclidianDistance(double *distance, Point p1, Point p2);

/**
 * @brief contains all data related to the knn algorithm
 * 
 */
typedef struct Knn
{
    int k;                // number of nearest points
    int numberOfCategory; //How many labels of the data set
    int n;                //number of points
} Knn;

/**
 * @brief draw all lines between the current point and the k nearest points
 * 
 * @param current current point
 * @param kNearestPoint pointer to the k-nearest point table
 * @param k
 * @param clicked draw the line until the user click to validate the point
 */
void drawLinesBetween(Point *current, Point **kNearestPoint, int k, int clicked);

#endif /* KNN_H */