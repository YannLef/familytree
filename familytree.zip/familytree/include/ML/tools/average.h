#ifndef AVERAGE_H
#define AVERAGE_H

/**
 * @brief define some useful name to indicate the index of a certain
 * average in the array of averages in a score structure
 *
 * i.e :
 *
 * AVERAGE_AGE_OF_MARIAGE_ALL => index 0 in the array
 * AVERAGE_AGE_OF_BIRTH_FEMALE => index 9 in the array
 */
typedef enum average_name
{
    AVERAGE_YEAR_OF_MARIAGE_ALL = 0,
    //AVERAGE_AGE_OF_MARIAGE_MALE,
    //AVERAGE_AGE_OF_MARIAGE_FEMALE,
    AVERAGE_YEAR_OF_DEATH_ALL,
    //AVERAGE_AGE_OF_DEATH_MALE,
    //AVERAGE_AGE_OF_DEATH_FEMALE,
    AVERAGE_YEAR_OF_BIRTH_ALL
    //AVERAGE_AGE_OF_BIRTH_MALE,
    //AVERAGE_AGE_OF_BIRTH_FEMALE,
} average_name;

/**
 * @brief Thanks to the average_type structure we can deal with
 * both float and int
 *
 * We store the value of the average in this structure
 * we compute the standardError to have a relation with error.
 *
 * e.g : Error handling could be useful for Machine Learning
 */
typedef struct Average
{
    //each case is a float pointer to avoid duplicate data
    float *arrayOfData;
    //number of data in the array
    unsigned int numberOfData;
    //value of the average
    float averageValue;
    //standard Error
    float standardError;
} Average;


/* ### constructors (initialisation) ### */

/**
 * @brief Initialise an Average with 
 * all attributs value are 0 and the array is NULL
 * 
 * @param a Average to initialize
 */
void newAverage(Average *a);

/**
 * @brief Initialise an Average with n elements at 0.
 * 
 * @param a Average to initialize
 * @param n Number of data
 */
void newAverageWithNDataInitialized(Average *a, unsigned int n);

/* ### Methods ### */

/**
 * @brief Add a data in the array of data AND recompute the average and the error.
 * 
 * 1) Update the number of items in the array.
 * 2) Reallocate the array.
 * 3) Add the new data at array[n-1].
 * 
 * @param a Average
 * @param newData 
 */
void addDataToAverage(Average *a, float newData);

/**
 * @brief Compute the average value if and only n >= 2.
 * 
 * Formula : https://bit.ly/2Il9sh2
 * 
 * @param a 
 */
void computeAverage(Average *a);

/**
 * @brief Compute the standard Error of the average if and only n >= 2.
 * 
 * Available if value != 0.
 * 
 * Formula : https://en.wikipedia.org/wiki/Standard_deviation
 * 
 * @param a This
 */
void computeStandardErrorOfAverage(Average *a);

/**
 * @brief Free the memory for the array and set all the other attributs to 0.
 * 
 * @param a This
 */
void clearAllDataOfAverage(Average *a);

/**
 * @brief Save an Average in one line in a text file
 * 
 * 
 * Format : {value:V,error:E,nbData:N,{v1,v2,...}}
 * Replace V,E,N,v1...vN by the corresponding data
 * 
 * @param a 
 * @param filename
 */
void saveAverageToTextFile(Average *a, char *filename);

/**
 * @brief return an Average from a log file of averages previously saved with
 * the saveAverageToTextFile methods
 * 
 * do not use sscanf ! try to use fseek instead !
 * 
 * tutorial : https://bit.ly/2v0dP7J
 * 
 * {value:%f,error:%f,nbData:%d,{%f,%f,...}}
 * 
 * @param a 
 * @param filename
 * 
 * */
void readAverageFromTextFile(Average *a, char *filename);

void printAverage(Average *a);

#endif //AVERAGE_H
