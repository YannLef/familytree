#ifndef ML_H
#define ML_H

#include "tools/average.h"
#include "tools/linearRegression.h"
#include "model/Score.h"
#include "model/Coordinate.h"

#include "list/event/Event.h"
#include "list/place/Place.h"

#include "model/Population.h"
#include "list/population/PopulationList.h"
#include "model/DataSet.h"
#include "model/Model.h"
#include "model/Map.h"

#include "model/IA.h"
#include "tools/strsplit.h"
#include "view/chatbot.h"

#endif // ML_H