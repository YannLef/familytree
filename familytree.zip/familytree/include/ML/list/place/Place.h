#ifndef FAMILYTREE_PLACE_H
#define FAMILYTREE_PLACE_H

/**
 * @brief data of a Place.
 * 
 */
typedef struct dataP {
    //Name of the place
    char *name;
    //list of all events concerning the specific place
    Event *listOfEvent;
    //total number of event
    int numberOfEvent;
    /*
        Geographical coordanates computed from the database Ville.db and sqlite3
        to positionate the Place on a Map, we need a scale from the 4 corners
        of the map (as an image)
    */
    Coordinate *geographicalPosition;
    /*
        Score of the place (Machine Learning)
        the higher the score, the more likely the location will be
    */
    Score *scoreOfPlace;
} dataP;

/**
 * @brief Place linked list to store all the events related to this location.
 *
 */
typedef struct Place
{
    dataP *data; //data of a place is placed in another structure
    struct Place *next;
} Place;

/**
 * search the previous place before insert.
 *
 * @param head list of Place
 * @param searched destination
 * @param insert Place choosen
 */
void searchPreviousPlaceNode(Place *head, Place **searched, Place *insert);

/**
 * insert a Place node in a list of Place.
 *
 * @param head list of Place
 * @param insert Place allocated
 */
void insertPlaceNode(Place **head, Place *insert);

/**
 * insert a Place in a list of Place from a name.
 *
 * @param head list of Place
 * @param name name of the place (NO_CASE_SENSITIVE)
 */
int insertPlace(Place **head, char* name);

/**
 * free a Place given
 *
 * @param p Place
 */
void freePlace(Place **p);

/**
 * delete all Places in a list of Place.
 *
 * @param head list of Place
 */
void deleteListOfPlace(Place **head);

/**
 * delete one Place.
 *
 * @param head list of Place
 * @param toDelete
 */
void deletePlace(Place **head, Place *toDelete);

/**
 * alloate and create a Place node.
 *
 * @param ptr pointer to the node
 */
void createPlace(Place **ptr);

/**
 * display a Place and it informations
 *
 * @param p Place
 */
void displayPlace(Place *p);

/**
 * display all Places in list
 *
 * @param head list of Place
 */
void displayListOfPlace(Place *head);

/**
 *
 * @param head list of Place
 * @param individu
 */
void insertBirthInPlace(Place *head,list_individu* individu);

/**
 *
 * @param head list of Place
 * @param individu
 */
void insertDeathInPlace(Place *head,list_individu* individu);

/**
 *
 * @param head list of Place
 * @param mariage
 */
void insertMariageInPlace(Place *head,list_mariage* mariage);

/**
 *
 * @param head list of Place
 * @param searched
 * @param name
 */
void searchPlace(Place *head, Place **searched,char* name);

/**
 *
 * @param head list of Place
 * @param searched
 */
void findPlaceWithMaxEvent(Place *head, Place **searched);

/**
 *
 * @param pathToDb
 * @param pathToFile
 */
void fetchDataBaseOfCityInFile(char *pathToDb, char *pathToFile);

#endif //FAMILYTREE_PLACE_H
