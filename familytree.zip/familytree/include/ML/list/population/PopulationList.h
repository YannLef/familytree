#ifndef POPULATION_LIST_H
#define POPULATION_LIST_H

typedef struct PopulationList {
    Population *data;
    struct PopulationList *next;
} PopulationList;

void searchPreviousPopulationListNode(PopulationList *head, PopulationList **searched, PopulationList *insert);

void insertPopulationListNode(PopulationList **head, PopulationList *insert);

void insertPopulationList(PopulationList **head, Population *p);

void freePopulationList(PopulationList **p);

void deleteListOfPopulationList(PopulationList **head);

void deletePopulationList(PopulationList **head, PopulationList *toDelete);

void createPopulationList(PopulationList **ptr);

void displayListOfPopulationList(PopulationList *head);

void searchPopulationList(PopulationList *head, PopulationList **searched, int nbEvent, population_type type);

int newPopulationListFromDataList(PopulationList **head, population_type type, LIST *data);


#endif //POPULATION_LIST_H