#ifndef FAMILYTREE_EVENT_H
#define FAMILYTREE_EVENT_H

#define NB_PTR_FUNC_EVENT 3 // number of function pointer for an event

/**
 * @brief define the type of an event.
 *
 */
typedef enum type_event
{
    MARIAGE = 0,
    DESCES,
    BIRTH
} type_event;

typedef struct dataE {
    type_event typeOfEvent;

    /**
     * depending on the type of event the description will change :
     * - The event is a mariage, we can find the related informations in the list.
     * - The event is a desces or a birth,
     *   we have access to his/her personal informations.
     *
     * additional information :
     * - whatever the description, the Place's name can be found in
     *   so it can be displayed at any time,
     *   we do not need to store the place's name.
     */
    union {
        list_individu *i;
        list_mariage *m;
    } desc;
} dataE;

/**
 * @brief linked list to store events.
 *
 */
typedef struct Event
{
    dataE* data; //data are stored in another structure
    struct Event *next;
} Event;

/**
 * @brief function pointer to call the respective searching function.
 */
typedef void (*searchEvent)(Event *head, Event **searched, Event *insert);
/**
 * @brief function pointer to call the respective displaying function.
 */
typedef void (*displayList)(Event *ptr);
/**
 * @brief contains the function pointers.
 */
typedef struct ptrFunc {
    searchEvent ptrSearchEvent[NB_PTR_FUNC_EVENT];
    displayList ptrDisplayList[NB_PTR_FUNC_EVENT];
} ptrFunc;

/**
 * callback function to display a death.
 *
 * @param ptr Event to display
 */
void displayEventDesces(Event *ptr);

/**
 * callback function to display a mariage.
 *
 * @param ptr Event to display
 */
void displayEventMariage(Event *ptr);

/**
 * callback function to display a birth.
 *
 * @param ptr Event to display
 */
void displayEventBirth(Event *ptr);

/**
 * tool function to compare two dates.
 *
 * @param d1 first
 * @param d2 second
 * @return -1 if d1 < d2 | 1 if d2 > d1 | 0 if d1 == d2 | else -2
 */
int compareDates(m_date* d1, m_date* d2);

/**
 * tool function to compare two mariage Event from the date.
 *
 * @param e1 first
 * @param e2 second
 * @return -1 if e1 < e2 | 1 if e2 > e1 | 0 if e1 == e2 | else -2
 */
int compareEventsMariage(Event *e1, Event *e2);
/**
 * tool function to compare two desces Event from the date.
 *
 * @param e1 first
 * @param e2 second
 * @return -1 if e1 < e2 | 1 if e2 > e1 | 0 if e1 == e2 | else -2
 */
int compareEventsDesces(Event *e1, Event *e2);
/**
 * tool function to compare two birth Event from the date.
 *
 * @param e1 first
 * @param e2 second
 * @return -1 if e1 < e2 | 1 if e2 > e1 | 0 if e1 == e2 | else -2
 */
int compareEventsBirth(Event *e1, Event *e2);

/**
 * callback function called by ptrFunc on searchEvent.
 *
 * search the previous desces Event before insert.
 *
 * @see ptrFunc
 *
 * @param head list of event
 * @param searched destination event structure
 * @param insert input Event to search and get the previous
 */
void searchPreviousEventDesces(Event *head, Event **searched, Event *insert);

/**
 * callback function called by ptrFunc on searchEvent.
 *
 * search the previous mariage Event before insert.
 *
 * @see ptrFunc
 *
 * @param head list of event
 * @param searched destination event structure
 * @param insert input Event to search and get the previous
 */
void searchPreviousEventMariage(Event *head, Event **searched, Event *insert);

/**
 * callback function called by ptrFunc on searchEvent.
 *
 * search the previous birth Event before insert.
 *
 * @see ptrFunc
 *
 * @param head list of event
 * @param searched destination event structure
 * @param insert input Event to search and get the previous
 */
void searchPreviousEventBirth(Event *head, Event **searched, Event *insert);

/**
 * initialise the function pointers for displaying and searching previous event.
 *
 * @return allocate ptrFunc structure pointer
 */
ptrFunc* initPtrFunc(void);

/**
 * deallocate a ptrFunc structure given.
 *
 * @param f
 */
void freePtrFunc(ptrFunc** f);

/**
 * create and allocate an Event node.
 *
 * @param ptr pointer to the Event to allocate
 */
void createEvent(Event **ptr);

/**
 * free an Event given by adress.
 *
 * @param e adress of the Event to free
 */
void freeEvent(Event **e);

/**
 * display in console a list of event.
 *
 * @param head list of event to display
 * @param f function pointers structure to manage display.
 */
void displayListEvent(Event *head, ptrFunc *f);

/**
 * insert an Event node in a list of Event.
 *
 * @param head list of Event
 * @param insert Event to insert in the list
 * @param f function pointers structure to manage searching.
 */
void insertEventNode(Event **head, Event *insert, ptrFunc *f);

/**
 * remove cleanly an Event from a list of Event.
 *
 * @param head list of Event
 * @param toDelete Event to delte in the list
 * @param f function pointers structure to manage searching.
 */
void deleteEvent(Event **head, Event *toDelete, ptrFunc *f);
/**
 * delete all Event in a list of Event.
 *
 * @param head
 */
void deleteListOfEvent(Event **head);

/**
 * insert a mariage in a list of Event
 *
 * @param head list of Event
 * @param f function pointers structure to manage searching.
 * @param mariage informations about the mariage
 */
void insertMariage(Event **head, ptrFunc *f, list_mariage* mariage);

/**
 * insert a death in a list of Event
 *
 * @param head list of Event
 * @param f function pointers structure to manage searching.
 * @param individu informations about the individu
 */
void insertDeath(Event **head, ptrFunc *f, list_individu* individu);

/**
 * insert a birth in a list of Event
 *
 * @param head list of Event
 * @param f function pointers structure to manage searching.
 * @param individu informations about the individu
 */
void insertBirth(Event **head, ptrFunc *f, list_individu* individu);

#endif //FAMILYTREE_EVENT_H
