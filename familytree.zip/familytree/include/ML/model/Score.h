#ifndef FAMILYTREE_SCORE_H
#define FAMILYTREE_SCORE_H

#define MIN_AVERAGE_IN_SCORE 3

/**
 * @brief We use a scoring model
 *
 * More information : https://bit.ly/2ZTbxp6
 *
 * For the supervised algorithms , implement a scoring system
 * to choose the most probable event
 *
 * the goal is to use both supervised learning and reinforcement
 * learning by computing the model error and compute all the scores
 *
 * i.e : newComputedError > previousError ?
 *      Yes -> the model is "learning"
 *      No -> the model is "regressing"
 *
 */
typedef struct Score
{
    //Weight of an event is represented by 3 counters (for each events)
    int desces_counter, mariages_counter, births_counter;
    //array of Averages
    Average *arrayOfAverages;
    //number of average
    int numberOfAverage;
    /*
        Global standard error : https://fr.wikipedia.org/wiki/%C3%89cart_type
        so useful to compute the model error
    */
    float globalStandardError;
} Score;


/**
 * @brief create a score
 *
 * @param s
 */
void newScore(Score **s);

/**
 * @brief clear a score
 *
 * @param s
 */
void clearScore(Score **s);

/**
 * @brief compute the global standard error of all average
 *
 * @param s
 */
void computeScoreGlobalStandardError(Score *s);

/**
 * @brief print in the terminal a score
 *
 * This is a debug function
 *
 * @param s
 */
void printScore(Score *s);


void addAverageToScore(Score *s, Average *a);

void newAverageInScore(Score *s);

#endif //FAMILYTREE_SCORE_H
