#ifndef IA_H
#define IA_H

#define PATH_TO_DB "../assets/db/villes.db"

typedef enum error_ia {
    C1_MISSING,
    C2_MISSING,
    NOT_FOUND
} error_ia;

int estimatePlaceMariage(Place **searched, Model *m, type_event e, list_individu *c1, list_individu *c2);
Place estimatePLaceDesces(Model *m, char *name, char* surname, int generation);
Place estimatePLaceNaissance(Model *m, char *name, char* surname, int generation);

//que l'annee pour l'instant car les moyennes de jour et de mois ne sont pas faites
int estimateDateMariage(Model *m, type_event e, char *name, char* surname, int generation);
int estimateDateDesces(Model *m, type_event e, char *name, char* surname, int generation);
int estimateDateBirth(Model *m, type_event e, char *name, char* surname, int generation);

#endif //IA_H