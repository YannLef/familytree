#ifndef MODEL_H
#define MODEL_H

typedef struct Model {
    LIST *data; //head pointer
    int nbSets;
    float error;
    DataSet **sets;
} Model;

void initModel(Model **m, int nbSets);

void createModel(Model *m, LIST *data);

//parse form of map
void getPopulationFromModel(Population **searched, Model *m, char** formData, population_type type, int nbData);

void getFamilyPopulationFromModel(Population **searched, Model *m, char *familyName);
void getIndividuPopulationFromModel(Population **searched, Model *m, population_type type, char *name, char *lastname, int generation); 
void getGenerationPopulationFromModel(Population **searched, Model *m, int generation);

void displayModel(Model *m);

void computeModelError(Model *m);

void findPlaceMaxWeight(Place **searched, Model *m, population_type type);

void freeDataSetsInModel(Model *m);
void freeModel(Model **m);

#endif