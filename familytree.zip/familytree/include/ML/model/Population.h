#ifndef FAMILYTREE_POPULATION_H
#define FAMILYTREE_POPULATION_H

#define NB_PTR_FUNC_POPULATION_FROM 4

/**
 * @brief to classify the data we should use some label
 * this is named classification in Machine Learning
 *
 */
typedef enum population_type
{
    GENERATION = 0,
    FAMILY,
    I_ASC,
    I_DESC
} population_type;

/**
 * @brief define a population according to the model (a set of people)
 *
 * a population is the set of Places for :
 * - a person and his/her ancestors
 * - a person and his/her children
 * - a family
 * - a generation
 *
 */
typedef struct Population
{
    Place *historyOfPlaceFrequented;
    int nbPlace;
    /**
     * we know the globalScore for all places,
     * so this score could be useful too to compare different Population
     */
    float globalPopulationScore;
    //label for a population
    population_type typeOfPopulation;
} Population;

typedef void (*newPopulationFrom[NB_PTR_FUNC_POPULATION_FROM])(Population **p, LIST *start);
typedef struct ptrFuncPopulation {
    newPopulationFrom tab;
} ptrFuncPopulation;

ptrFuncPopulation* initPtrFuncPopulation(void);
void freePtrFuncPopulation(ptrFuncPopulation** f);

//[POPULATION_METHODS_BEGINING]

/**
 * @brief create a population dependings on the type
 *
 * @param p
 * @param type
 */
void newPopulation(Population **p, population_type type);

void newPopulationFromGeneration(Population **p, LIST *start);
void newPopulationFromIasc(Population **p, LIST *start);
void newPopulationFromIdesc(Population **p, LIST *start);
void newPopulationFromFamily(Population **p, LIST *start);

void callbackPopulationIdescFamily(Population **p, LIST *start);
void callbackAddMariageToPopulation(Population **p, SUBLIST* tmpMariage);

/**
 * @brief compute the global population score of the population
 *
 * to handle model error is benefit to compute all kind of error
 * to predict if thee model is learning or regressing
 *
 * @param p
 */
void computeGlobalPopulationScore(Population *p);

void insertIndividuInPopulation(Population *p, list_individu *i);
void insertMariageInPopulation(Population *p, list_mariage *m);

void freePopulation(Population **p);

void displayPopulation(Population *p);

float findAverageValueWithMinSatandardErrorInPlaceHistoric(Population *p, average_name aname);

/**
 * @brief save to a log file a population
 *
 * @param p
 * @param filename
 */
void savePopulation(Population *p, char *filename);

/**
 * @brief read from a log file a population
 *
 * @param p
 * @param filename
 */
void readPopulation(Population *p, char *filename);

#endif //FAMILYTREE_POPULATION_H
