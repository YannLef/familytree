#ifndef FAMILYTREE_COORDINATE_H
#define FAMILYTREE_COORDINATE_H

/**
 * @brief useful structure to define a geographical coodinate.
 *
 */
typedef struct Coordinate
{
    float latitude, longitude;
} Coordinate;

/**
 * @brief initialise a Coordonate structure from nothing
 *
 * @param c Coordinate structure
 * @param latitude
 * @param longitude
 */
void initCoordinate(Coordinate **c);

/**
 * @brief initialise a Coordonate structure
 *
 * @param c Coordinate structure
 * @param latitude
 * @param longitude
 */
void newCoordinate(Coordinate **c, float latitude, float longitude);

/**
 * @brief create a coordonate from a cityName based on a database
 *
 * i.e : send a command to sqlite3 in Villes.db and checkout the
 * returned coordinates
 *
 * @param c Coordinate structure
 * @param cityName
 * @return -1 if the system command fail
 */
int newCoordinateFromCityName(Coordinate **c, char *cityName, char *pathToDb);
int getCityNameFromCoordinate(Coordinate *c, char **cityNameFound, char *pathToDb);

/**
 * @brief print a COordinate in a terminal
 *
 * This is  a debug methods
 *
 * @param c
 */
void printCoordinate(Coordinate *c);

/**
 * @brief free a coordinate
 * 
 * @param c adress of the coordinate
 */
void freeCoordinate(Coordinate **c);

/**
 * @brief save a Coordinates to a text file
 *
 * Format : {lat:%f,lg:%f}
 *
 * @param c
 * @param filename
 */
void saveCoordinateToTextFile(Coordinate *c, char *filename);

/**
 * @brief read a Coordinate from a log text file
 *
 * Format : {lat:%f,lg:%f}
 *
 * @param c
 * @param filename
 */
void readCoordinateFromTextFile(Coordinate **c, char *filename);

#endif //FAMILYTREE_COORDINATE_H
