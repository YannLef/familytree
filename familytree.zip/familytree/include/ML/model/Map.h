#ifndef MAP_H
#define MAP_H

//[BEGIN_MAP_CONSTANTS]

//PIXElS

#define SIZE_SIDEBAR_X 620
#define WINDOW_WIDTH 1600
#define MAP_WIDTH 800
#define MAP_HEIGHT 800

//latitudes
#define MAP_FRANCE_LAT_A 51.23
#define MAP_FRANCE_LAT_B 51.445
#define MAP_FRANCE_LAT_C 41.465
#define MAP_FRANCE_LAT_D 41.28

//longitudes
#define MAP_FRANCE_LONG_A -5.14
#define MAP_FRANCE_LONG_B 9.03
#define MAP_FRANCE_LONG_C -5.032
#define MAP_FRANCE_LONG_D 8.613

//[END_MAP_CONSTANTS]

/**
 * a ------ b
 * |        |
 * |        |
 * c ------ d
 * 
 * ab = cd = ac = bd = 800
 * (origin for scale) c = (,) # size_sidebar_on_side + (size_container_of_map - ab)/2
 */

/**
 * apply the scale from latitude to pixel
 *
 * 
 * @param latitude
 * @return pixel value
 */
float latitudeToPixel(float latitude);

/**
 * apply the scale from longitude to pixel
 *
 * @param longitude
 * @return pixel value
 */
float longitudeToPixel(float longitude);

void displayPopulationOnMap(Population *p, type_event e, int minYear, int maxYear);

#endif //MAP_H
