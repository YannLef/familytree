#ifndef DATASET_H
#define DATASET_H

typedef struct DataSet {
    int nbPopulation;
    population_type type;
    PopulationList *listOfPopulation; //head of list
} DataSet;

void initDataSet(DataSet **d, population_type type);

void newDataSetFromDataList(DataSet **d, LIST *data, population_type type);

void displayDataSet(DataSet *d);

void freeDataSet(DataSet **d);

#endif //DATASET_H