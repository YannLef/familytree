#ifndef COMPONENTS_H
#define COMPONENTS_H

#define NB_POINTS_BOUND 200 //number of point created by a CircularArc
#define EPSILON_PIXEL 3     //just in case
#define PI 3.14159265358979323846264338327950288


#include "../../tools/linearRegression.h"

//TODO remove this structure when the IHM structure will be included
typedef struct Color
{
    int r, g, b;
} Color;

void newColor(Color *c, int r, int g, int b);

//[BEGIN_BOUNDED_RECTANGLE]

/**
 * @brief a GUI component to create bounded rectangle in the corners
 * 
 * r -> radius
 * x -> left bottom corner x position
 * y -> left bottom corner y position
 * w -> width
 * h -> height
 * t -> thickness
 */
typedef struct BoundedRectangle
{
    int r, x, y, w, h, t;
    Color *c;
} BoundedRectangle;

/**
 * @brief create a new Bounded rectangle structure
 * 
 * @param b Object
 * @param radius 
 * @param x 
 * @param y 
 * @param width 
 * @param height 
 * @param c color of line
 * @param t thickness
 */
void newBoundedRectangle(
    BoundedRectangle *b,
    int radius,
    int x,
    int y,
    int width,
    int height,
    Color *c,
    int t);

/**
 * @brief draw a bounded rectangle with GfxLib.h and glut.h
 * 
 * @param b reference
 */
void drawBoundedRectangle(BoundedRectangle *b);

/**
 * @brief draw a circular arc from theta_min to theta_min
 * 
 * @param x_origin 
 * @param y_origin 
 * @param radius 
 * @param theta_min 
 * @param theta_max 
 */
void drawCircularArc(
    int x_origin,
    int y_origin,
    int radius,
    float theta_min,
    float theta_max);

//[END_BOUNDED_RECTANGLE]

//[BEGIN_GRAPH_COMPONENT]

typedef struct Graph
{
    //see first project with the graph
    PointsCloud *data;
    BoundedRectangle *frame;
    int step;
    char *mainTitle;
    char *xAxisTitle;
    char *yAxisTitle;
    Color *colorOfPoints;
    Color *colorOfFrame;
    Color *colorOfLine;
} Graph;

void newGraph(
    Graph *g,
    BoundedRectangle *frame,
    PointsCloud *data,
    char *mainTitle,
    char *xAxisTitle,
    char *yAxisTitle,
    Color *cp,
    Color *fr,
    Color *li);

void drawGraph(Graph *g);

//[END_GRAPH_COMPONENT]

//[BEGIN_SLIDER_PICKER_COMPONENT]

/**
 * @brief create a line with nbOfData points on it and display each name of
 * points above each points
 * 
 * e.g : slider picker of years , onClik = dislay the Event concenrning the choosen year
 */
typedef struct sliderPicker
{
    char **dataDisplayed;
    int nbOfData;
    Color colorOfPoints, colorOfLine;
} sliderPicker;

//[END_SLIDER_PICKER_COMPONENT]

//[BUBBLE]


void displayIAMessage(BoundedRectangle* container, char* message);

//[END_BUBBLE]


#endif /* COMPONENTS_H */