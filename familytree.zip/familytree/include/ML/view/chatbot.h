#ifndef CHATBOT_H
#define CHATBOT_H

#define SEARCH_COMMAND "!search"
#define HELP_COMMAND "!help"

#define MAX_NB_RESPONSE 6

typedef enum search_type {PLACE, DATE} search_type;

typedef struct searchRequestData {
    search_type st;
    type_event et;
    char* name;
    char* surname;
    int generation;
} searchRequestData;

typedef enum query {SEARCH, HELP, NOT_A_COMMAND, MISSING_PARAM} query;

void displayWelcomeMessage(void);
void displayBotMessageFromQueryInTerminal(token input, searchRequestData** data);

void getChatBotMessageFromRequest(message* response, char* input, int* state, searchRequestData* data);

#endif //CHATBOT_H