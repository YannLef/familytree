#ifndef STR_PLIT_H
#define STR_SPLIT_H

/**
 * @brief 
 * 
 * @param file 
 * @param chaine 
 * @param catactere 
 */
void str_getmDataFile(dataFile **file, char *chaine, char *catactere);
/**
 * @brief 
 * 
 * @param nb_col 
 * @param chaine 
 * @param caractere 
 * @return char** 
 */
char** str_splitChaine(const int nb_col, char *chaine, char *caractere);

#endif /* STR_CREATE_LINE_CSV_H */