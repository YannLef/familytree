#ifndef STR_CREATE_LINE_CSV_H
#define STR_CREATE_LINE_CSV_H

/**
 * @brief 
 * 
 * @param data 
 * @param ptr 
 * @return char* 
 */
char* str_creatLineCSV(char **data, dataFile *ptr);

#endif /* STR_CREATE_LINE_CSV_H */