#ifndef STR_H
#define STR_H

/**
 * @brief 
 * 
 * @param caracetre 
 */
void convertCharMinuscule(char *caracetre);

/**
 * @brief 
 * 
 * @param chaine 
 * @return char* 
 */
char* str_modifyChaine(char *chaine);

/**
 * @brief 
 * 
 * @param begin 
 * @param size_char 
 * @return char* 
 */
char* str_memcpy(char *begin, const size_t size_char);

#endif /* STR_H */