#ifndef FILE_READ_CSV_H
#define FILE_READ_CSV_H

/**
 * @brief lit la premiere ligne du fichier CSV, initialise dataFile
 *      - determine -> nb_line
 *      - determine -> nb_column
 *      - sauvegarde le header du file CSV -> headerFile
 * @param f curseur du fichier
 * @param file -> dataFile structure
 * @param caractere -> char caractere pour split
 */
void readHeaderLineCSV(FILE *f, dataFile **file, char *caractere);

/**
 * @brief 
 * 
 * @param f curseur du fichier
 * @param file -> datafile structure
 * @param caractere -> char caractere pour split
 * @return char** decomposition de la ligne en fonction de nb_column (dataFile)
 */
char** readLineCSV(FILE *f, dataFile *file, char *caractere);

#endif /* FILE_READ_CSV_H */