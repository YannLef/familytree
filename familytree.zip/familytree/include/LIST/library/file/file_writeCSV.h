#ifndef FILE_WRITE_CSV_H
#define FILE_WRITE_CSV_H

/**
 * @brief ecrit dans le fichier le contenu d'un maillon de type LIST
 * 
 * @param f curseur du fichier
 * @param ptrMaillon maillon de la liste chainée qui va etre ecrit dans le fichier
 * @param ptrfunc data pour les pointeurs sur fonction
 * @param file dataFile structure
 */
void writeLineCSV(FILE *f,LIST **ptrMaillon, funcList *ptrfunc, dataFile *file);
/**
 * @brief: ecrit la derniere ligne dans le fichier le contenu d'un maillon de type LIST
 * 
 * @param f curseur du fichier
 * @param ptrMaillon maillon de la liste chainée qui va etre ecrit dans le fichier
 * @param ptrfunc data pour les pointeurs sur fonction
 * @param file dataFile structure
 */
void writeLastLineCSV(FILE *f,LIST **ptrMaillon, funcList *ptrfunc, dataFile *file);
/**
 * @brief ecrit la ligne de description du fichier CSV
 * 
 * @param f curseur du fichier
 * @param file dataFile structure
 */
void writeHeadLineCSV(FILE *f, dataFile *file);

#endif /* FILE_WRITE_CSV_H */