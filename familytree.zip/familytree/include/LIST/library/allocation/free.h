#ifndef FREE_H
#define FREE_H

/**
 * @param char char double dimension par passage par adresse
 * @param nbCol nombre de case alloué dans la 2 dim
 * 
 *  Free un char à double dimension
 **/
void free_charDoubleDim(char ***d, const int nbCol);

/**
 * @param chaine chaine de caractere
 * 
 *  Free un char à double dimension
 **/
void free_char(char **chaine);

#endif /* FREE_H */