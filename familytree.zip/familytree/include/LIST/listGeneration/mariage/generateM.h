/**
 * @brief 
 * 
 * @param f 
 * @param file 
 * @param nowNbLine 
 * @param ptrI_teteListe 
 * @param type 
 * @param func 
 * @return LIST* 
 */
LIST* initialiseListMariage(FILE *f, dataFile *file, int nowNbLine, LIST **ptrI_teteListe, type_list type, funcList *func);

/**
 * @brief 
 * 
 * @param file 
 * @param ptrTeteListe 
 * @param ptrI_teteListe 
 * @param type 
 * @param func 
 */
void LISTMARIAGE_generationListe(dataFile **file, LIST **ptrTeteListe, LIST **ptrI_teteListe, type_list type, funcList *func);