/**
 * @brief 
 * 
 * @param file 
 * @param ptrTeteListe 
 * @param ptrFunc 
 */
void saveListInCSV(dataFile *file, LIST **ptrTeteListe, funcList *ptrFunc);