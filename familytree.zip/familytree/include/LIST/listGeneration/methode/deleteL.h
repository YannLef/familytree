/**
 * @brief 
 * 
 * @param file 
 * @param ptrTeteListe 
 * @param ptrFunc 
 * @param funcSL 
 */
void deleteList(dataFile *file, LIST **ptrTeteListe, funcList *ptrFunc, funcSublist *funcSL);