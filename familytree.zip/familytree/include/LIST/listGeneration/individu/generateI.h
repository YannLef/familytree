/**
 * @brief 
 * 
 * @param f 
 * @param file 
 * @param nowNbLine 
 * @param type 
 * @param func 
 * @return LIST* 
 */
LIST* initialiseListIndividu(FILE *f, dataFile *file, int nowNbLine, const type_list type, funcList *func);

/**
 * @brief 
 * 
 * @param ptrTeteListe 
 * @param file 
 * @param type 
 * @param ptrFunc 
 */
void LISTINDIVIDU_generationListe(LIST **ptrTeteListe, dataFile **file, type_list type, funcList *ptrFunc);

/**
 * @brief 
 * 
 * @param file 
 * @param ptrTeteListe 
 * @param ptrFunc 
 */
void LISTINDIVIDU_writeFileCSV(dataFile *file, LIST **ptrTeteListe, funcList *ptrFunc);

