/**
 * @brief 
 * 
 * @param ptrHead 
 * @param maillon 
 * @param data 
 * @param func 
 */
void LISTMARIAGE_updateMaillon(LIST **ptrHeadM, LIST **ptrHeadI, LIST *maillon, char ***data, funcSublist *func);