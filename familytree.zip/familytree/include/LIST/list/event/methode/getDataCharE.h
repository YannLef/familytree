#ifndef GET_DATA_CHAR_E_H
#define GET_DATA_CHAR_E_H




#endif /* GET_DATA_CHAR_E_H */