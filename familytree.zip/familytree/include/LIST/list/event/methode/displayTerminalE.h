#ifndef DISPLAY_TERMINAL_E_H
#define DISPLAY_TERMINAL_E_H

/**
 * @brief display a list of event in terminal
 * 
 * debug function
 * 
 * @param head head pointer of list
 */
void displayListEvent(LIST *head);

#endif /* DISPLAY_TERMINAL_E_H */