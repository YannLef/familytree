/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @param data 
 * @param type 
 */
void LISTINDIVIDU_insertGeneration(LIST **ptrMaillon, char *data);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @param data 
 * @param type 
 */
void LISTINDIVIDU_insertGenerationSupplementaire(LIST **ptrMaillon, char *data);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @param data 
 * @param type 
 */
void LISTINDIVIDU_insertNom(LIST **ptrMaillon, char *data);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @param data 
 * @param type 
 */
void LISTINDIVIDU_insertPrenom(LIST **ptrMaillon, char *data);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @param data 
 * @param type 
 */
void LISTINDIVIDU_insertGenre(LIST **ptrMaillon, char *data);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @param data 
 * @param type 
 */
void LISTINDIVIDU_insertDateNaissance(LIST **ptrMaillon, char *data);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @param data 
 * @param type 
 */
void LISTINDIVIDU_insertDateDeces(LIST **ptrMaillon, char *data);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @param data 
 * @param type 
 */
void LISTINDIVIDU_insertLieuNaissance(LIST **ptrMaillon, char *data);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @param data 
 * @param type 
 */
void LISTINDIVIDU_insertLieuDeces(LIST **ptrMaillon, char *data);