/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTINDIVIDU_getDataCharGeneration(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTINDIVIDU_getDataCharNom(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTINDIVIDU_getDataCharPrenom(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTINDIVIDU_getDataCharGenre(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTINDIVIDU_getDataCharLieuNaissance(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTINDIVIDU_getDataCharLieuDeces(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTINDIVIDU_getDataCharC1Nom(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTINDIVIDU_getDataCharC1Prenom(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTINDIVIDU_getDataCharC2Nom(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTINDIVIDU_getDataCharC2Prenom(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTINDIVIDU_getDataCharDateNaissance(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTINDIVIDU_getDataCharDateDeces(LIST *ptrMaillon);