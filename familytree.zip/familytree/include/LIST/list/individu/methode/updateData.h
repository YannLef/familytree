/**
 * @brief 
 * 
 * @param ptr 
 * @param data 
 */
void LISTINDIVIDU_updateGeneration(LIST **ptr, char *data);

void LISTINDIVIDU_updateNom(LIST **ptr, char *data);

void LISTINDIVIDU_updatePrenom(LIST **ptr, char *data);

void LISTINDIVIDU_updateGenre(LIST **ptr, char *data);

void LISTINDIVIDU_updateLieuNaissance(LIST **ptr, char *data);

void LISTINDIVIDU_updateLieuDeces(LIST **ptr, char *data);

void LISTINDIVIDU_updateDateNaissance(LIST **ptr, char *data);

void LISTINDIVIDU_updateDateDeces(LIST **ptr, char *data);

void LISTINDIVIDU_updateConjoint(LIST **ptrHead, LIST **maillon, funcSublist *func, char **data);