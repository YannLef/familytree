/**
 * @brief 
 * 
 * @param ptrTeteListe 
 * @param ptrIndividu 
 * @param nom 
 * @param prenom 
 * @param data 
 */
void LISTINDIVIDU_searchIndividuParent(LIST *ptrTeteListe, LIST **ptrIndividu, const int generation, char *nom, char *prenom);
/**
 * @brief 
 * 
 * @param ptrTeteListe 
 * @param ptrIndividu 
 * @param generation 
 * @param nom 
 * @param prenom 
 * @param data 
 */
void LISTINDIVIDU_searchIndividu(LIST *ptrTeteListe, LIST **ptrIndividu,const int generation, char *nom, char *prenom);
/**
 * @brief 
 * 
 * @param ptrTeteListe 
 * @param ptrIndividu 
 * @param parent 
 */
void LISTINDIVIDU_searchGeneration(LIST *ptrTeteListe, LIST **ptrIndividu, LIST *parent);

/**
 * @brief 
 * 
 * @param ptrHead 
 * @param precedent 
 * @param delete 
 */
void LISTINDIVIDU_searchIndividuMaillon(LIST *ptrHead, LIST **precedent, LIST *delete);