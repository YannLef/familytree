/**
 * @brief 
 * 
 * @param ptr 
 * @return int 
 */
int LISTINDIVIDU_compteNbMaillon(LIST *ptr); 