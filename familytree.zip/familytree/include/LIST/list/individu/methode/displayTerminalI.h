/**
 * @brief 
 * 
 * @param ptrTete 
 */
void displayListIndividu(LIST *ptrTete);