/**
 * @param :
 *      - ptrTeteList -> maillon individu
 * 
 *  alloue un maillon de type individu
 **/
void LISTINDIVIDU_createMaillon(LIST **ptrMaillon);

/**
 * @param :
 *      - ptrTeteList -> maillon individu
 * 
 *  alloue la data d'un maillon de type individu
 **/
void LISTINDIVIDU_creatDescription(LIST **ptrMaillon);

/**
 *  @param :
 *      - insert -> nouveau maillon à inserer
 *      - ptrTeteList -> tete de liste
 *      - ptrFunc -> pointeur sur les fonctions necessaire en fonction du type de la structure
 * 
 *  permet d'inser le nouveau maillon celon les caracteristique choisi defini lors du search maillon
 **/
void LISTINDIVIDU_insertMaillonHeader(LIST *insert, LIST **ptrTeteList);

/**
 * @brief Insert la data dans le maillon specifié
 * 
 * @param ptrMaillon maillon dans lequel on doit lui inserer la data
 * @param data donnée a mettre dans le maillon
 */
void LISTINDIVIDU_insertData(LIST **ptrMaillon, char **data);

/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @param data 
 * @param nom 
 * @param prenom 
 */
void LISTINDIVIDU_insertDataNameSurNameGeneration(LIST **ptrMaillon, char **data, const int nom, const int prenom, int nbParent);
/**
 * @brief alloue un maillon directement de type individu avec allocation LIST, list_description 
 *        et list_individu
 * 
 * @param ptrMaillon maillon à allouer
 */
void LISTINDIVIDU_create(LIST **ptrMaillon);

/**
 * @brief insert Insert le maillon dans la liste a l'endroit necessaire -> en fonction de la génération
 * 
 * @param insert 
 * @param ptrTeteList 
 */
void LISTINDIVIDU_insertMaillon(LIST **insert, LIST **ptrTeteList);

/**
 * @brief Crée les liens de Parenté - Enfant du maillon en question ptrMaillon
 * 
 * @param ptrMaillon 
 * @param ptrIndividu 
 * @param data 
 * @param nom 
 * @param prenom 
 * @param nbParent 
 */
void LISTINDIVIDU_creatLinkParent(LIST *ptrMaillon, LIST **ptrIndividu, char **data, const int nom, const int prenom, const int nbParent);

/**
 * @brief free l'allocation de list_description individu
 * 
 * @param ptrMaillon 
 */
void LISTINDIVIDU_freeDescription(LIST **ptrMaillon);

/**
 * @brief Free l'allocation list_individu
 * 
 * @param ptrMaillon -> maillon courant
 * @param func_SUBLIST -> pointeur fonction pour sublist
 */
void LISTINDIVIDU_freeMaillon(LIST **ptrMaillon, funcSublist *func_SUBLIST);

/**
 * @brief 
 * 
 * @param next 
 * @param ptrMaillon 
 */
void LISTINDIVIDU_getNextMaillon(LIST **next, LIST *ptrMaillon);

/**
 * @brief 
 * 
 * @param delete 
 * @param ptrHead 
 */
void LISTINDIVIDU_deleteMaillon(LIST **delete, LIST **ptrHead);