/**
 * @brief 
 * 
 * @param ptrMaillon 
 */
void LISTMARIAGE_createMaillon(LIST **ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 */
void LISTMARIAGE_creatDescription(LIST **ptrMaillon);
/**
 * @brief 
 * 
 * @param insert 
 * @param ptrTeteList 
 */
void LISTMARIAGE_insertMaillonHeader(LIST *insert, LIST **ptrTeteList);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @param data 
 */
void LISTMARIAGE_insertData(LIST **ptrMaillon, char **data);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @param ptrIndividu 
 * @param data 
 * @param generation 
 * @param nom 
 * @param prenom 
 * @param dateNaissance 
 * @param lieuNaissance 
 * @param nbConjoint 
 */
void LISTMARIAGE_creationLink(LIST *ptrMaillon, LIST **ptrIndividu, char **data, const int generation, const int nom, const int prenom, const int dateNaissance, const int lieuNaissance, const int nbConjoint);

/**
 * @brief 
 * 
 * @param ptrMaillon 
 */
void LISTMARIAGE_freeDescription(LIST **ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 */
void LISTMARIAGE_freeMaillon(LIST **ptrMaillon, funcSublist *func_SUBLIST);

/**
 * @brief 
 * 
 * @param next 
 * @param ptrMaillon 
 */
void LISTMARIAGE_getNextMaillon(LIST **next, LIST *ptrMaillon);

/**
 * @brief 
 * 
 * @param insert 
 * @param ptrTeteList 
 */
void LISTMARIAGE_insertMaillon(LIST *insert, LIST **ptrTeteList);

/**
 * @brief 
 * 
 * @param delete 
 * @param ptrHead 
 */
void LISTMARAIGE_deleteMaillon(LIST **delete, LIST **ptrHead);