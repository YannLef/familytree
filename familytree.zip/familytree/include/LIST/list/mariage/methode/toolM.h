/**
 * @brief 
 * 
 * @param ptr 
 * @return int 
 */
int LISTMARIAGE_compteNbMaillon(LIST *ptr);