/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @param data 
 * @param type 
 */
void LISTMARIAGE_insertDataDate(LIST **ptrMaillon, char *data);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @param data 
 * @param type 
 */
void LISTMARIAGE_insertDataLieu(LIST **ptrMaillon, char *data);