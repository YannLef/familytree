/**
 * @brief 
 * 
 * @param ptrTete 
 */
void displayListMariage(LIST *ptrTete);