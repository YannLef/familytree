/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTMARIAGE_getDataCharGenerationI(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTMARIAGE_getDataCharNomI(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTMARIAGE_getDataCharPrenomI(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTMARIAGE_getDataCharDateNaissanceI(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTMARIAGE_getDataCharLieuNaissanceI(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTMARIAGE_getDataCharGenerationII(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTMARIAGE_getDataCharNomII(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTMARIAGE_getDataCharPrenomII(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTMARIAGE_getDataCharDateNaissanceII(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTMARIAGE_getDataCharLieuNaissanceII(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTMARIAGE_getDataCharDateMariage(LIST *ptrMaillon);
/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @return char* 
 */
char* LISTMARIAGE_getDataCharLieuMariage(LIST *ptrMaillon);