/**
 * @brief 
 * 
 * @param ptrHead 
 * @param precedent 
 * @param insert 
 */
void LISTMARIAGE_searchMaillonDateMariage(LIST *ptrHead, LIST **precedent, LIST *insert);

/**
 * @brief 
 * 
 * @param ptrHead 
 * @param precedent 
 * @param insert 
 */
void LISTMARIAGE_searchMaillonSetDateMariage(LIST *ptrHead, LIST **precedent, LIST *insert);