/**
 * @brief 
 * 
 * @param maillon 
 * @param data 
 */
void LISTMARIAGE_updateLieuMariage(LIST **maillon, char *data);

/**
 * @brief 
 * 
 * @param maillon 
 * @param data 
 */
void LISTMARIAGE_updateDateMariage(LIST **maillon, char *data);

/**
 * @brief 
 * 
 * @param ptrHead 
 * @param maillon 
 * @param data 
 * @param func 
 */
void LISTMARIAGE_updateConjoint(LIST **ptrHead, LIST **maillon, char **data, funcSublist *func);