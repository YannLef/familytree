/**
 * @brief 
 * 
 * @param ptr 
 */
void ptrFunctionInddividu(funcList **ptr);

/**
 * @brief 
 * 
 * @param ptr 
 */
void ptrFunctionMariage(funcList **ptr);

/**
 * @brief 
 * 
 * @param ptr 
 */
void free_ptrFunctionIndividu(funcList **ptr);

/**
 * @brief 
 * 
 * @param ptr 
 */
void free_ptrFunctionMariage(funcList **ptr);