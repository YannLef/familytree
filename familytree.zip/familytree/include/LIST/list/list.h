/**
 * @brief alloue un maillon LIST et lui insert le type de maillon
 * 
 * @param ptrMaillon -> maillon à malloc
 * @param type -> type du maillon type_listIndividu, type_listMariage
 * @param func -> pointeur de fonction Liste
 */
void LIST_creatMaillon(LIST **ptrMaillon, type_list type, funcList *func);

/**
 * @brief insertion de la donnée dans la partie description de la Liste
 * 
 * @param ptrMaillon -> maillon 
 * @param data -> donnée à inserer
 * @param func -> pointeur de fonction Liste
 */
void LIST_insertData(LIST **ptrMaillon, char **data, funcList *func);

/**
 * @brief 
 * 
 * @param insert 
 * @param ptrListHead 
 * @param func 
 */
void LIST_insertMaillon(LIST *insert, LIST **ptrListHead, funcList *func);

/**
 * @brief 
 * 
 * @param data 
 * @param ptrMaillon 
 * @param func 
 * @param file 
 */
void LIST_getCharData(char ***data, LIST *ptrMaillon, funcList *func, dataFile *file);

/**
 * @brief 
 * 
 * @param ptrFunction 
 */
void LIST_pointeurFunction(funcList **ptrFunction);

/**
 * @brief 
 * 
 * @param next 
 * @param ptrMaillon 
 * @param ptrFunc 
 */
void LIST_getNexMaillon(LIST **next, LIST *ptrMaillon, funcList *ptrFunc);

/**
 * @brief 
 * 
 * @param ptrFunction 
 */
void LIST_freePointeurFonction(funcList **ptrFunction);