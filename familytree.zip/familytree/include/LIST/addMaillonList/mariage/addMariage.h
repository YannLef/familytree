/**
 * @brief ajout un mariage à la liste mariage et applique la meme 
 *        procedure que addINDIVIDULISTMARIAGE
 * 
 * @param MaillonMariage 
 * @param ptrHead 
 * @param func 
 * @param funcSL 
 */
void addMariageListMariage(char ***maillonMariage, LIST **ptrHeadM, LIST **ptrHeadI, funcList *func, funcSUBLIST *funcSL);