/**
 * @brief insertion d'un nouvelle individu dans la liste INDVIDU
 *        gere automatique les liens des parents et sublist des parents
 *        gere s'il faut generer un parent ou completer un parent
 * 
 * @param MaillonIndividu 
 * @param ptrHead 
 * @param func 
 */
void addIndividuListIndividu(char ***MaillonIndividu, LIST **ptrHead, funcList *func);