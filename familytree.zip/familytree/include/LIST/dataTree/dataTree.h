#ifndef DATA_TREE_H
#define DATA_TREE_H

/**
 * @brief allocation de la structure dataList
 *      - nb_row = 0
 *      - nb_column = 0
 *      - fileName = NULL
 *      - headerFile = NULL
 * 
 * @return dataList* 
 */
dataFile* DATAFILE_create(void);

#endif /* DATA_TREE_H */

