/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @param sublistType 
 * @param ptrFunc_subList 
 */
void SUBLIST_create(SUBLIST **ptrMaillon, type_sublist sublistType,funcSublist *ptrFunc_subList);

/**
 * @brief 
 * 
 * @param ptr 
 * @param ptrMaillon_I 
 * @param ptrFunc_subList 
 */
void SUBLIST_insertData(SUBLIST **ptr, LIST *ptrMaillon_I, funcSublist *ptrFunc_subList);

/**
 * @brief 
 * 
 * @param ptr 
 * @param individuParent 
 * @param ptrFunc_subList 
 */
void SUBLIST_insertMaillon(SUBLIST **ptr, LIST **individuParent, funcSublist *ptrFunc_subList);

/**
 * @brief 
 * 
 * @param ptrFunction 
 */
void SUBLIST_pointeurFunction(funcSublist **ptrFunction);

/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @param ptrFunc_subList 
 */
void SUBLIST_free(SUBLIST **ptrMaillon, funcSublist *ptrFunc_subList);

/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @param ptrFunc_subList 
 */
void SUBLIST_deleteAll(SUBLIST **ptrMaillon, funcSublist *ptrFunc_subList);

/**
 * @brief 
 * 
 * @param ptrFunction 
 */
void SUBLIST_freePointeurFunction(funcSublist **ptrFunction);