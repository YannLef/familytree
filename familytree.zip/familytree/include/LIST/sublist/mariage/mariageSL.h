/**
 * @brief 
 * 
 * @param ptrMaillon 
 */
void SUBLISTMARIAGE_create(SUBLIST **ptrMaillon);

/**
 * @brief 
 * 
 * @param ptrMaillon 
 */
void SUBLISTMARIAGE_creatMaillon(SUBLIST **ptrMaillon);

/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @param ptr_mariage 
 */
void SUBLISTMARIAGE_insertData(SUBLIST **ptrMaillon, LIST *ptr_mariage);

/**
 * @brief 
 * 
 * @param insert 
 * @param ptrI_teteListe 
 */
void SUBLISTMARIAGE_insertMaillon(SUBLIST *insert, LIST **ptrI_teteListe);

/**
 * @brief 
 * 
 * @param ptrMaillon 
 */
void SUBLISTMARIAGE_freeMaillon(SUBLIST **ptrMaillon);

/**
 * @brief Construct a new sublistmariage getnextmaillon object
 * 
 * @param nextMaillon 
 * @param ptrMaillon 
 */
void SUBLISTMARIAGE_getNextMaillon(SUBLIST **nextMaillon, SUBLIST *ptrMaillon);

/**
 * @brief 
 * 
 * @param ptrHead 
 * @param maillonDelete 
 * @param mariage 
 */
void SUBLISTMARAIGE_deleteMaillon(SUBLIST **ptrHead, SUBLIST **maillonDelete, LIST *mariage);