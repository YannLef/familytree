/**
 * @brief 
 * 
 * @param ptrHead 
 * @param maillon 
 * @param precedent 
 * @param delete 
 */
void SUBLISTMARIAGE_searchMaillon(SUBLIST *ptrHead, LIST *maillon, SUBLIST **precedent, SUBLIST **delete);