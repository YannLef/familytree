/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @param ptrFunc_subList 
 */
void SUBLIST_deleteAll(SUBLIST **ptrMaillon, funcSublist *ptrFunc_subList);