/**
 * @brief 
 * 
 * @param ptr 
 */
void SUBLIST_ptrFunctionInddividu(funcSublist **ptr);

/**
 * @brief 
 * 
 * @param ptr 
 */
void SUBLIST_ptrFunctionMariage(funcSublist **ptr);