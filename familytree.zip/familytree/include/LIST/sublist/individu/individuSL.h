/**
 * @brief 
 * 
 * @param ptrMaillon 
 */
void SUBLISTINDIVIDU_create(SUBLIST **ptrMaillon);

/**
 * @brief 
 * 
 * @param ptrMaillon 
 */
void SUBLISTINDIVIDU_creatMaillon(SUBLIST **ptrMaillon);

/**
 * @brief 
 * 
 * @param ptrMaillon 
 * @param ptr_individu 
 */
void SUBLISTINDIVIDU_insertData(SUBLIST **ptrMaillon, LIST *ptr_individu);

/**
 * @brief 
 * 
 * @param insert 
 * @param ptrI_teteListe 
 */
void SUBLISTINDIVIDU_insertMaillon(SUBLIST *insert, LIST **ptrI_teteListe);

/**
 * @brief 
 * 
 * @param ptrMaillon 
 */
void SUBLISTINDIVIDU_freeMaillon(SUBLIST **ptrMaillon);

/**
 * @brief
 * 
 * @param nextMaillon 
 * @param ptrMaillon 
 */
void SUBLISTINDIVIDU_getNextMaillon(SUBLIST **nextMaillon, SUBLIST *ptrMaillon);

/**
 * @brief 
 * 
 * @param ptrHead 
 * @param maillonDelete 
 * @param individu 
 */
void SUBLICTINDIVIDU_delateMaillon(SUBLIST **ptrHead, SUBLIST **maillonDelete, LIST *individu);

/**
 * @brief 
 * 
 * @param insert 
 * @param ptrHead 
 */
void SUBLISTINDIVIDU_insertMaillonSubList(SUBLIST **insert, SUBLIST **ptrHead);
