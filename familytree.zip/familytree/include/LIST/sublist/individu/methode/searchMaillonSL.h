/**
 * @brief retrouve le maillon precdent du maillon a supprimer dans la sublist individu
 *        trouver grace a une comparaison arithmetique de pointeur
 * 
 * @param ptrHead 
 * @param maillon 
 * @param precedent 
 */
void SUBLISTINDIVIDU_searchMaillonIndividu(SUBLIST *ptrHead, LIST *maillon, SUBLIST **precedent, SUBLIST **delete);