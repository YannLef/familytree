#ifndef STRUCTURE_H
#define STRUCTURE_H

typedef enum type_month
{
    JANVIER,
    FEVRIER,
    MARS,
    AVRIL,
    MAI,
    JUIN,
    JUILLET,
    AOUT,
    SEPTEMBRE,
    OCTOBRE,
    NOVEMBRE,
    DECEMBRE
} type_month;

typedef enum type_list
{
    type_listMariage,
    type_listIndividu
} type_list;

typedef enum type_sublist
{
    type_sublistMariage,
    type_sublistIndividu
} type_sublist;

typedef enum descriptionTypeI
{
    generationI,
    nomI,
    prenomI,
    genreI,
    naissanceDateI,
    naissanceLieuI,
    decesDateI,
    decesLieuI,
    nomParent1I,
    prenomParent1I,
    nomParent2I,
    prenomParent2I
} descriptionTypeI;

typedef enum descriptionTypeM
{
    generation1,
    nom1,
    prenom1,
    naissanceDate1,
    naissanceLieu1,
    generation2,
    nom2,
    prenom2,
    naissanceDate2,
    naissanceLieu2,
    dateMariage,
    lieuMariage
} descriptionTypeM;

typedef enum data_type
{
    INT,
    FLOAT,
    CHAR,
    SHORT,
    DOUBLE
} data_type;

typedef struct LIST_descriptionIndividu list_descriptionIndividu;
typedef struct LIST_descriptionMariage list_descriptionMariage;

typedef struct LIST_mariage list_mariage;
typedef struct LIST_individu list_individu;
typedef struct LIST LIST;

typedef struct SUBLIST_individu sublist_individu;
typedef struct SUBLIST_mariage sublist_mariage;
typedef struct SUBLIST SUBLIST;

typedef struct M_date m_date;

typedef struct DATA DATA;

typedef struct LIST_tool LIST_tool;

struct DATA
{
    data_type type;
    union {
        int _int;
        float _float;
        char *_char;
        short _short;
    } u;
};

struct M_date
{
    int jour;
    int moi;
    int annee;
};

struct SUBLIST_individu
{
    SUBLIST *suivant;
    LIST *individu;
};

struct SUBLIST_mariage
{
    SUBLIST *suivant;
    LIST *mariage;
};

struct SUBLIST
{
    enum type_sublist type;
    union {
        sublist_individu *sublist_I;
        sublist_mariage *sublist_M;
    } u;
};

struct LIST_descriptionIndividu
{
    char *genre;
    m_date *naissance;
    m_date *deces;
    char *lieuNaissance;
    char *lieuDeces;
    char *nom;
    char *prenom;
    int generation;
};

struct LIST_individu
{
    list_descriptionIndividu *data;
    LIST *suivant;
    LIST *c1, *c2;
    SUBLIST *sublistIndividu;
    SUBLIST *sublistMariage;
};

struct LIST_descriptionMariage
{
    char *lieu;
    m_date *date;
};

struct LIST_mariage
{
    list_descriptionMariage *data;
    LIST *suivant;
    LIST *c1, *c2;
};

struct LIST
{
    enum type_list type;
    union {
        list_individu *list_individu;
        list_mariage *list_mariage;
    } u;
};

struct dataFile
{
    char *fileName;
    char *headerFile;
    int nb_column;
    int nb_row;
};

typedef struct dataFile dataFile;

struct toolList
{
    int nb_generation;
    int *tabNbMaxChild;
    SUBLIST *individu; //raccourci vers les le moillon d'en-tete de chaque generation
};

typedef struct toolList toolList;

struct dataList
{
    LIST *headList;
    toolList *individu;
    dataFile *file;
};

typedef struct dataList dataList;

struct mDataTree
{
    char *wayAcces;
    dataList *individu;
    dataList *mariage;
};

typedef struct mDataTree mDataTree;

#define NB_POINTEURFUNCTION 2 //Individu, Mariage, Event, Place
#define NB_POINTEURFUNCTION_SUBLIST 2
#define NB_FONCTIONDESC_I 7
#define NB_FONCTIONDESC_M 2

typedef struct ptrFunctSUBLIST funcSublist;
typedef struct ptrFunctLIST funcList;

typedef void (*createMaillonType)(LIST **ptrMaillon);
typedef void (*createMaillonDescription)(LIST **ptrMaillon);
typedef void (*insertMaillonHeader)(LIST *insert, LIST **ptrTeteList);
typedef void (*insertMaillonData)(LIST **ptrMaillon, char **data);
typedef void (*insertDataDescription)(LIST **ptrMaillon, char **data, const int type);
typedef char *(*getDataChar)(LIST *ptrMaillon);
typedef void (*ptrListFuncSL)(LIST **ptrMaillon, funcSublist *func_SUBLIST);
typedef void (*ptrGetNextMaillonL)(LIST **next, LIST *ptrMailon);

struct ptrFunctLIST
{
    createMaillonType maillon[NB_POINTEURFUNCTION];
    createMaillonDescription maillonDesc[NB_POINTEURFUNCTION];
    insertMaillonHeader insertMaillonHead[NB_POINTEURFUNCTION];
    insertMaillonData insertData[NB_POINTEURFUNCTION];
    getDataChar *getData[NB_POINTEURFUNCTION];
    createMaillonType freeDescription[NB_POINTEURFUNCTION];
    ptrListFuncSL freeMaillon[NB_POINTEURFUNCTION];
    ptrGetNextMaillonL getNextMaillon[NB_POINTEURFUNCTION];
};

typedef void (*ptrSubListType)(SUBLIST **ptrMaillon);
typedef void (*ptrSubListCreate)(SUBLIST **ptrMaillon, type_sublist sublistType);
typedef void (*ptrInsertData)(SUBLIST **ptrMaillon, LIST *ptr_individu);
typedef void (*ptrInsertMaillon)(SUBLIST *insert, LIST **ptrI_teteListe);
typedef void (*ptrFreeMailon)(SUBLIST **ptr);
typedef void (*ptrGetNextMaillon)(SUBLIST **nextMaillon, SUBLIST *ptrMaillon);

struct ptrFunctSUBLIST
{
    ptrSubListType tabSublistType[NB_POINTEURFUNCTION_SUBLIST];
    ptrInsertData tabInsertData[NB_POINTEURFUNCTION_SUBLIST];
    ptrInsertMaillon tabInsertMaillon[NB_POINTEURFUNCTION_SUBLIST];
    ptrFreeMailon tabFreeMaillon[NB_POINTEURFUNCTION_SUBLIST];
    ptrGetNextMaillon getNextMaillon[NB_POINTEURFUNCTION_SUBLIST];
};

typedef struct ptrFunctSUBLIST funcSUBLIST;

#endif /* STRUCTURE_H */