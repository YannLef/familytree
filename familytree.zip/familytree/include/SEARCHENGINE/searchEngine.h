/**
 * @brief 
 * 
 * @param data 
 * @param ptrHead 
 * @param func 
 * @return SUBLIST* 
 */
SUBLIST* SEARCHENGINE_searchIndividu(char ***data, LIST *ptrHead, funcSublist *func);

m_date* splitDate(char *data);

int SEARCHENGINE_determineNombreParametre(char **data);