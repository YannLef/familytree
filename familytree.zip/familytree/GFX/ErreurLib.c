#include "ErreurLib.h"

const char *ChaineErreurLisEntier = "La valeur entree n'est pas de type entier. Veuillez recommencer SVP : ";
const char *ChaineErreurLisFlottant = "La valeur entree n'est pas de type flottant. Veuillez recommencer SVP : ";
const char *ChaineErreurLisCaractere = "La valeur entree n'est pas de type caractere. Veuillez recommencer SVP : ";
