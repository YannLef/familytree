# DEVELOPMENT SPECIFICATIONS

## Introduction

Consider this file as a **reference** to keep **organized** and **efficient** your code in this project.

To **read** this file fluently, go on the **main page of the git repository**.

## Summary

1. File organisation
2. Documentation
3. code specification
4. Unit testing
5. Git
6. EDI configuration
   1. Geany
   2. Vs code
7. Build system
   1. Makefile
   2. Cmake
   
### 1. File organisation

#### File tree structure

```
project/
├── assets/
│   ├── csv/
|   |     *all csv file here*
│   ├── img/
|   |    *all images here*
|   ├── icons/
|   |    *all icons here*
│   └── db/ 
|        *all databases here*
├── GFX/
|        *GfxLib .c files here*
├── include/
|   ├── LIST/
|   |   └── *all .h for linkedList management*
|   |       
│   ├── ML/
|   |   └── model/
|   |       ├── view/
|   |       ├── controller/
|   |       └── tools/
│   └── IHM/
|       └── *all .h for the IHM*
├── src/
│   ├── LIST/
|   |   └── *all .h for linkedList management*
|   |       
│   ├── ML/
|   |   └── model/
|   |       ├── view/
|   |       ├── controller/
|   |       └── tools/
│   └── IHM/
|       └── *all .c for the IHM*
├── test/
|   ├── minunit/
|   |   └── *minunit unit test framework*
│   ├── LIST/
|   |   └── *all your test files*
|   |       
│   ├── ML/
|   |   └── *all test files for Machine Learning*
|   |
│   └── IHM/
|       └── *all test files for IHM*
|   .gitignore
|   main.c //entry point of the main program
|   CMakeList.txt (or makefile)
|   readme.md

```

useful command to generate tree in terminal :

```
    sudo apt install tree
    tree
```

### 2. Documentation

- **The documentation will be generated with doxygen**
- **Have a look on what kind of documentation blocks you can add**
- **Place your documentation blocks in *'header files' (.h)* only !**
- **For complexe algorithm you must comments every statement of your code**
  
- **To separate different part of your header files, follow the template below**

```
//[MODULE_NAME_BEGIN]
    
    /* place your code for the specific module here */

//[MODULE_NAME_END]
```

- **Use** ```//TODO your task``` **block to indicate to the team what need to be done yet**

- **don't hesitate to create a file** ```info.md``` **like this one to explain some components of your module to the others**

#### concerning unit testing ####

- your file must have a name like ```moduleToBeTested_test.c```
      

### 3. Code specifiation

#### General specifiation

- **Every headers file must start with :**

```c
    #ifndef HEADER_NAME_H
    #define HEADER_NAME_H

    /* Place your code here */

    #endif /* HEADER_NAME_H */
```
- **You should use a code beautifier**

#### Object Oriented syntax explanation used in ML module

- **An object is a simple structure**
- **The first parameter of every methods (functions) related to a structure (class) must be a pointer to the Object**
- **Every structure name must start with a Capital letter**
- **to initialize a structure (object) name your methods like :**

```c
    void newYourObjectName(ObjectName* o, ...);
```

- **to free attributs of your object, name your methods like :**

```c
    void clearYourObjectName(ObjectName* o);
```
### 4. Unit testing

#### install the framework or use it

- You can find the framework in ```tests/minunit```.
  
- Link to the framework : https://github.com/siu/minunit

- install the framework :

```
cd path/to/your/directory
checkout https://github.com/siu/minunit.git
```

#### create your test ###

**see** ```tests/minunit/minunit_example.c```

- include the header of the framework :

```c
    #include "minunit/minunit.h"
```

- declare your variable after as ```static```

- write this two functions :

```c
    void test_setup(void) {
        /* 
            -this function is called before each test 
            -intialize your variables here
        */
    }

    void test_teardown(void) {
        /* 
            -Called after each test
            -useful to free your variable
        */
    }
```

- write a test :

```c
    MU_TEST(shouldDoSomething){
        /*
            - call your function for doSomething
            - test the output with an expected resul
             -all assert are available in minunit.h

            e.g : 
                test for : int addition(int a,int b);

                int result = addition(5, 4);
                mu_assert_int_eq("9", result); //expected : 9

                in this example, name your test :
                "shouldAddToPositiveNumbers"
        */
    }
```

- write a suit of test :

```c
    MU_TEST_SUITE(test_suite) {
        MU_SUITE_CONFIGURE(&test_setup, &test_teardown);

        /*
            call all your test with : MU_RUN_TEST(test_name)

            e.g : 
                MU_RUN_TEST(shouldDoSomething)
        */

        MU_RUN_TEST(test_fail);
    }
```

- main function :

```c
    int main(int argc, char *argv[]) {
        MU_RUN_SUITE(your_test_suite); //you can create more than one test suite
        MU_REPORT();

        return 0;
    }
```
### 5. Git

- **Gitkraken is a good choice to avoid mistake**

- useful command :

check what's going on

```
    git status
```

list all commit on your branch

```
    git log
```

list branches

```
    git branch
```
new branch for current branch
```
    git branch your_branch_name
```
add all files to the versionning
```
    git add .
```
commit modifications and add all files
```
    git commit -m "your message" .
```
push the local modification to the server
```
    git push branch_name origin/remote_branch_name
```
configure your name and email
```
    git config --global user.name "your name"
    git config --global user.email "foo@bar.com"
```
initialize a new repo
```
    git init
```

- **never work on the same branch unless you do not edit the same file**
  
### 6. EDI Configuration

#### 1. Geany

- **install Geany plugins**

```
    sudo apt install geany-plugins
```

- **Enable Doxygen documenation generator (Gendoc)**
- **You should enable the 'split window' plugin**

#### 2. Vs code

A good set of extension to code in C/C++ on vs code :

**essential**
- C/C++ by Microsoft
  
**documentation**
- Doxygen Documenation generator by Christoph Schlosser

**themes**
- Dracula Official by Dracula Theme
- Atom one dark
- Material icon theme
  
**tools**
- Todo Tree by Grunfuggly
- Markdown All in One

Useful tools in vs code


Beautify your code
```
    CTRL+SHIFT+P
    format document with
    c++
```

### Build system

## 1. Makefile

**this section need to be written if do not use Cmake**

Useful function :

execute make clean and remove executable
```
    make clean
```

remove all files generated from make deeply
```
    make deepclean
```

remove all text file
```
    make textfileclean
```

checkout minunit repository from github
```
    make getminunit
```
Lauch the tests specified in the makefile
```
    make test
```

## 2. Cmake

### Build the project :

- install cmake :
```
    sudo apt install cmake
```
- create build directory : (name based on clion by jetbrains for compatibilies)
```
    cd project_directory
    mkdir cmake-build-* #replace "*" by debug (development) or release (final)
```
- build main program :
```
    cd cmake-build-*
    mkdir MAIN 
    cmake ../../
    make
    ./main
```
- build tests : (debug only please)
```
    cd cmake-build-debug
    mkdir TESTS/your_tests_output_directory
    cmake ../../../tests/your_tests_source_directory
    make
    ./your_executable_name
```
- Exemple : build tests for LIST
```
    cd cmake-build-debug
    mkdir TESTS/LIST
    cmake ../../../tests/LIST
    make
    ./list_test
``` 
- Exemple : build tests for ML
```
    cd cmake-build-debug
    mkdir TESTS/ML
    cmake ../../../tests/ML
    make
    ./average_test
    ./linearRegression
```
- Exemple : build tests for IHM
```
    cd cmake-build-debug
    mkdir TESTS/IHM
    cmake ../../../tests/IHM
    make
    ./ihm_test
```

- clean build directory :
```
    cd cmake-build-*
    make clean
```
- deepclean build directory :
```
    cd cmake-build-*
    make clean
    sudo rm -r *
```

### Create a CMakeList.txt

1. create a static library

- add a **CMakeLists.txt** file in the root folder of your library (e.g : src/LIST )

- add the following code according to your paths
```cmake
cmake_minimum_required(VERSION 3.0.0)
project(nameOfYourLibrarylib VERSION 0.1.0)

file(GLOB_RECURSE HEADERS ../../include/nameOfYourLibrary/*.h)
file(GLOB_RECURSE SOURCES ../../src/nameOfYourLibrary/*.c)

# create static library "libnameOfYourLibrarylib" from SOURCES
add_library(nameOfYourLibrarylib STATIC ${SOURCES} ${HEADERS})
```

